import { askChartGpt } from "@/lib/chat";
import type { QuoteBundle } from "@/lib/market/types";
import { formatMoney, pct } from "@/lib/utils";
import { useState } from "react";

const PRESETS = [
  "Aaj ka candle beginner ko kaise padhna hai?",
  "Bull hai ya bear — last close ke hisaab se?",
  "Support / resistance simple words mein samjhao",
  "Volume kya keh raha hai? Koi buy/sell mat dena.",
];

export function ChartGpt({ bundle }: { bundle: QuoteBundle }) {
  const q = bundle.quote;
  const [prompt, setPrompt] = useState(PRESETS[0]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const points = bundle.chart.points.slice(-12);
  const context = [
    `Symbol: ${q.symbol} (${q.name})`,
    `Last: ${formatMoney(q.price, q.currency)}  Change: ${pct(q.changePct)} (${q.change >= 0 ? "BULL / green" : "BEAR / red"})`,
    `Prev close: ${formatMoney(q.previousClose, q.currency)}  High: ${q.dayHigh ?? "n/a"}  Low: ${q.dayLow ?? "n/a"}`,
    `Volume: ${q.volume ?? "n/a"}  State: ${q.marketState}`,
    `Recent closes: ${points.map((p) => p.close.toFixed(2)).join(", ") || "n/a"}`,
  ].join("\n");

  async function run(p: string) {
    setBusy(true);
    setErr(null);
    try {
      const res = await askChartGpt({ data: { prompt: p, context } });
      if (!res.ok) setErr(res.error);
      else setText(res.text);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not reach Chart GPT");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="overflow-hidden rounded-xl border border-rose-700/40 bg-gradient-to-b from-rose-950/40 to-surface">
      <header className="flex items-center justify-between bg-rose-700 px-4 py-2 text-white">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest">CNBC Awaaz desk · education</p>
          <h2 className="text-base font-semibold">Chart GPT</h2>
        </div>
        <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10px] uppercase">Not a buy/sell call</span>
      </header>
      <div className="space-y-3 p-4">
        <p className="text-xs text-muted">
          Ask how to <em>read</em> this chart — candles, trend, bull vs bear. Chart GPT will not pick stocks for
          you.
        </p>
        <div className="flex flex-wrap gap-1.5">
          {PRESETS.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => {
                setPrompt(p);
                void run(p);
              }}
              className="rounded-full border border-border bg-bg px-3 py-1 text-[11px] hover:border-rose-500"
            >
              {p}
            </button>
          ))}
        </div>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={2}
          className="w-full rounded-lg border border-border bg-bg px-3 py-2 text-sm outline-none focus:border-rose-500"
        />
        <button
          type="button"
          disabled={busy || !prompt.trim()}
          onClick={() => void run(prompt)}
          className="h-10 rounded-full bg-rose-600 px-4 text-sm font-medium text-white disabled:opacity-40"
        >
          {busy ? "Chart GPT soch raha hai…" : "Ask Chart GPT"}
        </button>
        {err ? <p className="text-sm text-rose-300">{err}</p> : null}
        {text ? (
          <div className="whitespace-pre-wrap rounded-lg border border-border bg-bg p-3 text-sm leading-relaxed">
            {text}
          </div>
        ) : null}
      </div>
    </section>
  );
}
