import { useState } from "react";
import { X, Maximize2, Minimize2 } from "lucide-react";

/** Public YouTube embed for CNBC Awaaz-style market coverage. Swap VIDEO_ID for a current live stream. */
const VIDEO_ID = "bY_MJndfYNg";

export function LiveNewsEmbed() {
  const [open, setOpen] = useState(true);
  const [expanded, setExpanded] = useState(false);

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="fixed bottom-4 right-4 z-50 rounded-full bg-rose-600 px-4 py-2 text-xs font-medium text-white shadow-lg hover:bg-rose-500"
      >
        CNBC Awaaz Live
      </button>
    );
  }

  return (
    <div
      className={`fixed z-50 overflow-hidden rounded-xl border border-border bg-bg shadow-2xl transition-all ${
        expanded ? "bottom-4 right-4 h-[70vh] w-[min(560px,95vw)]" : "bottom-4 right-4 h-[180px] w-[320px]"
      }`}
    >
      <div className="flex items-center justify-between bg-rose-700/90 px-2 py-1 text-[11px] font-medium text-white">
        <span className="flex items-center gap-1.5">
          <span className="size-1.5 animate-pulse rounded-full bg-white" />
          CNBC Awaaz · Live / Market
        </span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            className="rounded p-1 hover:bg-white/20"
            onClick={() => setExpanded((e) => !e)}
            aria-label={expanded ? "Minimise" : "Expand"}
          >
            {expanded ? <Minimize2 className="size-3.5" /> : <Maximize2 className="size-3.5" />}
          </button>
          <button
            type="button"
            className="rounded p-1 hover:bg-white/20"
            onClick={() => setOpen(false)}
            aria-label="Close"
          >
            <X className="size-3.5" />
          </button>
        </div>
      </div>
      <iframe
        title="CNBC Awaaz live / market stream"
        src={`https://www.youtube.com/embed/${VIDEO_ID}?autoplay=0&mute=1&rel=0`}
        className="h-[calc(100%-28px)] w-full"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
    </div>
  );
}
