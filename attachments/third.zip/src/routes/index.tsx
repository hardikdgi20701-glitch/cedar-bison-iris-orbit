import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkline } from "@/components/charts/Sparkline";
import { MascotClip } from "@/components/markets/MascotClip";
import { getMarketHome } from "@/lib/market/server";
import type { MarketQuote, NewsItem } from "@/lib/market/types";
import { HEADLINES } from "@/lib/learn";
import { BADGE_META, useSiply } from "@/lib/store";
import { cn, formatMoney, pct, timeAgo } from "@/lib/utils";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({ component: Home });

const REGIONS = [
  { id: "india", label: "India" },
  { id: "us", label: "US" },
  { id: "europe", label: "Europe" },
  { id: "fx", label: "Currencies" },
  { id: "crypto", label: "Crypto" },
] as const;

function Home() {
  const [region, setRegion] = useState<(typeof REGIONS)[number]["id"]>("india");
  const [quotes, setQuotes] = useState<MarketQuote[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [session, setSession] = useState({ open: false, label: "NSE closed" });
  const [busy, setBusy] = useState(true);
  const profile = useSiply((s) => s.profile);
  const badges = useSiply((s) => s.badges);

  useEffect(() => {
    let live = true;
    setBusy(true);
    void getMarketHome({ data: { region } })
      .then((res) => {
        if (!live) return;
        setQuotes(res.quotes);
        setNews(res.news);
        setSession(res.session);
      })
      .catch(() => {
        if (live) {
          setQuotes([]);
          setNews([]);
        }
      })
      .finally(() => {
        if (live) setBusy(false);
      });
    return () => {
      live = false;
    };
  }, [region]);

  const lead = news[0];
  const rest = news.slice(1, 5);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-medium tracking-tight">Markets</h1>
          <p className="mt-1 text-sm text-muted">
            Live NSE & BSE quotes · {session.label}
            {profile.displayName ? ` · Welcome back, ${profile.displayName.split(" ")[0]}` : ""}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link
            to="/search"
            className="inline-flex h-10 items-center rounded-full border border-border px-4 text-sm font-medium hover:bg-surface"
          >
            Deep Search
          </Link>
          <Link
            to="/sip"
            className="inline-flex h-10 items-center rounded-full bg-primary px-4 text-sm font-medium text-primary-fg hover:bg-primary-hover"
          >
            SIP calculator
          </Link>
        </div>
      </div>

      <div className="flex flex-wrap gap-1">
        {REGIONS.map((r) => (
          <button
            key={r.id}
            type="button"
            onClick={() => setRegion(r.id)}
            className={cn(
              "h-9 rounded-full px-4 text-sm",
              region === r.id ? "bg-chip font-medium text-fg" : "text-muted hover:bg-surface hover:text-fg",
            )}
          >
            {r.label}
          </button>
        ))}
      </div>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(busy && quotes.length === 0 ? [0, 1, 2, 3] : quotes).map((q, i) =>
          typeof q === "number" ? (
            <div key={i} className="h-32 animate-pulse rounded-xl border border-border bg-surface" />
          ) : (
            <Link
              key={q.symbol}
              to="/quote/$symbol"
              params={{ symbol: q.symbol }}
              className="rounded-xl border border-border p-4 hover:bg-surface"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm font-medium">{q.name}</p>
                <MascotClip up={q.change >= 0} size="sm" />
              </div>
              <p className="mt-1 text-2xl font-medium tabular-nums tracking-tight">
                {formatMoney(q.price, q.currency)}
              </p>
              <p className={cn("flex items-center gap-1.5 text-sm tabular-nums", q.change >= 0 ? "text-up" : "text-down")}>
                <span className="text-[10px] font-semibold uppercase tracking-wide">
                  {q.change >= 0 ? "Bull" : "Bear"}
                </span>
                {pct(q.changePct)}
              </p>
              <Sparkline data={q.spark} up={q.change >= 0} className="mt-2 h-10 w-full" />
            </Link>
          ),
        )}
      </section>

      <section>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="text-base font-medium">{region === "india" ? "India market summary" : "Market summary"}</h2>
          <Link to="/markets" className="text-sm text-primary hover:underline">
            All markets
          </Link>
        </div>
        {lead ? (
          <article className="rounded-xl border border-border p-4 sm:p-5">
            <p className="text-xs text-subtle">
              {lead.source} · {timeAgo(lead.published)}
            </p>
            <a href={lead.url} target="_blank" rel="noreferrer" className="mt-1 block text-lg font-medium hover:text-primary">
              {lead.title}
            </a>
            <div className="mt-4 divide-y divide-border">
              {rest.map((n) => (
                <a
                  key={n.url + n.title}
                  href={n.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-start justify-between gap-3 py-3 text-sm hover:text-primary"
                >
                  <span>{n.title}</span>
                  <span className="shrink-0 text-xs text-subtle">{n.source}</span>
                </a>
              ))}
            </div>
          </article>
        ) : (
          <article className="rounded-xl border border-border p-4">
            <p className="text-sm font-medium">Classroom tape</p>
            <ul className="mt-3 space-y-3">
              {HEADLINES.map((h) => (
                <li key={h.title}>
                  <Link to="/learn" className="text-sm hover:text-primary">
                    {h.title}
                  </Link>
                  <p className="text-[11px] text-subtle">
                    {h.source} · {h.time}
                  </p>
                </li>
              ))}
            </ul>
          </article>
        )}
      </section>

      <section className="grid gap-3 sm:grid-cols-3">
        <Link to="/planner" className="rounded-xl border border-border p-4 hover:bg-surface">
          <p className="text-xs uppercase tracking-wide text-subtle">Goals</p>
          <p className="mt-1 text-lg font-medium">Build a SIP watchlist</p>
          <p className="mt-1 text-sm text-muted">Name a goal, inflate the cost, see the monthly SIP.</p>
        </Link>
        <Link to="/learn" className="rounded-xl border border-border p-4 hover:bg-surface">
          <p className="text-xs uppercase tracking-wide text-subtle">Learn</p>
          <p className="mt-1 text-lg font-medium">Short explainers</p>
          <p className="mt-1 text-sm text-muted">SIP, inflation, index funds, step-ups — written for first-timers.</p>
        </Link>
        <div className="rounded-xl border border-border p-4">
          <p className="text-xs uppercase tracking-wide text-subtle">Badges</p>
          <ul className="mt-2 flex flex-wrap gap-1.5">
            {badges.map((b) => (
              <li key={b} className="rounded-full bg-primary-soft px-2.5 py-1 text-[11px] font-medium text-primary">
                {BADGE_META[b].label}
              </li>
            ))}
            {badges.length === 0 ? <li className="text-xs text-muted">Sign in and complete onboarding to start.</li> : null}
          </ul>
        </div>
      </section>
    </div>
  );
}
