import { createFileRoute, Link } from "@tanstack/react-router";
import { ChartGpt } from "@/components/markets/ChartGpt";
import { MascotClip } from "@/components/markets/MascotClip";
import { getMarketHome, getQuoteBundle } from "@/lib/market/server";
import type { QuoteBundle } from "@/lib/market/types";
import { formatMoney, pct } from "@/lib/utils";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/chart-gpt")({ component: ChartGptPage });

function ChartGptPage() {
  const [bundle, setBundle] = useState<QuoteBundle | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    void getMarketHome({ data: { region: "india" } })
      .then((home) => {
        const nifty =
          home.quotes.find((q) => /nifty/i.test(q.name) || /nifty/i.test(q.symbol)) ?? home.quotes[0];
        if (!nifty) throw new Error("Could not load an index");
        return getQuoteBundle({ data: { symbol: nifty.symbol, range: "1d" } });
      })
      .then((b) => {
        if (live) setBundle(b);
      })
      .catch((e) => {
        if (live) setErr(e instanceof Error ? e.message : "Could not load Chart GPT");
      });
    return () => {
      live = false;
    };
  }, []);

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-widest text-rose-400">CNBC Awaaz desk · education</p>
        <h1 className="mt-1 text-2xl font-medium tracking-tight">Chart GPT</h1>
        <p className="mt-1 text-sm text-muted">
          A beginner chart teacher in Awaaz-desk style. It explains candles, trend and bull vs bear. It will not
          tell you what to buy.
        </p>
      </div>
      {err ? <p className="text-sm text-rose-300">{err}</p> : null}
      {!bundle && !err ? <div className="h-64 animate-pulse rounded-xl bg-surface" /> : null}
      {bundle ? (
        <>
          <div className="flex items-center gap-4 rounded-xl border border-border p-4">
            <MascotClip up={bundle.quote.change >= 0} size="lg" />
            <div>
              <p className="text-sm text-muted">{bundle.quote.name}</p>
              <p className="text-2xl font-medium tabular-nums">{formatMoney(bundle.quote.price, bundle.quote.currency)}</p>
              <p className={bundle.quote.change >= 0 ? "text-sm text-up" : "text-sm text-down"}>
                {bundle.quote.change >= 0 ? "Bull" : "Bear"} {pct(bundle.quote.changePct)} ·{" "}
                {bundle.quote.marketState === "open" ? "live / delayed" : "last close"}
              </p>
              <Link
                to="/quote/$symbol"
                params={{ symbol: bundle.quote.symbol }}
                className="text-xs text-primary hover:underline"
              >
                Open full chart
              </Link>
            </div>
          </div>
          <ChartGpt bundle={bundle} />
        </>
      ) : null}
    </div>
  );
}
