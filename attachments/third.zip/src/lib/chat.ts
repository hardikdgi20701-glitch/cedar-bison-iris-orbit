import { createServerFn } from "@tanstack/react-start";

export const askResearch = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as { prompt?: string; context?: string };
    const prompt = String(d?.prompt ?? "").trim();
    if (!prompt) throw new Error("Ask a question");
    if (prompt.length > 2000) throw new Error("Keep questions under 2,000 characters");
    return { prompt, context: String(d?.context ?? "").slice(0, 4000) };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Research assistant is unavailable in this environment." };

    const system = `You are PlanVista Finance Research, an educational market explainer for Indian (NSE/BSE) and global markets.
Rules:
- For learning purposes only. Not investment advice, not a SEBI-registered advisor, not a recommendation to buy or sell.
- Be concise, structured, and calm. Use short paragraphs and bullet points.
- If you cite numbers from the provided context, treat them as delayed public-market snapshots that may be stale.
- If data is missing, say so. Do not invent filings, insider information, or guaranteed returns.
- Prefer explaining *why* a move or ratio matters over telling the user what to do.
- End with a one-line reminder: "For learning purposes only."`;

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 700,
        temperature: 0.4,
        messages: [
          { role: "system", content: system },
          {
            role: "user",
            content: data.context
              ? `Context:\n${data.context}\n\nQuestion: ${data.prompt}`
              : data.prompt,
          },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `Research assistant error (${res.status}). Try again.` };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "Empty response. Try a more specific question." };
    return { ok: true as const, text };
  });

export const askChartGpt = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as { prompt?: string; context?: string };
    const prompt = String(d?.prompt ?? "").trim();
    if (!prompt) throw new Error("Ask Chart GPT a question");
    if (prompt.length > 2000) throw new Error("Keep questions under 2,000 characters");
    return { prompt, context: String(d?.context ?? "").slice(0, 5000) };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Chart GPT is unavailable in this environment." };

    const system = `You are "Chart GPT — Awaaz Desk", an educational chart explainer in the style of a calm CNBC Awaaz market-desk teacher (Hindi-English mix is welcome, keep it readable).
You help first-time Indian investors READ a chart. You never tell them to buy or sell a specific stock.

Rules:
- For learning purposes only. Not investment advice. Not a SEBI-registered research analyst or adviser.
- Explain candles, trend, support/resistance, volume, bull vs bear colour in simple words.
- Use the provided snapshot numbers only. If a number is missing, say so. Do not invent prices, targets, or "sure-shot" levels.
- No guaranteed returns. No "ye stock lo". Offer 2–4 teaching bullets and one risk reminder.
- If the user asks for a buy/sell call, refuse and teach how a stop-loss and target are written instead.
- End with: "Yeh sirf padhai ke liye hai — Chart GPT is not a buy/sell call."`;

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 650,
        temperature: 0.35,
        messages: [
          { role: "system", content: system },
          {
            role: "user",
            content: data.context
              ? `Chart snapshot:\n${data.context}\n\nLearner question: ${data.prompt}`
              : data.prompt,
          },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `Chart GPT error (${res.status}). Try again.` };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "Empty response. Try a simpler question." };
    return { ok: true as const, text };
  });
