import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, Moon, Search, Sun, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { useSiply } from "@/lib/store";
import { useTheme } from "@/lib/theme";
import { cn } from "@/lib/utils";
import { SearchBox } from "@/components/markets/SearchBox";
import { ResearchPanel } from "@/components/markets/ResearchPanel";
import { WatchlistRail } from "@/components/markets/WatchlistRail";
import { CloudSync } from "./CloudSync";
import { SiteFooter } from "./SiteFooter";
import { Ticker } from "./Ticker";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/markets", label: "Markets" },
  { to: "/search", label: "Deep Search" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/planner", label: "Goals" },
  { to: "/sip", label: "SIP" },
  { to: "/learn", label: "Learn" },
  { to: "/progress", label: "Progress" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [menu, setMenu] = useState(false);
  const [lists, setLists] = useState(false);
  const [research, setResearch] = useState(false);
  const { theme, toggle } = useTheme();
  const displayName = useSiply((s) => s.profile.displayName) || "Hardik";
  const first = displayName.split(" ")[0] || "Hardik";

  return (
    <div className="min-h-screen bg-bg text-fg">
      <CloudSync />
      <header className="sticky top-0 z-40 border-b border-border bg-bg">
        <div className="flex items-center gap-2 px-2 py-2 sm:px-4">
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface lg:hidden"
            aria-label="Open lists"
            onClick={() => setLists((v) => !v)}
          >
            {lists ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
          <Link to="/" className="flex shrink-0 items-center gap-2 pr-1">
            <img
              src="/planvista-icon.png"
              alt="PlanVista"
              className="size-8 object-contain"
              width={32}
              height={32}
            />
            <span className="hidden text-[20px] tracking-tight sm:inline">
              PlanVista
              <span className="ml-1.5 text-sm text-muted">Finance</span>
            </span>
            <span className="hidden rounded-sm bg-primary-soft px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary md:inline">
              Beta
            </span>
          </Link>
          <SearchBox className="hidden max-w-xl md:block" />
          <div className="ml-auto flex shrink-0 items-center gap-1 sm:gap-2">
            <Link
              to="/search"
              className="inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-sm text-muted hover:bg-surface hover:text-fg"
            >
              <Search className="size-4" />
              <span className="hidden sm:inline">Deep Search</span>
            </Link>
            <button
              type="button"
              onClick={toggle}
              className="inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface"
              aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            >
              {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            </button>
            <button
              type="button"
              className="inline-flex h-9 items-center rounded-full px-3 text-sm text-muted hover:bg-surface xl:hidden"
              onClick={() => setResearch((v) => !v)}
            >
              Research
            </button>
            <div className="flex items-center gap-2 pl-1">
              <span className="grid size-8 place-items-center rounded-full bg-primary text-sm font-medium text-primary-fg">
                {first.charAt(0).toUpperCase()}
              </span>
              <span className="hidden text-sm font-medium sm:inline">{first}</span>
            </div>
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface md:hidden"
              aria-label="Open menu"
              onClick={() => setMenu((v) => !v)}
            >
              {menu ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
        <div className="px-3 pb-2 md:hidden">
          <SearchBox />
        </div>
        <nav className="hidden gap-1 px-4 md:flex">
          {NAV.map((n) => {
            const active = n.to === "/" ? pathname === "/" : pathname.startsWith(n.to);
            return (
              <Link
                key={n.to}
                to={n.to}
                className={cn(
                  "border-b-2 px-3 py-2.5 text-sm",
                  active
                    ? "border-primary font-medium text-primary"
                    : "border-transparent text-muted hover:border-border-strong hover:text-fg",
                )}
              >
                {n.label}
              </Link>
            );
          })}
        </nav>
        {menu ? (
          <nav className="border-t border-border px-3 py-2 md:hidden">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setMenu(false)}
                className="block rounded-md px-3 py-3 text-sm hover:bg-surface"
              >
                {n.label}
              </Link>
            ))}
          </nav>
        ) : null}
      </header>
      <Ticker />
      <div className="border-b border-border bg-warn-soft px-3 py-1.5 text-center text-[11px] text-fg">
        For learning purposes only — not investment advice, not a SEBI-registered advisor. Market data may be
        delayed.
      </div>
      <div className="flex min-h-[70vh]">
        <aside
          className={cn(
            "w-[300px] shrink-0 border-r border-border bg-rail",
            lists ? "fixed inset-y-0 left-0 z-30 mt-[52px] bg-bg lg:static lg:mt-0" : "hidden lg:block",
          )}
        >
          <WatchlistRail />
        </aside>
        <div className="min-w-0 flex-1">
          <main className="mx-auto max-w-5xl px-3 py-5 sm:px-5 sm:py-6">{children}</main>
          <SiteFooter />
        </div>
        <aside
          className={cn(
            "w-[320px] shrink-0 border-l border-border bg-rail",
            research ? "fixed inset-y-0 right-0 z-30 mt-[52px] bg-bg xl:static xl:mt-0" : "hidden xl:block",
          )}
        >
          <div className="sticky top-[108px] h-[calc(100vh-108px)]">
            <ResearchPanel />
          </div>
        </aside>
      </div>
    </div>
  );
}

export function BareShell({ children }: { children: ReactNode }) {
  const { theme, toggle } = useTheme();
  return (
    <div className="min-h-screen bg-bg text-fg">
      <header className="flex items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2">
          <img
            src="/planvista-icon.png"
            alt="PlanVista"
            className="size-8 object-contain"
            width={32}
            height={32}
          />
          <span className="text-[20px] tracking-tight">
            PlanVista
            <span className="ml-1.5 text-sm text-muted">Finance</span>
          </span>
          <span className="rounded-sm bg-primary-soft px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary">
            Beta
          </span>
        </Link>
        <button
          type="button"
          onClick={toggle}
          className="inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface"
          aria-label="Toggle theme"
        >
          {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
        </button>
      </header>
      {children}
    </div>
  );
}
