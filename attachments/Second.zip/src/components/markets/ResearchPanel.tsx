import { Link, useRouterState } from "@tanstack/react-router";
import { ListPlus, Send, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { askResearch } from "@/lib/chat";
import { findCompany } from "@/lib/market/universe";
import { useSiply } from "@/lib/store";
import { cn } from "@/lib/utils";

type Msg = { role: "user" | "assistant"; text: string };

export function ResearchPanel({ context }: { context?: string }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const profile = useSiply((s) => s.profile);
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const symbol = useMemo(() => {
    const m = pathname.match(/\/quote\/([^/]+)/);
    return m ? decodeURIComponent(m[1]) : null;
  }, [pathname]);
  const company = symbol ? findCompany(symbol) : null;
  const name = profile.displayName.split(" ")[0] || "Hardik";

  const suggestions = company
    ? [
        `Give me an overview of ${company.symbol}`,
        `What were the key takeaways from ${company.name} latest quarterly results?`,
        `Why might ${company.symbol} be moving, and what should a learner watch?`,
      ]
    : [
        "What's going on with Indian markets today?",
        "How does a SIP compare with a lump sum for a 5-year goal?",
        "How are higher oil prices affecting Indian retail stocks?",
      ];

  async function send(text: string) {
    const prompt = text.trim();
    if (!prompt || busy) return;
    setBusy(true);
    setErr(null);
    setInput("");
    setMsgs((m) => [...m, { role: "user", text: prompt }]);
    try {
      const res = await askResearch({
        data: {
          prompt,
          context: [
            context ?? "",
            profile.displayName ? `Learner: ${profile.displayName}, age ${profile.age}, ${profile.risk} risk, ${profile.timeHorizon} horizon.` : "",
            company ? `Viewing ${company.name} (${company.yahoo}), sector ${company.sector}.` : "",
          ]
            .filter(Boolean)
            .join("\n"),
        },
      });
      if (!res.ok) {
        setErr(res.error);
        setMsgs((m) => [...m, { role: "assistant", text: res.error }]);
      } else {
        setMsgs((m) => [...m, { role: "assistant", text: res.text }]);
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Could not reach the assistant.";
      setErr(msg);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-4 py-3">
        <h2 className="text-base font-medium">Research</h2>
        <Sparkles className="size-4 text-primary" />
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-3">
        <p className="text-sm text-muted">Hi {name}, ask any financial question</p>
        <ul className="mt-3 space-y-2">
          {suggestions.map((s) => (
            <li key={s}>
              <button
                type="button"
                onClick={() => void send(s)}
                className="flex w-full items-center justify-between gap-2 rounded-lg border border-border px-3 py-2.5 text-left text-sm hover:bg-surface"
              >
                <span>{s}</span>
                <span className="text-subtle">↗</span>
              </button>
            </li>
          ))}
        </ul>
        <p className="mt-5 text-xs font-medium uppercase tracking-wide text-subtle">Explore</p>
        <div className="mt-2 flex flex-col gap-2">
          <Link
            to="/planner"
            className="inline-flex h-10 items-center gap-2 rounded-full border border-border px-3 text-sm hover:bg-surface"
          >
            <ListPlus className="size-4" /> Create a goal
          </Link>
          <Link
            to="/sip"
            className="inline-flex h-10 items-center gap-2 rounded-full border border-border px-3 text-sm hover:bg-surface"
          >
            SIP calculator
          </Link>
          <Link
            to="/progress"
            className="inline-flex h-10 items-center gap-2 rounded-full border border-border px-3 text-sm hover:bg-surface"
          >
            Track progress
          </Link>
        </div>
        {msgs.length ? (
          <ul className="mt-5 space-y-3">
            {msgs.map((m, i) => (
              <li
                key={i}
                className={cn(
                  "rounded-lg px-3 py-2 text-sm leading-relaxed",
                  m.role === "user" ? "bg-primary-soft text-fg" : "border border-border bg-surface",
                )}
              >
                {m.text}
              </li>
            ))}
          </ul>
        ) : null}
        {busy ? <p className="mt-3 text-xs text-muted">Thinking…</p> : null}
        {err && !msgs.length ? <p className="mt-3 text-xs text-down">{err}</p> : null}
      </div>
      <form
        className="border-t border-border p-3"
        onSubmit={(e) => {
          e.preventDefault();
          void send(input);
        }}
      >
        <div className="flex items-end gap-2 rounded-xl border border-border bg-surface px-3 py-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            rows={2}
            placeholder="Ask anything"
            className="min-h-11 flex-1 resize-none bg-transparent text-sm outline-none placeholder:text-subtle"
          />
          <button
            type="submit"
            disabled={busy || !input.trim()}
            className="inline-flex size-10 items-center justify-center rounded-full bg-primary text-primary-fg disabled:opacity-40"
            aria-label="Send"
          >
            <Send className="size-4" />
          </button>
        </div>
        <p className="mt-1.5 text-[10px] text-subtle">For learning purposes only. Not investment advice.</p>
      </form>
    </div>
  );
}
