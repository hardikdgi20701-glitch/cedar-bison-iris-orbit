import { googleFinanceQuoteUrl, googleFinanceSearchUrl, googleNewsUrl, googleSearchUrl, displayTicker } from "./google";
import { createServerFn } from "@tanstack/react-start";
import { findCompany, INDICES, nseSession, searchUniverse } from "./universe";
import type {
  ChartPoint,
  ChartSeries,
  CompanyProfile,
  MarketQuote,
  NewsItem,
  QuoteBundle,
  QuoteRange,
} from "./types";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key) as CacheEntry<T> | undefined;
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value);
  return fn().then((value) => {
    cache.set(key, { at: Date.now(), value });
    return value;
  });
}

async function yahooJson(url: string): Promise<unknown> {
  const res = await fetch(url, {
    headers: {
      "User-Agent": UA,
      Accept: "application/json,text/plain,*/*",
      "Accept-Language": "en-IN,en;q=0.9",
    },
  });
  if (!res.ok) throw new Error(`Yahoo ${res.status}`);
  return res.json();
}

const RANGE_MAP: Record<QuoteRange, { range: string; interval: string }> = {
  "1d": { range: "1d", interval: "2m" },
  "5d": { range: "5d", interval: "15m" },
  "1mo": { range: "1mo", interval: "1d" },
  "6mo": { range: "6mo", interval: "1d" },
  ytd: { range: "ytd", interval: "1d" },
  "1y": { range: "1y", interval: "1d" },
  "5y": { range: "5y", interval: "1wk" },
  max: { range: "max", interval: "1mo" },
};

type ChartRaw = {
  chart?: {
    result?: {
      meta: {
        symbol: string;
        shortName?: string;
        longName?: string;
        exchangeName?: string;
        fullExchangeName?: string;
        currency?: string;
        regularMarketPrice?: number;
        chartPreviousClose?: number;
        previousClose?: number;
        regularMarketDayHigh?: number;
        regularMarketDayLow?: number;
        regularMarketVolume?: number;
        fiftyTwoWeekHigh?: number;
        fiftyTwoWeekLow?: number;
        instrumentType?: string;
      };
      timestamp?: number[];
      indicators?: { quote?: { close?: (number | null)[]; volume?: (number | null)[] }[] };
    }[];
  };
};

function sparkFrom(closes: number[], n = 28): number[] {
  if (closes.length <= n) return closes;
  const step = (closes.length - 1) / (n - 1);
  const out: number[] = [];
  for (let i = 0; i < n; i++) out.push(closes[Math.round(i * step)]!);
  return out;
}

function sessionState(): "open" | "closed" {
  return nseSession().open ? "open" : "closed";
}

async function fetchChart(symbol: string, range: QuoteRange): Promise<{ quote: MarketQuote; series: ChartSeries }> {
  const spec = RANGE_MAP[range];
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${spec.interval}&range=${spec.range}&includePrePost=false`;
  const raw = (await yahooJson(url)) as ChartRaw;
  const result = raw.chart?.result?.[0];
  if (!result) throw new Error("No chart data");
  const meta = result.meta;
  const ts = result.timestamp ?? [];
  const close = result.indicators?.quote?.[0]?.close ?? [];
  const vol = result.indicators?.quote?.[0]?.volume ?? [];
  const points: ChartPoint[] = [];
  const closes: number[] = [];
  for (let i = 0; i < ts.length; i++) {
    const c = close[i];
    if (c == null || !Number.isFinite(c)) continue;
    points.push({ t: ts[i]! * 1000, close: c, volume: vol[i] ?? null });
    closes.push(c);
  }
  const price = meta.regularMarketPrice ?? closes[closes.length - 1] ?? 0;
  const prev = meta.previousClose ?? meta.chartPreviousClose ?? closes[0] ?? price;
  const change = price - prev;
  const changePct = prev ? change / prev : 0;
  const company = findCompany(symbol);
  const quote: MarketQuote = {
    symbol,
    name: company?.name ?? meta.longName ?? meta.shortName ?? symbol,
    shortName: meta.shortName ?? company?.symbol ?? symbol,
    exchange: meta.fullExchangeName ?? meta.exchangeName ?? company?.exchange ?? "",
    currency: meta.currency ?? "INR",
    price,
    previousClose: prev,
    change,
    changePct,
    dayHigh: meta.regularMarketDayHigh ?? null,
    dayLow: meta.regularMarketDayLow ?? null,
    volume: meta.regularMarketVolume ?? null,
    fiftyTwoWeekHigh: meta.fiftyTwoWeekHigh ?? null,
    fiftyTwoWeekLow: meta.fiftyTwoWeekLow ?? null,
    spark: sparkFrom(closes),
    marketState: sessionState(),
  };
  return {
    quote,
    series: { symbol, range, previousClose: prev, currency: quote.currency, points },
  };
}

function parseRss(xml: string): NewsItem[] {
  const items: NewsItem[] = [];
  const blocks = xml.match(/<item>[\s\S]*?<\/item>/g) ?? [];
  for (const block of blocks) {
    const title = decodeXml(tag(block, "title"));
    const link = decodeXml(tag(block, "link"));
    const source =
      decodeXml((block.match(/<source[^>]*>([\s\S]*?)<\/source>/) ?? [])[1] ?? "") ||
      decodeXml(tag(block, "dc:creator")) ||
      "News";
    const published = decodeXml(tag(block, "pubDate"));
    if (!title) continue;
    items.push({ title: title.replace(/ - [^-]+$/, (m) => (source ? "" : m)).trim() || title, source, url: link, published });
    if (items.length >= 10) break;
  }
  return items;
}

function tag(block: string, name: string): string {
  const m = block.match(new RegExp(`<${name}[^>]*><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/${name}>`))
    ?? block.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)<\\/${name}>`));
  return m?.[1]?.trim() ?? "";
}

function decodeXml(s: string): string {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/'/g, "'");
}

async function fetchNews(query: string): Promise<NewsItem[]> {
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-IN&gl=IN&ceid=IN:en`;
  const res = await fetch(url, { headers: { "User-Agent": UA } });
  if (!res.ok) return [];
  const xml = await res.text();
  return parseRss(xml);
}

async function fetchIndiaHeadlines(): Promise<NewsItem[]> {
  const url = "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms";
  try {
    const res = await fetch(url, { headers: { "User-Agent": UA } });
    if (!res.ok) throw new Error("et");
    return parseRss(await res.text());
  } catch {
    return fetchNews("India stock market Nifty Sensex");
  }
}

type YahooSearch = {
  quotes?: {
    symbol?: string;
    shortname?: string;
    longname?: string;
    exchDisp?: string;
    quoteType?: string;
    exchange?: string;
  }[];
};

async function yahooSearch(q: string, indiaOnly = true) {
  const url = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=12&newsCount=0`;
  const raw = (await yahooJson(url)) as YahooSearch;
  return (raw.quotes ?? [])
    .filter((x) => x.symbol && (x.quoteType === "EQUITY" || x.quoteType === "INDEX" || x.quoteType === "ETF"))
    .map((x) => ({
      symbol: x.symbol!,
      name: x.longname ?? x.shortname ?? x.symbol!,
      exchange: x.exchDisp ?? x.exchange ?? "",
      type: x.quoteType ?? "EQUITY",
    }))
    .filter((r) => {
      if (!indiaOnly) return true;
      const ex = r.exchange.toUpperCase();
      return (
        r.symbol.endsWith(".NS") ||
        r.symbol.endsWith(".BO") ||
        ex.includes("NSE") ||
        ex.includes("BSE") ||
        ex.includes("BOMBAY") ||
        r.symbol.startsWith("^") ||
        r.type === "INDEX"
      );
    });
}

function analysisFrom(quote: MarketQuote, yearCloses: number[], profile: CompanyProfile | null): string[] {
  const lines: string[] = [];
  const { price, changePct, fiftyTwoWeekHigh, fiftyTwoWeekLow, dayHigh, dayLow } = quote;
  const up = changePct >= 0;
  lines.push(
    `${quote.name} is ${up ? "up" : "down"} ${(Math.abs(changePct) * 100).toFixed(2)}% versus the previous close, trading at ${formatPx(price, quote.currency)}.`,
  );
  if (fiftyTwoWeekHigh && fiftyTwoWeekLow) {
    const vsHigh = (price / fiftyTwoWeekHigh - 1) * 100;
    const span = fiftyTwoWeekHigh - fiftyTwoWeekLow || 1;
    const pos = ((price - fiftyTwoWeekLow) / span) * 100;
    lines.push(
      `The stock is ${Math.abs(vsHigh).toFixed(1)}% ${vsHigh >= 0 ? "above" : "below"} its 52-week high of ${formatPx(fiftyTwoWeekHigh, quote.currency)}, sitting near the ${pos.toFixed(0)}th percentile of the 52-week range.`,
    );
  }
  if (dayHigh && dayLow) {
    lines.push(`Today’s range is ${formatPx(dayLow, quote.currency)} – ${formatPx(dayHigh, quote.currency)}.`);
  }
  if (yearCloses.length > 20) {
    const ago = yearCloses[0]!;
    const ret = ago ? (price / ago - 1) * 100 : 0;
    lines.push(`Over the available 1-year window the last close implies a ${ret >= 0 ? "gain" : "decline"} of ${Math.abs(ret).toFixed(1)}%.`);
  }
  if (profile?.quarters?.length) {
    const last = profile.quarters[profile.quarters.length - 1]!;
    if (last.yoyRevenue != null) {
      lines.push(
        `Latest compiled quarter (${last.label}) shows revenue ${last.yoyRevenue >= 0 ? "up" : "down"} ${(Math.abs(last.yoyRevenue) * 100).toFixed(1)}% YoY` +
          (last.yoyPat != null
            ? ` and PAT ${last.yoyPat >= 0 ? "up" : "down"} ${(Math.abs(last.yoyPat) * 100).toFixed(1)}% YoY.`
            : "."),
      );
    }
  }
  lines.push(
    "This is an educational snapshot built from public market data — not a recommendation to buy or sell.",
  );
  return lines;
}

function formatPx(n: number, ccy: string): string {
  if (ccy === "INR" || ccy === "USD") {
    const sym = ccy === "INR" ? "₹" : "$";
    return (
      sym +
      n.toLocaleString(ccy === "INR" ? "en-IN" : "en-US", {
        maximumFractionDigits: n >= 100 ? 2 : 4,
      })
    );
  }
  return n.toLocaleString("en-IN", { maximumFractionDigits: 2 }) + " " + ccy;
}

function retFrom(closes: number[], days: number, price: number): number | null {
  if (closes.length < days) return null;
  const base = closes[closes.length - 1 - days];
  if (!base) return null;
  return price / base - 1;
}

export const getQuotes = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const symbols = (data as { symbols?: string[] })?.symbols;
    if (!Array.isArray(symbols)) throw new Error("symbols required");
    return { symbols: symbols.slice(0, 40).map(String) };
  })
  .handler(async ({ data }): Promise<MarketQuote[]> => {
    const out: MarketQuote[] = [];
    await Promise.all(
      data.symbols.map(async (sym) => {
        try {
          const row = await cached(`q:${sym}`, 20_000, () => fetchChart(sym, "1mo"));
          out.push(row.quote);
        } catch {
          /* skip */
        }
      }),
    );
    const order = new Map(data.symbols.map((s, i) => [s, i]));
    out.sort((a, b) => (order.get(a.symbol) ?? 0) - (order.get(b.symbol) ?? 0));
    return out;
  });

export const getChart = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as { symbol?: string; range?: QuoteRange };
    if (!d?.symbol) throw new Error("symbol required");
    const range = (d.range ?? "1d") as QuoteRange;
    if (!(range in RANGE_MAP)) throw new Error("bad range");
    return { symbol: String(d.symbol), range };
  })
  .handler(async ({ data }): Promise<ChartSeries> => {
    const row = await cached(`c:${data.symbol}:${data.range}`, 15_000, () => fetchChart(data.symbol, data.range));
    return row.series;
  });

export const getQuoteBundle = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as { symbol?: string; range?: QuoteRange };
    if (!d?.symbol) throw new Error("symbol required");
    return { symbol: String(d.symbol), range: (d.range ?? "1d") as QuoteRange };
  })
  .handler(async ({ data }): Promise<QuoteBundle> => {
    const profile = findCompany(data.symbol) ?? null;
    const yahoo = profile?.yahoo ?? data.symbol;
    const [main, year] = await Promise.all([
      cached(`c:${yahoo}:${data.range}`, 15_000, () => fetchChart(yahoo, data.range)),
      cached(`c:${yahoo}:1y`, 60_000, () => fetchChart(yahoo, "1y")).catch(() => null),
    ]);
    const yearCloses = year?.series.points.map((p) => p.close) ?? [];
    const newsQuery = profile ? `${profile.name} stock` : `${main.quote.name} stock`;
    const news = await cached(`n:${newsQuery}`, 120_000, () => fetchNews(newsQuery)).catch(() => [] as NewsItem[]);
    const avgVolume =
      year && year.series.points.length
        ? year.series.points.reduce((s, p) => s + (p.volume ?? 0), 0) / year.series.points.length
        : null;
    const marketCap =
      profile?.sharesCr && main.quote.price ? profile.sharesCr * 1e7 * main.quote.price : null;
    const vs52wHigh =
      main.quote.fiftyTwoWeekHigh && main.quote.fiftyTwoWeekHigh > 0
        ? main.quote.price / main.quote.fiftyTwoWeekHigh - 1
        : null;
    return {
      quote: { ...main.quote, spark: year?.quote.spark ?? main.quote.spark },
      chart: main.series,
      profile,
      news,
      analysis: analysisFrom(main.quote, yearCloses, profile),
      stats: {
        open: main.series.points[0]?.close ?? null,
        avgVolume,
        marketCap,
        pe: profile?.pe ?? null,
        eps: profile?.eps ?? null,
        employees: profile?.employees ?? null,
        return1m: yearCloses.length ? retFrom(yearCloses, 21, main.quote.price) : null,
        return1y: yearCloses.length > 2 ? main.quote.price / yearCloses[0]! - 1 : null,
        vs52wHigh,
      },
      delayed: false,
    };
  });

export const searchSymbols = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const q = String((data as { q?: string })?.q ?? "").trim();
    return { q };
  })
  .handler(async ({ data }) => {
    const q = data.q;
    if (q.length < 1) return { local: [] as CompanyProfile[], remote: [] as { symbol: string; name: string; exchange: string; type: string }[] };
    const local = searchUniverse(q, 8);
    let remote: { symbol: string; name: string; exchange: string; type: string }[] = [];
    if (q.length >= 2) {
      try {
        remote = await cached(`s:${q.toLowerCase()}`, 60_000, () => yahooSearch(q, true));
        const localYahoo = new Set(local.map((c) => c.yahoo.toUpperCase()));
        remote = remote.filter((r) => !localYahoo.has(r.symbol.toUpperCase()));
      } catch {
        remote = [];
      }
    }
    return { local, remote: remote.slice(0, 8) };
  });

export const deepSearch = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const q = String((data as { q?: string })?.q ?? "").trim();
    if (q.length > 80) throw new Error("Keep searches under 80 characters");
    return { q };
  })
  .handler(async ({ data }) => {
    const q = data.q;
    const empty = {
      query: q,
      hits: [] as {
        symbol: string;
        ticker: string;
        name: string;
        exchange: string;
        googleFinance: string;
        googleSearch: string;
        googleNews: string;
      }[],
      quotes: [] as MarketQuote[],
      news: [] as NewsItem[],
      googleFinanceSearch: googleFinanceSearchUrl(q || "Nifty 50"),
      googleSearch: googleSearchUrl(`${q || "Indian stock market"} NSE BSE`),
    };
    if (q.length < 1) return empty;
    const local = searchUniverse(q, 10);
    let remote: { symbol: string; name: string; exchange: string; type: string }[] = [];
    try {
      remote = await cached(`ds:${q.toLowerCase()}`, 60_000, () => yahooSearch(q, false));
    } catch {
      remote = [];
    }
    const hits: typeof empty.hits = [];
    const seen = new Set<string>();
    for (const c of local) {
      const key = c.yahoo.toUpperCase();
      if (seen.has(key)) continue;
      seen.add(key);
      hits.push({
        symbol: c.yahoo,
        ticker: c.symbol,
        name: c.name,
        exchange: c.exchange,
        googleFinance: googleFinanceQuoteUrl(c.yahoo),
        googleSearch: googleSearchUrl(`${c.name} stock NSE`),
        googleNews: googleNewsUrl(`${c.name} stock`),
      });
    }
    for (const r of remote) {
      const key = r.symbol.toUpperCase();
      if (seen.has(key)) continue;
      seen.add(key);
      hits.push({
        symbol: r.symbol,
        ticker: displayTicker(r.symbol),
        name: r.name,
        exchange: r.exchange || r.type,
        googleFinance: googleFinanceQuoteUrl(r.symbol),
        googleSearch: googleSearchUrl(`${r.name} stock`),
        googleNews: googleNewsUrl(`${r.name} stock`),
      });
    }
    const top = hits.slice(0, 10);
    const quotes: MarketQuote[] = [];
    await Promise.all(
      top.map(async (h) => {
        try {
          const row = await cached(`q:${h.symbol}`, 20_000, () => fetchChart(h.symbol, "1mo"));
          quotes.push(row.quote);
        } catch {
          /* skip */
        }
      }),
    );
    const news = await cached(`n:ds:${q.toLowerCase()}`, 120_000, () => fetchNews(`${q} stock India`)).catch(
      () => [] as NewsItem[],
    );
    return {
      query: q,
      hits: top,
      quotes,
      news,
      googleFinanceSearch: googleFinanceSearchUrl(q),
      googleSearch: googleSearchUrl(`${q} NSE BSE stock`),
    };
  });

export const getMarketHome = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const region = String((data as { region?: string })?.region ?? "india") as
      | "india"
      | "us"
      | "europe"
      | "crypto"
      | "fx";
    return { region };
  })
  .handler(async ({ data }) => {
    const list = INDICES.filter((i) => i.region === data.region).slice(0, 4);
    const quotes: MarketQuote[] = [];
    await Promise.all(
      list.map(async (i) => {
        try {
          const row = await cached(`q:${i.yahoo}`, 20_000, () => fetchChart(i.yahoo, "1mo"));
          quotes.push({ ...row.quote, name: i.name, shortName: i.name });
        } catch {
          /* skip */
        }
      }),
    );
    const news = await cached("n:india-home", 180_000, () => fetchIndiaHeadlines()).catch(() => [] as NewsItem[]);
    const session = nseSession();
    return { quotes, news, session, region: data.region };
  });

export const getIndexList = createServerFn({ method: "GET" }).handler(async () => {
  return INDICES;
});
