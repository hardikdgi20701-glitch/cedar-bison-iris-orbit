export type Article = {
  slug: string;
  title: string;
  kicker: string;
  minutes: number;
  body: string[];
};

export const ARTICLES: Article[] = [
  {
    slug: "what-is-a-sip",
    title: "What a SIP actually does with your ₹500",
    kicker: "Basics",
    minutes: 4,
    body: [
      "A Systematic Investment Plan (SIP) invests a fixed amount on a fixed date, usually into a mutual fund. You are not timing the market — you are buying more units when prices are low and fewer when they are high (rupee-cost averaging).",
      "For students, the point is habit plus compounding. ₹2,000 a month for five years is ₹1.2 lakh of your money; at an illustrative 11% annualised return the corpus is closer to ₹1.6 lakh. The extra is market growth, not magic.",
      "SIPs can be paused. They are not a loan and not a lock-in (except tax-saving ELSS, which has a 3-year lock). Start with an amount you will not miss on a bad month.",
    ],
  },
  {
    slug: "goal-based-vs-random",
    title: "Why every SIP needs a job",
    kicker: "Planning",
    minutes: 3,
    body: [
      "A nameless SIP is easy to raid for a weekend trip. A SIP labelled “semester fees 2029” is harder to break. Goal-based investing assigns each rupee a date, an amount, and a risk level.",
      "Short goals (under 3 years) should not sit in pure equity. Long goals can. Mixing them in one fund makes it tempting to sell the long-term units when a short-term bill arrives.",
      "PlanVista maps each goal to its own SIP size and mix so you can see if the plan fits your surplus before you open a folio.",
    ],
  },
  {
    slug: "inflation-is-the-silent-fee",
    title: "Inflation is the fee nobody invoices",
    kicker: "Inflation",
    minutes: 3,
    body: [
      "A ₹80,000 laptop today is not ₹80,000 in 18 months. Education costs in India have often run above general CPI. Planning in today’s rupees without an inflation line understates the SIP you need.",
      "PlanVista inflates the goal first, then solves for the monthly amount. If the number shocks you, that is useful information: extend the date, step up the SIP with income hikes, or shrink the goal.",
    ],
  },
  {
    slug: "risk-for-students",
    title: "Risk when you have more time than money",
    kicker: "Risk",
    minutes: 5,
    body: [
      "Students usually have a long career ahead and a small corpus. Volatility on a ₹10,000 pot is emotionally loud but financially small. The bigger risk is staying in a 3% savings account while fees inflate at 7%.",
      "That does not mean 100% equity for a laptop you need next semester. Match risk to the calendar: emergency and near-term fees in debt/liquid; five-year study-abroad seed can hold more equity.",
      "The quiz in PlanVista is a teaching tool, not a SEBI-registered risk profile. When you invest for real, complete the fund house’s questionnaire.",
    ],
  },
  {
    slug: "index-funds-first",
    title: "Why an index fund is a good first SIP",
    kicker: "Funds",
    minutes: 4,
    body: [
      "A Nifty 50 or Nifty 500 index fund (direct plan) tracks the market at a low expense ratio. You skip star-manager risk and the urge to switch funds every year.",
      "Direct plans cut distributor commission. For a 10-year SIP the difference compounds. You still need a demat/MF account (Groww, Coin, MF Central, etc.) — PlanVista does not transact.",
      "Categories shown in the planner are sleeves, not buy-lists. Always read the scheme document and past rolling returns, not last year’s rank.",
    ],
  },
  {
    slug: "step-up-sip",
    title: "Step-up SIPs: let your stipend do the heavy lifting",
    kicker: "Tactics",
    minutes: 3,
    body: [
      "A 10% annual step-up means this year’s ₹2,000 becomes ₹2,200 next year. That often matches internship or placement hikes and dramatically cuts the starting SIP needed for a far-off goal.",
      "If you cannot commit to a step-up, plan a flat SIP. A missed step-up is not a failure — recalculate. Consistency beats an aggressive schedule you abandon in exam season.",
    ],
  },
];

export const HEADLINES = [
  { title: "SEBI’s investor-ed push: why campuses are the next classroom", source: "Campus Desk", time: "2h" },
  { title: "Direct plans vs regular: the 1% that compounds on student SIPs", source: "Explainers", time: "5h" },
  { title: "Education inflation vs CPI — plan the fee, not last year’s brochure", source: "Data", time: "1d" },
  { title: "Liquid funds for emergency money: what students actually need", source: "Guides", time: "1d" },
];
