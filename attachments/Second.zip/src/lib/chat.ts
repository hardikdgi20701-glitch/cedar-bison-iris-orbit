import { createServerFn } from "@tanstack/react-start";

export const askResearch = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as { prompt?: string; context?: string };
    const prompt = String(d?.prompt ?? "").trim();
    if (!prompt) throw new Error("Ask a question");
    if (prompt.length > 2000) throw new Error("Keep questions under 2,000 characters");
    return { prompt, context: String(d?.context ?? "").slice(0, 4000) };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Research assistant is unavailable in this environment." };

    const system = `You are PlanVista Finance Research, an educational market explainer for Indian (NSE/BSE) and global markets.
Rules:
- For learning purposes only. Not investment advice, not a SEBI-registered advisor, not a recommendation to buy or sell.
- Be concise, structured, and calm. Use short paragraphs and bullet points.
- If you cite numbers from the provided context, treat them as delayed public-market snapshots that may be stale.
- If data is missing, say so. Do not invent filings, insider information, or guaranteed returns.
- Prefer explaining *why* a move or ratio matters over telling the user what to do.
- End with a one-line reminder: "For learning purposes only."`;

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 700,
        temperature: 0.4,
        messages: [
          { role: "system", content: system },
          {
            role: "user",
            content: data.context
              ? `Context:\n${data.context}\n\nQuestion: ${data.prompt}`
              : data.prompt,
          },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `Research assistant error (${res.status}). Try again.` };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "Empty response. Try a more specific question." };
    return { ok: true as const, text };
  });
