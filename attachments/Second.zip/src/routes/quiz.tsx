import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { QUIZ, scoreToRisk } from "@/lib/finance";
import { useSiply } from "@/lib/store";
import { useState } from "react";

export const Route = createFileRoute("/quiz")({ component: Quiz });

function Quiz() {
  const completeQuiz = useSiply((s) => s.completeQuiz);
  const navigate = useNavigate();
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const q = QUIZ[i]!;
  const done = answers.length === QUIZ.length;

  return (
    <div className="mx-auto max-w-xl">
      <p className="text-xs font-medium uppercase tracking-wide text-subtle">Risk questionnaire</p>
      <h1 className="mt-1 text-2xl font-medium tracking-tight">Seven questions. One mix.</h1>
      <p className="mt-2 text-sm text-muted">
        This is a teaching profile for student goals — not a SEBI-registered assessment.
      </p>
      <div className="mt-4 h-1 overflow-hidden rounded-full bg-chip">
        <div
          className="h-full bg-primary transition-[width] duration-200"
          style={{ width: `${(Math.min(answers.length, QUIZ.length) / QUIZ.length) * 100}%` }}
        />
      </div>

      {done ? (
        <div className="mt-8 rounded-lg border border-border p-5">
          <p className="text-sm text-muted">Your mapped profile</p>
          <p className="mt-1 text-3xl font-medium capitalize">{scoreToRisk(answers)}</p>
          <p className="mt-2 text-sm text-muted">
            Score {answers.reduce((a, b) => a + b, 0)} / {QUIZ.length * 2}. Conservative ≤5, moderate ≤10, else
            aggressive. Emergency goals still use a debt-heavy sleeve.
          </p>
          <button
            type="button"
            className="mt-5 inline-flex h-11 items-center rounded-full bg-primary px-5 text-sm font-medium text-primary-fg hover:bg-primary-hover"
            onClick={() => {
              completeQuiz(answers);
              void navigate({ to: "/portfolio" });
            }}
          >
            Save and open portfolio
          </button>
        </div>
      ) : (
        <div className="mt-8">
          <p className="text-xs text-subtle">
            {i + 1} of {QUIZ.length}
          </p>
          <h2 className="mt-2 text-lg font-medium">{q.q}</h2>
          <ul className="mt-4 space-y-2">
            {q.options.map((o) => (
              <li key={o.label}>
                <button
                  type="button"
                  className="flex min-h-12 w-full items-center rounded-md border border-border px-3 py-3 text-left text-sm hover:border-primary hover:bg-primary-soft"
                  onClick={() => {
                    const next = [...answers, o.score];
                    setAnswers(next);
                    setI((v) => v + 1);
                  }}
                >
                  {o.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
