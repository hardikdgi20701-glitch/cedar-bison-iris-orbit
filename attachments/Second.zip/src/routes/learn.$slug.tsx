import { createFileRoute, Link } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/learn";
import { useSiply } from "@/lib/store";
import { useEffect } from "react";

export const Route = createFileRoute("/learn/$slug")({ component: Article });

function Article() {
  const { slug } = Route.useParams();
  const article = ARTICLES.find((a) => a.slug === slug);
  const markRead = useSiply((s) => s.markRead);

  useEffect(() => {
    if (article) markRead(article.slug);
  }, [article, markRead]);

  if (!article) {
    return (
      <p className="py-16 text-center text-muted">
        Article missing.{" "}
        <Link to="/learn" className="text-primary hover:underline">
          All explainers
        </Link>
      </p>
    );
  }

  return (
    <article className="mx-auto max-w-2xl">
      <Link to="/learn" className="text-xs text-primary hover:underline">
        All explainers
      </Link>
      <p className="mt-4 text-[11px] font-medium uppercase tracking-wide text-primary">{article.kicker}</p>
      <h1 className="mt-1 text-3xl font-medium tracking-tight">{article.title}</h1>
      <p className="mt-2 text-sm text-subtle">{article.minutes} min read</p>
      <div className="mt-6 space-y-4 text-[15px] leading-relaxed text-fg">
        {article.body.map((p) => (
          <p key={p.slice(0, 24)}>{p}</p>
        ))}
      </div>
    </article>
  );
}
