import { createFileRoute, Link } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/learn";
import { useSiply } from "@/lib/store";

export const Route = createFileRoute("/learn")({ component: Learn });

function Learn() {
  const read = useSiply((s) => s.readSlugs);
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-medium tracking-tight">Learn</h1>
        <p className="mt-1 text-sm text-muted">
          Short explainers written for first-time student investors. Read two to earn the reader badge.
        </p>
      </div>
      <ul className="divide-y divide-border overflow-hidden rounded-lg border border-border">
        {ARTICLES.map((a) => (
          <li key={a.slug}>
            <Link to="/learn/$slug" params={{ slug: a.slug }} className="block px-4 py-4 hover:bg-surface">
              <p className="text-[11px] font-medium uppercase tracking-wide text-primary">{a.kicker}</p>
              <p className="mt-1 text-base font-medium">{a.title}</p>
              <p className="text-xs text-subtle">
                {a.minutes} min read
                {read.includes(a.slug) ? " · Read" : ""}
              </p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
