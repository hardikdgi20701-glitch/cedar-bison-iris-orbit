# NSE India Website – Look-alike Prototype

A static front-end prototype that closely mirrors the layout, structure, and visual style of the official National Stock Exchange of India website (https://www.nseindia.com/).

> **Disclaimer:** This is an **unofficial educational / portfolio prototype**. It is **not affiliated with, endorsed by, or connected to** the National Stock Exchange of India Ltd. All market data shown is sample / static data captured for demonstration purposes only.

## What’s included

| File / Folder       | Description                                      |
|---------------------|--------------------------------------------------|
| `index.html`        | Main homepage structure                          |
| `css/styles.css`    | Complete styling (NSE-inspired blue theme)       |
| `js/app.js`         | Ticker, indices list, font-size & contrast controls |
| `README.md`         | This file                                        |

## Features mirrored from the real NSE site

- Top utility bar (CAS, Option Chain, Market Turnover, Listings, IPO, Circulars, etc.)
- Language selector & accessibility controls (font size A+/A–, contrast)
- Logo + global search bar + Login / Register
- Main navigation with dropdown menus (Market Data, Products, Listings, Investors, Members, Resources, About Us)
- Scrolling stock-price ticker
- NIFTY 50 hero card with OHLC, chart placeholder & time-frame tabs
- Key Indices side panel
- Market Statistics cards (Advances / Declines / Circuits / 52-week highs-lows)
- Market Turnover table (Equity, Derivatives, Currency, Commodity, Debt, etc.)
- Quick-access cards (Live Market, Option Chain, IPO, Circulars, Investor’s Home, Corporates)
- New-listing / announcement banners
- Full footer with links
- Responsive layout (desktop → tablet → mobile)

## How to use

1. Unzip the folder.
2. Open `index.html` in any modern browser (Chrome recommended).
3. No build step or server required – pure static HTML/CSS/JS.

## How to combine with your existing project

- Copy the `css/`, `js/` and `index.html` into your project root or a sub-folder.
- Adjust paths in `index.html` if needed.
- Re-use individual sections (header, ticker, stats cards, table, footer) as components.

## Notes

- All prices and statistics are **static sample data** taken from a snapshot of the live site on 07-Oct-2026 for visual fidelity only.
- No live API calls are made.
- The prototype intentionally uses a clean, professional design language close to the official NSE blue/orange palette.

---

Created as a look-alike prototype for educational purposes.
