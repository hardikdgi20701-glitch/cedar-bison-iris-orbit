/* NSE Prototype – Interactive behaviours */

(function () {
  'use strict';

  // ---- Sample stock data for ticker ----
  const stocks = [
    { sym: 'ADANIENT', price: '2,765.50', chg: '-84.40 (-2.96%)', pos: false },
    { sym: 'ADANIPORTS', price: '1,754.20', chg: '-29.20 (-1.64%)', pos: false },
    { sym: 'APOLLOHOSP', price: '7,853.00', chg: '-61.50 (-0.78%)', pos: false },
    { sym: 'ASIANPAINT', price: '2,367.20', chg: '-57.00 (-2.35%)', pos: false },
    { sym: 'AXISBANK', price: '1,245.80', chg: '-2.20 (-0.18%)', pos: false },
    { sym: 'BAJAJ-AUTO', price: '9,790.00', chg: '-227.00 (-2.27%)', pos: false },
    { sym: 'BAJAJFINSV', price: '1,743.50', chg: '-8.90 (-0.51%)', pos: false },
    { sym: 'BAJFINANCE', price: '966.00', chg: '2.90 (0.30%)', pos: true },
    { sym: 'BEL', price: '378.65', chg: '-8.75 (-2.26%)', pos: false },
    { sym: 'BHARTIARTL', price: '1,843.30', chg: '32.80 (1.81%)', pos: true },
    { sym: 'BSE', price: '3,350.80', chg: '45.80 (1.39%)', pos: true },
    { sym: 'CIPLA', price: '1,330.50', chg: '-9.70 (-0.72%)', pos: false },
    { sym: 'COALINDIA', price: '413.05', chg: '1.40 (0.34%)', pos: true },
    { sym: 'HDFCBANK', price: '702.45', chg: '-9.00 (-1.27%)', pos: false },
    { sym: 'ICICIBANK', price: '1,348.40', chg: '5.60 (0.42%)', pos: true },
    { sym: 'INFY', price: '993.50', chg: '-20.35 (-2.01%)', pos: false },
    { sym: 'ITC', price: '263.45', chg: '-3.25 (-1.22%)', pos: false },
    { sym: 'RELIANCE', price: '1,209.90', chg: '-8.10 (-0.67%)', pos: false },
    { sym: 'SBIN', price: '948.75', chg: '-10.00 (-1.04%)', pos: false },
    { sym: 'TCS', price: '2,085.30', chg: '-14.70 (-0.70%)', pos: false },
    { sym: 'TITAN', price: '4,370.70', chg: '-179.30 (-3.94%)', pos: false },
    { sym: 'NIFTY 50', price: '22,583.00', chg: '-193.10 (-0.85%)', pos: false },
  ];

  // ---- Key indices ----
  const indices = [
    { name: 'NIFTY 50', price: '22,583.00', chg: '-193.10 (-0.85%)', pos: false },
    { name: 'NIFTY NEXT 50', price: '69,313.00', chg: '-660.70 (-0.94%)', pos: false },
    { name: 'NIFTY BANK', price: '54,893.85', chg: '-234.55 (-0.43%)', pos: false },
    { name: 'NIFTY FIN SERVICE', price: '24,856.30', chg: '-89.75 (-0.36%)', pos: false },
    { name: 'NIFTY MID SELECT', price: '13,735.75', chg: '-90.25 (-0.65%)', pos: false },
    { name: 'NIFTY 100', price: '23,676.20', chg: '-205.50 (-0.86%)', pos: false },
    { name: 'NIFTY MIDCAP 100', price: '59,324.75', chg: '-436.45 (-0.73%)', pos: false },
    { name: 'NIFTY SMLCAP 100', price: '19,475.30', chg: '26.60 (0.14%)', pos: true },
    { name: 'NIFTY AUTO', price: '25,115.40', chg: '-426.55 (-1.67%)', pos: false },
    { name: 'NIFTY IT', price: '27,790.15', chg: '-345.90 (-1.23%)', pos: false },
  ];

  // Build ticker
  function buildTicker() {
    const track = document.getElementById('tickerTrack');
    if (!track) return;
    // Duplicate list for seamless loop
    const items = [...stocks, ...stocks];
    track.innerHTML = items.map(s => `
      <span class="ticker-item">
        <span class="sym">${s.sym}</span>
        <span>${s.price}</span>
        <span class="chg ${s.pos ? 'pos' : 'neg'}">${s.chg}</span>
      </span>
    `).join('');
  }

  // Build indices list
  function buildIndices() {
    const list = document.getElementById('indicesList');
    if (!list) return;
    list.innerHTML = indices.map(i => `
      <li>
        <span class="idx-name">${i.name}</span>
        <span class="idx-val">
          <span class="idx-price">${i.price}</span>
          <span class="idx-chg ${i.pos ? 'pos' : 'neg'}">${i.chg}</span>
        </span>
      </li>
    `).join('');
  }

  // Font size controls
  function setupFontControls() {
    const btns = document.querySelectorAll('.font-btn');
    let base = 14;
    btns.forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.size;
        if (action === 'up') base = Math.min(base + 1, 20);
        else if (action === 'down') base = Math.max(base - 1, 11);
        else base = 14;
        document.body.style.fontSize = base + 'px';
      });
    });
  }

  // Contrast toggle
  function setupContrast() {
    const btn = document.querySelector('.contrast-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      document.body.classList.toggle('high-contrast');
    });
  }

  // Chart tab switching (visual only)
  function setupChartTabs() {
    const tabs = document.querySelectorAll('.chart-tabs button');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
      });
    });
  }

  // Search (simple alert demo)
  function setupSearch() {
    const input = document.getElementById('searchInput');
    const btn = document.querySelector('.search-btn');
    if (!input || !btn) return;
    const doSearch = () => {
      const q = input.value.trim();
      if (q) alert('Search demo: Looking up "' + q + '" (prototype only)');
    };
    btn.addEventListener('click', doSearch);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') doSearch();
    });
  }

  // Init
  document.addEventListener('DOMContentLoaded', () => {
    buildTicker();
    buildIndices();
    setupFontControls();
    setupContrast();
    setupChartTabs();
    setupSearch();
  });
})();
