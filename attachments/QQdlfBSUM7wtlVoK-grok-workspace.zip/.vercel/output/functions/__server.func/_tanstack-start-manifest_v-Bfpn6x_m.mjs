//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bfpn6x_m.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/analytics",
			"/chart-gpt",
			"/gate",
			"/learn",
			"/markets",
			"/quote/$symbol"
		],
		preloads: [
			"/assets/index-R0piE_l0.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/link-anJVWdi9.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/preload-helper-G__tLwmk.js",
			"/assets/redirect-DtIAAt0y.js",
			"/assets/useRouter-VZUr0Np1.js",
			"/assets/useNavigate-Co_V3MLd.js",
			"/assets/utils-SI_Es5Th.js",
			"/assets/store-BSe66tvp.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-R0piE_l0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BH6a41PO.js",
			"/assets/card-CvNebkid.js",
			"/assets/bull-bear-ghdpk2E4.js",
			"/assets/quote-card-DAnt5Xyt.js",
			"/assets/articles-X0fEZ1Qq.js"
		]
	},
	"/analytics": {
		filePath: "/workspace/src/routes/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-CLFnWOAd.js",
			"/assets/generateCategoricalChart-Bgk-2GMl.js",
			"/assets/card-CvNebkid.js"
		]
	},
	"/chart-gpt": {
		filePath: "/workspace/src/routes/chart-gpt.tsx",
		children: void 0,
		preloads: [
			"/assets/chart-gpt-DGNlFvCU.js",
			"/assets/price-chart-iVRg6Mpx.js",
			"/assets/card-CvNebkid.js"
		]
	},
	"/gate": {
		filePath: "/workspace/src/routes/gate.tsx",
		children: void 0,
		preloads: [
			"/assets/gate-CgDl198a.js",
			"/assets/card-CvNebkid.js",
			"/assets/quiz-Dq5ZKx8F.js",
			"/assets/input-tV4lCLpv.js"
		]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: ["/learn/$slug"],
		preloads: [
			"/assets/learn-RmMEnzOc.js",
			"/assets/card-CvNebkid.js",
			"/assets/articles-X0fEZ1Qq.js"
		]
	},
	"/markets": {
		filePath: "/workspace/src/routes/markets.tsx",
		children: void 0,
		preloads: [
			"/assets/markets-B1fxskcE.js",
			"/assets/card-CvNebkid.js",
			"/assets/quote-card-DAnt5Xyt.js"
		]
	},
	"/learn/$slug": {
		filePath: "/workspace/src/routes/learn.$slug.tsx",
		children: void 0,
		preloads: ["/assets/learn._slug-CZLalO8L.js"]
	},
	"/quote/$symbol": {
		filePath: "/workspace/src/routes/quote.$symbol.tsx",
		children: void 0,
		preloads: [
			"/assets/quote._symbol-BFpJw65u.js",
			"/assets/price-chart-iVRg6Mpx.js",
			"/assets/card-CvNebkid.js",
			"/assets/bull-bear-ghdpk2E4.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
