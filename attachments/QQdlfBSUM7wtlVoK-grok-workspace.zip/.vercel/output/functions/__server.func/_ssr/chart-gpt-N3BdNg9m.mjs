import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-CpS5yj8T.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useMarketBoard } from "./router-Cpe-PNfT.mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { n as PriceChart, t as ChartGptPanel } from "./price-chart-BQzMJ3dI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chart-gpt-N3BdNg9m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChartGptPage() {
	const { data } = useMarketBoard();
	const quotes = data?.quotes ?? [];
	const [id, setId] = (0, import_react.useState)("NIFTY");
	const quote = (0, import_react.useMemo)(() => quotes.find((q) => q.id === id) ?? quotes[0], [quotes, id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.16em] text-muted",
						children: "CNBC Awaaz-style desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl tracking-tight",
						children: "Chart GPT"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-sm text-muted",
						children: "A teaching desk that reads candles, trend, and stops in plain language. It will not tell you to buy or sell. Pair it with the live Awaaz window in the corner — television is context, not a broker."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: quotes.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setId(q.id),
					className: cn("shrink-0 rounded-full border px-3 py-1 text-xs", q.id === quote?.id ? "border-accent bg-surface-2 text-fg" : "border-border text-muted"),
					children: q.id
				}, q.id))
			}),
			quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceChart, { quote })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartGptPanel, { quote })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { className: "h-64 animate-pulse bg-surface-2" })
		]
	});
}
//#endregion
export { ChartGptPage as component };
