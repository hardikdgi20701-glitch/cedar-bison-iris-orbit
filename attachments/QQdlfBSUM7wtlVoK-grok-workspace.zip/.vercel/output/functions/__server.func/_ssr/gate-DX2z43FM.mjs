import { i as __toESM } from "../_runtime.mjs";
import { a as hashString, o as todayKey, t as cn } from "./utils-CpS5yj8T.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Button, l as writeGate } from "./router-Cpe-PNfT.mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { t as Input } from "./input-Bf-oSb3z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-B6XTM5Fz.js
var BANK = [
	{
		id: "lose-money",
		prompt: "If you buy a share, what can happen to your money?",
		context: "A first-day fact every new investor must accept.",
		options: [
			"The exchange guarantees you a profit after 1 year",
			"You can lose some or all of the money you invested",
			"SEBI will refund losses if the stock falls",
			"A green day means your capital is locked in as profit"
		],
		answer: 1,
		why: "Shares have no guaranteed return. Price can fall. Only invest money you can afford to keep at risk."
	},
	{
		id: "sip",
		prompt: "What is a SIP, in plain words?",
		options: [
			"A loan from the broker to buy more shares",
			"A one-time lump-sum bet on a hot stock",
			"Investing a fixed amount on a schedule, usually into a mutual fund",
			"A government bonus paid when Nifty is green"
		],
		answer: 2,
		why: "A Systematic Investment Plan puts a fixed sum in at regular intervals. It is a habit, not a promise of profit."
	},
	{
		id: "bull-green",
		prompt: "A stock’s last trade is shown in green with a bull mark. What does that mean?",
		options: [
			"You should buy it immediately",
			"The last move was up versus the previous close — not a buy call",
			"The company cannot report a loss this quarter",
			"SEBI has certified the stock as safe"
		],
		answer: 1,
		why: "Green / bull only describes the last price move. It is not advice to buy, hold, or sell."
	},
	{
		id: "rent-money",
		prompt: "Which money should stay out of the stock market?",
		options: [
			"Money already sitting in a 5-year goal fund",
			"A small amount you can leave untouched for years",
			"Next month’s rent, fees, or emergency cash",
			"A long-term SIP you started after building an emergency buffer"
		],
		answer: 2,
		why: "Near-term living costs and emergency money do not belong in shares. Markets can stay down longer than a rent cycle."
	},
	{
		id: "past-returns",
		prompt: "A fund card shows “+18% last year”. What is the honest reading?",
		options: [
			"You will also earn 18% this year",
			"Past returns are a record of the past, not a promise",
			"SEBI requires the same return next year",
			"The number is a guaranteed bank-like interest rate"
		],
		answer: 1,
		why: "Past performance is not a guide to future results. That line exists in every SEBI-mandated disclaimer for a reason."
	},
	{
		id: "sebi",
		prompt: "What is SEBI’s role in the Indian market?",
		options: [
			"It picks winning stocks for retail investors",
			"It is the market regulator — it writes and enforces the rules",
			"It pays compensation when Nifty falls 2%",
			"It runs every brokerage’s trading app"
		],
		answer: 1,
		why: "The Securities and Exchange Board of India regulates markets and intermediaries. It does not give stock tips."
	},
	{
		id: "stop-loss",
		prompt: "What is a stop-loss, for a beginner?",
		options: [
			"A bonus the broker pays if you lose money",
			"A planned exit price so a loss cannot run without a decision",
			"A way to buy more shares as the price falls",
			"A SEBI rule that blocks all selling"
		],
		answer: 1,
		why: "A stop-loss is your pre-decided “this is enough” price. It does not guarantee that exact fill in a fast market."
	},
	{
		id: "demat",
		prompt: "Where do the shares you buy actually sit?",
		options: [
			"As paper certificates in your wallet",
			"Inside the trading app’s chat window",
			"In a demat account in your name, held electronically",
			"At SEBI headquarters until you sell"
		],
		answer: 2,
		why: "Indian shares are electronic. A demat account is the locker; a trading account is the counter you use to place orders."
	},
	{
		id: "index",
		prompt: "Nifty 50 is best described as…",
		options: [
			"A single company you can buy by name “Nifty”",
			"A basket that tracks 50 large Indian companies",
			"A government savings scheme with fixed interest",
			"A private tip sheet from a TV channel"
		],
		answer: 1,
		why: "An index is a scoreboard for a group of stocks. You cannot buy the index itself; you buy a fund or the members."
	},
	{
		id: "advice",
		prompt: "A learning site explains candles and shows a live TV feed. Is that a buy or sell order?",
		options: [
			"Yes — if the screen is green you must buy",
			"Yes — Chart GPT is a SEBI-registered advisor",
			"No. Education and news are not personalised investment advice",
			"Only if your quiz score is above 70%"
		],
		answer: 2,
		why: "PlanVista is an educational prototype. It is not a broker, not a research analyst, and not investment advice."
	}
];
function pickDailyQuiz(date = /* @__PURE__ */ new Date()) {
	const key = todayKey(date);
	const seed = hashString(`planvista-quiz-${key}`);
	const shuffled = [...BANK.filter((q) => q.id !== "lose-money")];
	let s = seed;
	for (let i = shuffled.length - 1; i > 0; i--) {
		s = s * 1664525 + 1013904223 >>> 0;
		const j = s % (i + 1);
		[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
	}
	return [BANK.find((q) => q.id === "lose-money"), ...shuffled.slice(0, 6)];
}
function scorePercent(correct, total = 7) {
	if (total <= 0) return 0;
	return Math.round(correct / total * 100);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/gate-DX2z43FM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Progress({ value, className, tone = "accent" }) {
	const pct = Math.max(0, Math.min(100, value));
	const fill = tone === "bull" ? "bg-bull" : tone === "bear" ? "bg-bear" : tone === "warn" ? "bg-warn" : "bg-accent";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-2 w-full overflow-hidden rounded-full bg-surface-2", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full rounded-full transition-[width] duration-300", fill),
			style: { width: `${pct}%` }
		})
	});
}
function ScoreRing({ percent, size = 176, label = "Risk fitness" }) {
	const r = 54;
	const circ = 2 * Math.PI * r;
	const clamped = Math.max(0, Math.min(100, percent));
	const offset = circ - clamped / 100 * circ;
	const pass = clamped >= 70;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			style: {
				width: size,
				height: size
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				width: size,
				height: size,
				viewBox: "0 0 128 128",
				className: "absolute inset-0 -rotate-90",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "64",
					cy: "64",
					r,
					fill: "none",
					stroke: "var(--color-surface-2)",
					strokeWidth: "8"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "64",
					cy: "64",
					r,
					fill: "none",
					stroke: pass ? "var(--color-bull)" : "var(--color-bear)",
					strokeWidth: "8",
					strokeLinecap: "round",
					strokeDasharray: circ,
					strokeDashoffset: offset,
					className: "transition-[stroke-dashoffset] duration-500"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 flex flex-col items-center justify-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-5xl font-medium tabular-nums tracking-tight text-fg",
					children: [clamped, "%"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.18em] text-muted",
					children: label
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-sm", pass ? "text-bull" : "text-bear"),
			children: pass ? "Pass mark cleared" : `Need 70% to enter`
		})]
	});
}
function GatePage() {
	const navigate = useNavigate();
	const questions = (0, import_react.useMemo)(() => pickDailyQuiz(), []);
	const [step, setStep] = (0, import_react.useState)("profile");
	const [name, setName] = (0, import_react.useState)("");
	const [ageOk, setAgeOk] = (0, import_react.useState)(false);
	const [docName, setDocName] = (0, import_react.useState)(null);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [correct, setCorrect] = (0, import_react.useState)(0);
	const [answered, setAnswered] = (0, import_react.useState)(0);
	const [locked, setLocked] = (0, import_react.useState)(false);
	const [finalPct, setFinalPct] = (0, import_react.useState)(0);
	const q = questions[index];
	const runningPct = answered === 0 ? 0 : scorePercent(correct, answered);
	const projected = scorePercent(correct + (7 - answered), 7);
	function finish(nextCorrect) {
		const pct = scorePercent(nextCorrect, 7);
		setFinalPct(pct);
		const passed = pct >= 70;
		writeGate({
			name: name.trim(),
			ageConfirmed: true,
			documentName: docName,
			quizScore: pct,
			quizPassed: passed,
			quizDate: todayKey(),
			correctCount: nextCorrect,
			totalCount: 7
		});
		setStep("result");
	}
	function submitAnswer() {
		if (picked == null || locked) return;
		setLocked(true);
		const isRight = picked === q.answer;
		const nextCorrect = correct + (isRight ? 1 : 0);
		const nextAnswered = answered + 1;
		setCorrect(nextCorrect);
		setAnswered(nextAnswered);
		window.setTimeout(() => {
			if (index + 1 >= 7) finish(nextCorrect);
			else {
				setIndex((i) => i + 1);
				setPicked(null);
				setLocked(false);
			}
		}, 650);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg px-4 py-8 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-lg flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.2em] text-muted",
							children: "PlanVista gate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl tracking-tight",
							children: "18+ learning desk"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Beginner quiz. Pass mark ",
								70,
								"%. Not a broker. Not SEBI-registered advice."
							]
						})
					]
				}),
				step === "profile" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "space-y-4 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Your name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "As you want it on the desk"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3 text-sm leading-relaxed text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 size-4 accent-accent",
								checked: ageOk,
								onChange: (e) => setAgeOk(e.target.checked)
							}), "I confirm I am 18 or older. Indian securities markets are not a game for minors."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: !name.trim() || !ageOk,
							onClick: () => setStep("docs"),
							children: "Continue"
						})
					]
				}) : null,
				step === "docs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "space-y-4 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Mock document check"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "A real broker needs PAN and KYC. This prototype only records a filename on your device. Do not upload genuine ID cards here."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "file",
							accept: ".pdf,image/*",
							onChange: (e) => setDocName(e.target.files?.[0]?.name ?? null)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "w-full",
							onClick: () => setDocName("demo-pan-card.pdf"),
							children: "Attach demo PAN (filename only, nothing is uploaded)"
						}),
						docName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-fg",
							children: ["Attached: ", docName]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: !docName,
							onClick: () => setStep("quiz"),
							children: "Start today’s quiz"
						})
					]
				}) : null,
				step === "quiz" && q ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "space-y-5 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted",
								children: [
									"Question ",
									index + 1,
									" of ",
									7
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: ["Daily paper · ", todayKey()]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-3xl tabular-nums leading-none text-fg",
									children: [runningPct, "%"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] uppercase tracking-[0.14em] text-muted",
									children: "Running score"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: (index + (locked ? 1 : 0)) / 7 * 100 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-subtle",
							children: answered === 0 ? `Need 70% (${Math.ceil(70 / 100 * 7)} of 7) to enter.` : `If you ace the rest, max score is ${projected}%.`
						}),
						q.context ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: q.context
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl leading-snug",
							children: q.prompt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: q.options.map((opt, i) => {
								const show = locked;
								const right = i === q.answer;
								const mine = i === picked;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: locked,
									onClick: () => setPicked(i),
									className: `w-full rounded-lg border px-3 py-3 text-left text-sm leading-relaxed ${show && right ? "border-bull bg-bull/10 text-fg" : show && mine && !right ? "border-bear bg-bear/10 text-fg" : mine ? "border-accent bg-surface-2 text-fg" : "border-border text-muted hover:text-fg"}`,
									children: opt
								}, opt);
							})
						}),
						locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: q.why
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: picked == null || locked,
							onClick: submitAnswer,
							children: index + 1 === 7 ? "See my percentage" : "Lock answer"
						})
					]
				}) : null,
				step === "result" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "space-y-5 p-5 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
							children: "Your risk-fitness score"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, { percent: finalPct }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								correct,
								" of ",
								7,
								" correct · pass mark ",
								70,
								"% · score ",
								finalPct,
								"%"
							]
						}),
						finalPct >= 70 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-fg",
							children: [
								"Welcome, ",
								name.trim(),
								". Your risk-fitness score is stored on this device and shown in the header."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: () => navigate({ to: "/" }),
							children: "Enter the desk"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-fg",
							children: [
								"Score ",
								finalPct,
								"% is below ",
								70,
								"%. Read a starter lesson, then retry today’s paper. The desk stays closed until you clear the mark."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: "outline",
							onClick: () => {
								setStep("quiz");
								setIndex(0);
								setPicked(null);
								setCorrect(0);
								setAnswered(0);
								setLocked(false);
								setFinalPct(0);
							},
							children: "Retry quiz"
						})] })
					]
				}) : null
			]
		})
	});
}
//#endregion
export { GatePage as component };
