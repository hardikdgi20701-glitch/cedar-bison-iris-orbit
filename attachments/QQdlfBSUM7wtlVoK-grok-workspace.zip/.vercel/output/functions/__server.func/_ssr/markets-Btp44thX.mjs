import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useMarketBoard } from "./router-Cpe-PNfT.mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { t as QuoteCard } from "./quote-card-BJxKNeP4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/markets-Btp44thX.js
var import_jsx_runtime = require_jsx_runtime();
function MarketsPage() {
	const { data, isLoading, dataUpdatedAt } = useMarketBoard();
	const quotes = data?.quotes ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Markets"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Delayed public prints when the feed answers; otherwise a same-day simulation so the board still moves when you open the desk. Bull / bear follows the last close."
				}),
				dataUpdatedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-subtle",
					children: ["Refreshed ", new Date(dataUpdatedAt).toLocaleTimeString("en-IN")]
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: isLoading ? Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { className: "h-20 animate-pulse bg-surface-2" }, i)) : quotes.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteCard, { quote: q }, q.id))
		})]
	});
}
//#endregion
export { MarketsPage as component };
