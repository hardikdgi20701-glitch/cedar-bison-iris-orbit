import { a as hashString, o as todayKey } from "./utils-CpS5yj8T.mjs";
import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotes-Cn6eV3jv.js
var SYMBOLS = [
	{
		id: "NIFTY",
		yahoo: "^NSEI",
		name: "Nifty 50",
		kind: "index",
		sector: "Index"
	},
	{
		id: "SENSEX",
		yahoo: "^BSESN",
		name: "Sensex",
		kind: "index",
		sector: "Index"
	},
	{
		id: "BANKNIFTY",
		yahoo: "^NSEBANK",
		name: "Bank Nifty",
		kind: "index",
		sector: "Index"
	},
	{
		id: "RELIANCE",
		yahoo: "RELIANCE.NS",
		name: "Reliance",
		kind: "stock",
		sector: "Energy"
	},
	{
		id: "TCS",
		yahoo: "TCS.NS",
		name: "TCS",
		kind: "stock",
		sector: "IT"
	},
	{
		id: "HDFCBANK",
		yahoo: "HDFCBANK.NS",
		name: "HDFC Bank",
		kind: "stock",
		sector: "Banking"
	},
	{
		id: "INFY",
		yahoo: "INFY.NS",
		name: "Infosys",
		kind: "stock",
		sector: "IT"
	},
	{
		id: "ICICIBANK",
		yahoo: "ICICIBANK.NS",
		name: "ICICI Bank",
		kind: "stock",
		sector: "Banking"
	},
	{
		id: "ITC",
		yahoo: "ITC.NS",
		name: "ITC",
		kind: "stock",
		sector: "FMCG"
	},
	{
		id: "SBIN",
		yahoo: "SBIN.NS",
		name: "SBI",
		kind: "stock",
		sector: "Banking"
	},
	{
		id: "BHARTI",
		yahoo: "BHARTIARTL.NS",
		name: "Bharti Airtel",
		kind: "stock",
		sector: "Telecom"
	},
	{
		id: "LT",
		yahoo: "LT.NS",
		name: "Larsen & Toubro",
		kind: "stock",
		sector: "Infra"
	}
];
function findSymbol(id) {
	const key = id.toUpperCase();
	return SYMBOLS.find((s) => s.id === key || s.yahoo === key) ?? SYMBOLS[0];
}
function seededWalk(def) {
	const day = todayKey();
	const hour = (/* @__PURE__ */ new Date()).getHours();
	let s = hashString(`${def.id}-${day}-${hour}`);
	const rand = () => {
		s = s * 1664525 + 1013904223 >>> 0;
		return s / 4294967296;
	};
	const base = {
		NIFTY: 24750,
		SENSEX: 80920,
		BANKNIFTY: 55640,
		RELIANCE: 1428,
		TCS: 3895,
		HDFCBANK: 1662,
		INFY: 1874,
		ICICIBANK: 1218,
		ITC: 492,
		SBIN: 812,
		BHARTI: 1840,
		LT: 3625
	}[def.id] ?? 1e3;
	const drift = (rand() - .48) * .012;
	const candles = [];
	let price = base * (1 - drift);
	const start = Date.now() - 25056e5;
	for (let i = 0; i < 30; i++) {
		const o = price;
		const move = (rand() - .48) * .018 * price;
		const c = Math.max(1, o + move);
		const h = Math.max(o, c) * (1 + rand() * .006);
		const l = Math.min(o, c) * (1 - rand() * .006);
		candles.push({
			t: start + i * 864e5,
			o,
			h,
			l,
			c,
			v: Math.round(2e6 + rand() * 8e6)
		});
		price = c;
	}
	const last = candles[candles.length - 1];
	const prev = candles[candles.length - 2] ?? last;
	const change = last.c - prev.c;
	return {
		id: def.id,
		yahoo: def.yahoo,
		name: def.name,
		kind: def.kind,
		sector: def.sector,
		price: last.c,
		previousClose: prev.c,
		change,
		changePct: change / prev.c * 100,
		high: last.h,
		low: last.l,
		volume: last.v,
		spark: candles.map((c) => c.c),
		candles,
		isBull: change >= 0,
		source: "delayed-sim",
		asOf: (/* @__PURE__ */ new Date()).toISOString()
	};
}
async function fetchYahoo(def) {
	const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(def.yahoo)}?interval=1d&range=1mo`;
	const res = await fetch(url, {
		headers: {
			"User-Agent": "Mozilla/5.0 PlanVistaEducation/1.0",
			Accept: "application/json"
		},
		signal: AbortSignal.timeout(4e3)
	});
	if (!res.ok) return null;
	const result = (await res.json()).chart?.result?.[0];
	const quote = result?.indicators?.quote?.[0];
	const ts = result?.timestamp ?? [];
	if (!result || !quote || !ts.length) return null;
	const candles = [];
	for (let i = 0; i < ts.length; i++) {
		const o = quote.open?.[i];
		const h = quote.high?.[i];
		const l = quote.low?.[i];
		const c = quote.close?.[i];
		const v = quote.volume?.[i];
		if (o == null || h == null || l == null || c == null) continue;
		candles.push({
			t: ts[i] * 1e3,
			o,
			h,
			l,
			c,
			v: v ?? 0
		});
	}
	if (candles.length < 2) return null;
	const last = candles[candles.length - 1];
	const prevClose = result.meta?.previousClose ?? result.meta?.chartPreviousClose ?? candles[candles.length - 2].c;
	const price = result.meta?.regularMarketPrice ?? last.c;
	const change = price - prevClose;
	return {
		id: def.id,
		yahoo: def.yahoo,
		name: def.name,
		kind: def.kind,
		sector: def.sector,
		price,
		previousClose: prevClose,
		change,
		changePct: change / prevClose * 100,
		high: last.h,
		low: last.l,
		volume: last.v,
		spark: candles.map((c) => c.c),
		candles,
		isBull: change >= 0,
		source: "live",
		asOf: (/* @__PURE__ */ new Date()).toISOString()
	};
}
async function loadOne(def) {
	try {
		const live = await fetchYahoo(def);
		if (live) return live;
	} catch {}
	return seededWalk(def);
}
var getMarketBoard_createServerFn_handler = createServerRpc({
	id: "099ce4e3bc88a2a9dc8c397c6b5b7eb7b182f5fd3bb64b888853e3d2b0f20f70",
	name: "getMarketBoard",
	filename: "src/lib/market/quotes.ts"
}, (opts) => getMarketBoard.__executeServer(opts));
var getMarketBoard = createServerFn({ method: "GET" }).handler(getMarketBoard_createServerFn_handler, async () => {
	const quotes = await Promise.all(SYMBOLS.map((s) => loadOne(s)));
	const nifty = quotes.find((q) => q.id === "NIFTY") ?? quotes[0];
	return {
		quotes,
		session: {
			isBull: nifty.isBull,
			leader: nifty,
			asOf: nifty.asOf,
			source: quotes.some((q) => q.source === "live") ? "live" : "delayed-sim"
		}
	};
});
var getQuote_createServerFn_handler = createServerRpc({
	id: "e1c77e5b8511c8ac364e6202ff8792d7224b832de345ef158132942a22a4e583",
	name: "getQuote",
	filename: "src/lib/market/quotes.ts"
}, (opts) => getQuote.__executeServer(opts));
var getQuote = createServerFn({ method: "POST" }).validator((id) => String(id || "NIFTY")).handler(getQuote_createServerFn_handler, async ({ data }) => loadOne(findSymbol(data)));
//#endregion
export { getMarketBoard_createServerFn_handler, getQuote_createServerFn_handler };
