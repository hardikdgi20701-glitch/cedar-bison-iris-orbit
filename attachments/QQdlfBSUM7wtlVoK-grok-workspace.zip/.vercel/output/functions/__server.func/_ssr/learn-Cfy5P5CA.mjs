import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { t as ARTICLES } from "./articles-DcAT5KRE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-Cfy5P5CA.js
var import_jsx_runtime = require_jsx_runtime();
function LearnPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "space-y-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Learn the market"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-sm text-muted",
				children: "A beginner course: shares, indexes, demat, candles, stops, graphs, and SEBI. Read in order. Nothing here is a tip."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2",
			children: ARTICLES.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/learn/$slug",
				params: { slug: a.slug },
				className: "block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "h-full overflow-hidden p-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: a.image,
						alt: "",
						className: "h-40 w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs uppercase tracking-[0.14em] text-muted",
								children: [
									a.level,
									" · ",
									a.minutes,
									" min"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl text-fg",
								children: a.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: a.dek
							})
						]
					})]
				})
			}, a.slug))
		})]
	});
}
//#endregion
export { LearnPage as component };
