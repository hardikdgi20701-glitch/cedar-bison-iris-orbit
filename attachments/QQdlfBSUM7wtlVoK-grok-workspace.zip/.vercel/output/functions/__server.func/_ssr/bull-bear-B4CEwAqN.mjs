import { t as cn } from "./utils-CpS5yj8T.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bull-bear-B4CEwAqN.js
var import_jsx_runtime = require_jsx_runtime();
function BullBearMark({ isBull, className, size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("relative inline-flex overflow-hidden rounded-md border border-border bg-surface-2", size === "lg" ? "h-16 w-16" : size === "sm" ? "h-8 w-8" : "h-11 w-11", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			className: "h-full w-full object-cover",
			autoPlay: true,
			muted: true,
			loop: true,
			playsInline: true,
			poster: isBull ? "/media/bull.jpg" : "/media/bear.jpg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
				src: isBull ? "/media/bull.mp4" : "/media/bear.mp4",
				type: "video/mp4"
			})
		}, isBull ? "bull" : "bear")
	});
}
//#endregion
export { BullBearMark as t };
