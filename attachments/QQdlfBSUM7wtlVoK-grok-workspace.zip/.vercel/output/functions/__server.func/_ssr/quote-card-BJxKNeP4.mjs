import { i as formatPct, r as formatInr, t as cn } from "./utils-CpS5yj8T.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { t as BullBearMark } from "./bull-bear-B4CEwAqN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote-card-BJxKNeP4.js
var import_jsx_runtime = require_jsx_runtime();
function Sparkline({ data, isBull, className }) {
	if (!data.length) return null;
	const min = Math.min(...data);
	const span = Math.max(...data) - min || 1;
	const w = 120;
	const h = 36;
	const pts = data.map((v, i) => {
		return `${i / Math.max(data.length - 1, 1) * w},${h - (v - min) / span * h}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: cn("h-9 w-28", className),
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
			fill: "none",
			stroke: isBull ? "var(--color-bull)" : "var(--color-bear)",
			strokeWidth: "2",
			points: pts
		})
	});
}
function QuoteCard({ quote }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/quote/$symbol",
		params: { symbol: quote.id },
		className: "block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "flex items-center gap-3 p-3 transition-colors hover:bg-surface-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BullBearMark, { isBull: quote.isBull }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium text-fg",
						children: quote.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							quote.id,
							" · ",
							quote.sector
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
					data: quote.spark,
					isBull: quote.isBull,
					className: "hidden sm:block"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium tabular-nums text-fg",
						children: quote.kind === "index" ? quote.price.toFixed(2) : formatInr(quote.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-xs tabular-nums", quote.isBull ? "text-bull" : "text-bear"),
						children: formatPct(quote.changePct)
					})]
				})
			]
		})
	});
}
//#endregion
export { QuoteCard as t };
