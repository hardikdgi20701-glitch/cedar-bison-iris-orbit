import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-CpS5yj8T.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useMarketBoard, c as useGate } from "./router-Cpe-PNfT.mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { c as Cell, i as XAxis, l as ResponsiveContainer, n as BarChart, r as YAxis, s as Bar, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analytics-CGISLdYZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AnalyticsPage() {
	const { data } = useMarketBoard();
	const gate = useGate();
	const quotes = data?.quotes ?? [];
	const breadth = (0, import_react.useMemo)(() => {
		const bull = quotes.filter((q) => q.isBull).length;
		return {
			bull,
			bear: quotes.length - bull,
			avg: quotes.length ? quotes.reduce((s, q) => s + q.changePct, 0) / quotes.length : 0,
			best: [...quotes].sort((a, b) => b.changePct - a.changePct)[0],
			worst: [...quotes].sort((a, b) => a.changePct - b.changePct)[0]
		};
	}, [quotes]);
	const bars = quotes.map((q) => ({
		name: q.id,
		pct: Number(q.changePct.toFixed(2)),
		bull: q.isBull
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Analytics"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Breadth of this delayed board plus your stored risk-fitness percentage. Teaching stats, not a model portfolio."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.14em] text-muted",
							children: "Your risk score"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("font-display text-4xl tabular-nums", (gate.quizScore ?? 0) >= 70 ? "text-bull" : "text-bear"),
							children: [gate.quizScore ?? "—", "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: [
								gate.correctCount ?? "—",
								" / ",
								gate.totalCount ?? "—",
								" on ",
								gate.quizDate ?? "—"
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.14em] text-muted",
							children: "Bull vs bear"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-4xl tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-bull",
									children: breadth.bull
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: " / "
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-bear",
									children: breadth.bear
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-subtle",
							children: "Names up vs down on this board"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.14em] text-muted",
							children: "Average move"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("font-display text-4xl tabular-nums", breadth.avg >= 0 ? "text-bull" : "text-bear"),
							children: [
								breadth.avg >= 0 ? "+" : "",
								breadth.avg.toFixed(2),
								"%"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-subtle",
							children: "Equal-weight across listed names"
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "Session change %"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-72",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: bars,
							margin: {
								top: 8,
								right: 8,
								left: 0,
								bottom: 24
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 10
									},
									interval: 0,
									angle: -35,
									textAnchor: "end"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { tick: {
									fill: "var(--color-muted)",
									fontSize: 11
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "var(--color-surface)",
									border: "1px solid var(--color-border)",
									borderRadius: 12
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "pct",
									radius: [
										6,
										6,
										0,
										0
									],
									children: bars.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: b.bull ? "var(--color-bull)" : "var(--color-bear)" }, b.name))
								})
							]
						})
					})
				})]
			}),
			breadth.best && breadth.worst ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Strongest print ",
					breadth.best.name,
					" (",
					breadth.best.changePct.toFixed(2),
					"%). Weakest ",
					breadth.worst.name,
					" (",
					breadth.worst.changePct.toFixed(2),
					"%). Still not a recommendation."
				]
			}) : null
		]
	});
}
//#endregion
export { AnalyticsPage as component };
