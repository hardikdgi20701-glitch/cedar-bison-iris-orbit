import { i as formatPct, n as formatCompact, r as formatInr, t as cn } from "./utils-CpS5yj8T.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Route, o as useQuote } from "./router-Cpe-PNfT.mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { n as PriceChart, t as ChartGptPanel } from "./price-chart-BQzMJ3dI.mjs";
import { t as BullBearMark } from "./bull-bear-B4CEwAqN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote._symbol-DIr8A5cm.js
var import_jsx_runtime = require_jsx_runtime();
function QuotePage() {
	const { symbol } = Route.useParams();
	const { data: quote, isLoading } = useQuote(symbol);
	if (isLoading || !quote) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { className: "h-80 animate-pulse bg-surface-2" });
	const price = quote.kind === "index" ? quote.price.toFixed(2) : formatInr(quote.price);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-start gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BullBearMark, {
						isBull: quote.isBull,
						size: "lg"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted",
								children: quote.sector
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-3xl tracking-tight",
								children: quote.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: quote.id
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl tabular-nums",
							children: price
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("text-sm tabular-nums", quote.isBull ? "text-bull" : "text-bear"),
							children: [
								quote.isBull ? "Bull" : "Bear",
								" ",
								formatPct(quote.changePct)
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceChart, { quote })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					["Prev close", quote.kind === "index" ? quote.previousClose.toFixed(2) : formatInr(quote.previousClose)],
					["High", quote.kind === "index" ? quote.high.toFixed(2) : formatInr(quote.high)],
					["Low", quote.kind === "index" ? quote.low.toFixed(2) : formatInr(quote.low)],
					["Volume", formatCompact(quote.volume)]
				].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tabular-nums text-fg",
						children: v
					})]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartGptPanel, { quote })
		]
	});
}
//#endregion
export { QuotePage as component };
