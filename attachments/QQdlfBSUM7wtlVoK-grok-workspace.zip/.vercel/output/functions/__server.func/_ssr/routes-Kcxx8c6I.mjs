import { i as formatPct, t as cn } from "./utils-CpS5yj8T.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useMarketBoard, c as useGate } from "./router-Cpe-PNfT.mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { t as ARTICLES } from "./articles-DcAT5KRE.mjs";
import { t as BullBearMark } from "./bull-bear-B4CEwAqN.mjs";
import { t as QuoteCard } from "./quote-card-BJxKNeP4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Kcxx8c6I.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { data, isLoading } = useMarketBoard();
	const gate = useGate();
	const session = data?.session;
	const indexes = data?.quotes.filter((q) => q.kind === "index") ?? [];
	const stocks = data?.quotes.filter((q) => q.kind === "stock") ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "overflow-hidden rounded-xl border border-border bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-0 md:grid-cols-[1.1fr_0.9fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
								children: "Today’s session"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-4xl tracking-tight",
								children: session ? session.isBull ? "Bull tape" : "Bear tape" : "Opening the tape"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "max-w-md text-sm leading-relaxed text-muted",
								children: [
									"Hello ",
									gate.name || "learner",
									". The animal follows Nifty’s last close. Green is not a buy. Red is not a sell. Your risk-fitness score is",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: cn("tabular-nums font-medium", (gate.quizScore ?? 0) >= 70 ? "text-bull" : "text-bear"),
										children: [gate.quizScore ?? "—", "%"]
									}),
									"."
								]
							}),
							session ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn("text-sm tabular-nums", session.isBull ? "text-bull" : "text-bear"),
								children: [
									session.leader.name,
									" ",
									formatPct(session.leader.changePct),
									" ·",
									" ",
									session.source === "live" ? "live delayed" : "refreshed simulation"
								]
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative min-h-48",
						children: session ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							className: "absolute inset-0 h-full w-full object-cover",
							autoPlay: true,
							muted: true,
							loop: true,
							playsInline: true,
							poster: session.isBull ? "/media/bull.jpg" : "/media/bear.jpg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
								src: session.isBull ? "/media/bull.mp4" : "/media/bear.mp4",
								type: "video/mp4"
							})
						}, session.isBull ? "bull" : "bear") : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full bg-surface-2" })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Indexes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/markets",
						className: "text-sm text-muted hover:text-fg",
						children: "All markets"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: isLoading ? Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { className: "h-20 animate-pulse bg-surface-2" }, i)) : indexes.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteCard, { quote: q }, q.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Watchlist"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: stocks.slice(0, 6).map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteCard, { quote: q }, q.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Start learning"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/learn",
						className: "text-sm text-muted hover:text-fg",
						children: "Full course"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: ARTICLES.slice(0, 4).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/learn/$slug",
						params: { slug: a.slug },
						className: "block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "overflow-hidden p-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: a.image,
								alt: "",
								className: "h-32 w-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs uppercase tracking-[0.14em] text-muted",
										children: a.level
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium text-fg",
										children: a.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: a.dek
									})
								]
							})]
						})
					}, a.slug))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-xs text-subtle",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BullBearMark, {
					isBull: session?.isBull ?? true,
					size: "sm"
				}), "Mascots describe the last print. They never place an order."]
			})
		]
	});
}
//#endregion
export { Home as component };
