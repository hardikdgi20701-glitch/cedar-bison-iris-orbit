import { i as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as createServerFn } from "./ssr.mjs";
import { i as Button, s as createSsrRpc } from "./router-Cpe-PNfT.mjs";
import { t as Card } from "./card-BnwYzZyF.mjs";
import { a as Area, i as XAxis, l as ResponsiveContainer, o as CartesianGrid, r as YAxis, t as AreaChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
import { t as Input } from "./input-Bf-oSb3z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/price-chart-BQzMJ3dI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var askChartGpt = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("6eb684e8e29c699ce23df45d5fc9a3bc7c3a901945723e2b270c9c57f85f44b5"));
function ChartGptPanel({ quote }) {
	const [question, setQuestion] = (0, import_react.useState)("");
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)(null);
	async function run(q) {
		setBusy(true);
		setNote(null);
		try {
			const res = await askChartGpt({ data: {
				quote,
				question: q
			} });
			setText(res.text);
			if (!res.ok) setNote(res.error);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "space-y-4 p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
					children: "Chart GPT · Awaaz desk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl text-fg",
					children: "Read this chart, do not trade it"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Teaching only. No buy, sell, or hold. ",
						quote.name,
						" last close is a",
						" ",
						quote.isBull ? "bull" : "bear",
						" print."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 sm:flex-row",
				onSubmit: (e) => {
					e.preventDefault();
					run(question);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: question,
					onChange: (e) => setQuestion(e.target.value),
					placeholder: "Ask about candles, stop-loss, trend…"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					className: "shrink-0",
					children: busy ? "Reading…" : "Explain"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"What is the trend?",
					"Where is a beginner stop?",
					"Read the last candle."
				].map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full border border-border px-3 py-1 text-xs text-muted hover:text-fg",
					onClick: () => {
						setQuestion(q);
						run(q);
					},
					children: q
				}, q))
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [note, ". On-desk teaching notes below."]
			}) : null,
			text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3 whitespace-pre-wrap text-sm leading-relaxed text-fg/90",
				children: text
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Ask a question or tap a prompt to open the desk."
			})
		]
	});
}
function PriceChart({ quote }) {
	const data = quote.candles.map((c) => ({
		t: new Date(c.t).toLocaleDateString("en-IN", {
			day: "2-digit",
			month: "short"
		}),
		close: c.c,
		high: c.h,
		low: c.l
	}));
	const stroke = quote.isBull ? "var(--color-bull)" : "var(--color-bear)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "pv",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: stroke,
							stopOpacity: .28
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: stroke,
							stopOpacity: 0
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-border)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "t",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						domain: ["auto", "auto"],
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						width: 64
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
						background: "var(--color-surface)",
						border: "1px solid var(--color-border)",
						borderRadius: 12,
						color: "var(--color-fg)"
					} }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "close",
						stroke,
						fill: "url(#pv)",
						strokeWidth: 2
					})
				]
			})
		})
	});
}
//#endregion
export { PriceChart as n, ChartGptPanel as t };
