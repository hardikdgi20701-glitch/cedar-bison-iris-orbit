import { useState } from "react";
import { askChartGpt } from "@/lib/chart-gpt/ask";
import type { Quote } from "@/lib/market/quotes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

export function ChartGptPanel({ quote }: { quote: Quote }) {
  const [question, setQuestion] = useState("");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);

  async function run(q: string) {
    setBusy(true);
    setNote(null);
    try {
      const res = await askChartGpt({ data: { quote, question: q } });
      setText(res.text);
      if (!res.ok) setNote(res.error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="space-y-4 p-5">
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Chart GPT · Awaaz desk</p>
        <h3 className="font-display text-xl text-fg">Read this chart, do not trade it</h3>
        <p className="mt-1 text-sm text-muted">
          Teaching only. No buy, sell, or hold. {quote.name} last close is a{" "}
          {quote.isBull ? "bull" : "bear"} print.
        </p>
      </div>
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          void run(question);
        }}
      >
        <Input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Ask about candles, stop-loss, trend…"
        />
        <Button type="submit" disabled={busy} className="shrink-0">
          {busy ? "Reading…" : "Explain"}
        </Button>
      </form>
      <div className="flex flex-wrap gap-2">
        {["What is the trend?", "Where is a beginner stop?", "Read the last candle."].map((q) => (
          <button
            key={q}
            type="button"
            className="rounded-full border border-border px-3 py-1 text-xs text-muted hover:text-fg"
            onClick={() => {
              setQuestion(q);
              void run(q);
            }}
          >
            {q}
          </button>
        ))}
      </div>
      {note ? <p className="text-xs text-muted">{note}. On-desk teaching notes below.</p> : null}
      {text ? (
        <div className="space-y-3 whitespace-pre-wrap text-sm leading-relaxed text-fg/90">{text}</div>
      ) : (
        <p className="text-sm text-muted">Ask a question or tap a prompt to open the desk.</p>
      )}
    </Card>
  );
}
