import { useCallback, useEffect, useState, type ReactNode } from "react";
import { Navigate, useRouterState } from "@tanstack/react-router";
import { isGateOpen, readGate } from "@/lib/gate/store";
import { useGate } from "@/hooks/use-gate";
import { AppShell } from "./app-shell";
import { Splash, markSplashSeen, splashSeen } from "./splash";

export function AppFrame({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const gate = useGate();
  const [phase, setPhase] = useState<"boot" | "splash" | "app">("boot");

  useEffect(() => {
    setPhase(splashSeen() ? "app" : "splash");
  }, []);

  const finishSplash = useCallback(() => {
    markSplashSeen();
    setPhase("app");
  }, []);

  if (phase === "boot") {
    return <div className="min-h-dvh bg-bg" />;
  }

  if (phase === "splash") {
    return <Splash onDone={finishSplash} />;
  }

  const open = isGateOpen(gate) || isGateOpen(readGate());
  if (!open && pathname !== "/gate") {
    return <Navigate to="/gate" />;
  }

  if (pathname === "/gate") {
    return <>{children}</>;
  }

  return <AppShell>{children}</AppShell>;
}
