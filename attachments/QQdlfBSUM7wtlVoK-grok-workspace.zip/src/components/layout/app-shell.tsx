import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, LineChart, Newspaper, PieChart, Radio } from "lucide-react";
import { cn } from "@/lib/utils";
import { useGate } from "@/hooks/use-gate";
import { LiveNews } from "./live-news";

const NAV = [
  { to: "/", label: "Home", icon: Newspaper },
  { to: "/markets", label: "Markets", icon: LineChart },
  { to: "/learn", label: "Learn", icon: BookOpen },
  { to: "/chart-gpt", label: "Chart GPT", icon: Radio },
  { to: "/analytics", label: "Analytics", icon: PieChart },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const gate = useGate();
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="font-display text-lg tracking-tight">
            PlanVista
          </Link>
          <nav className="ml-2 hidden items-center gap-1 md:flex">
            {NAV.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "rounded-md px-3 py-2 text-sm",
                    active ? "bg-surface-2 text-fg" : "text-muted hover:text-fg",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="ml-auto flex items-center gap-3">
            {gate.quizScore != null ? (
              <Link
                to="/gate"
                className={cn(
                  "rounded-full border border-border px-3 py-1 text-xs font-medium tabular-nums",
                  gate.quizPassed ? "text-bull" : "text-bear",
                )}
              >
                Risk {gate.quizScore}%
              </Link>
            ) : null}
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl px-4 py-6 pb-24">{children}</main>
      <footer className="border-t border-border px-4 py-6 text-center text-xs leading-relaxed text-subtle">
        Educational prototype only. Not SEBI-registered. Not a broker, investment adviser, or research analyst.
        Past performance is not a reliable indicator of future results. Capital is at risk.
      </footer>
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-bg/95 md:hidden">
        {NAV.map((item) => {
          const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-h-12 flex-col items-center justify-center gap-0.5 text-[10px]",
                active ? "text-fg" : "text-muted",
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <LiveNews />
    </div>
  );
}
