import { useEffect, useState } from "react";
import { useMarketBoard } from "@/hooks/use-market";
import { formatPct } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const SEEN = "planvista-splash-seen";

export function Splash({ onDone }: { onDone: () => void }) {
  const { data } = useMarketBoard();
  const isBull = data?.session.isBull ?? true;
  const leader = data?.session.leader;
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const started = Date.now();
    const dur = 5200;
    const id = window.setInterval(() => {
      const p = Math.min(100, ((Date.now() - started) / dur) * 100);
      setProgress(p);
      if (p >= 100) {
        window.clearInterval(id);
        sessionStorage.setItem(SEEN, "1");
        onDone();
      }
    }, 80);
    return () => window.clearInterval(id);
  }, [onDone]);

  return (
    <div className="fixed inset-0 z-50 bg-bg">
      <video
        key={isBull ? "bull" : "bear"}
        className="absolute inset-0 h-full w-full object-cover"
        autoPlay
        muted
        playsInline
        poster={isBull ? "/media/bull.jpg" : "/media/bear.jpg"}
      >
        <source src={isBull ? "/media/bull.mp4" : "/media/bear.mp4"} type="video/mp4" />
      </video>
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/20" />
      <div className="relative flex h-full flex-col justify-end gap-4 px-6 pb-10 sm:px-10">
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">PlanVista Finance</p>
        <h1 className="max-w-xl font-display text-4xl font-medium tracking-tight text-fg sm:text-5xl">
          {isBull ? "Bull session" : "Bear session"}
        </h1>
        <p className="max-w-lg text-sm text-muted">
          {leader
            ? `${leader.name} last print ${formatPct(leader.changePct)}. The animal follows the last close — it is not a trade.`
            : "Reading the last Nifty close to choose the opening animal."}
        </p>
        <div className="h-1 w-full max-w-sm overflow-hidden rounded-full bg-surface-2">
          <div
            className={isBull ? "h-full bg-bull" : "h-full bg-bear"}
            style={{ width: `${progress}%` }}
          />
        </div>
        <Button variant="outline" size="sm" className="w-fit bg-bg/80" onClick={onDone}>
          Skip
        </Button>
      </div>
    </div>
  );
}

export function splashSeen() {
  return typeof window !== "undefined" && sessionStorage.getItem(SEEN) === "1";
}

export function markSplashSeen() {
  sessionStorage.setItem(SEEN, "1");
}
