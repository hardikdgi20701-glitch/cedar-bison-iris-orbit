import { useState } from "react";
import { Maximize2, Minimize2, Radio, X } from "lucide-react";
import { cn } from "@/lib/utils";

const LIVE_ID = "i_1g_M0JSy4";

export function LiveNews() {
  const [mode, setMode] = useState<"chip" | "panel" | "hidden">("chip");
  if (mode === "hidden") return null;

  if (mode === "chip") {
    return (
      <button
        type="button"
        onClick={() => setMode("panel")}
        className="fixed right-4 bottom-4 z-40 flex h-12 items-center gap-2 rounded-full border border-border bg-surface px-4 text-sm text-fg shadow-lg"
      >
        <Radio className="size-4 text-bear" />
        CNBC Awaaz live
      </button>
    );
  }

  return (
    <div
      className={cn(
        "fixed right-3 bottom-3 z-40 overflow-hidden rounded-xl border border-border bg-surface shadow-2xl",
        "w-[min(100%-1.5rem,360px)]",
      )}
    >
      <div className="flex items-center justify-between gap-2 px-3 py-2">
        <p className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.14em] text-muted">
          <Radio className="size-3.5 text-bear" />
          CNBC Awaaz
        </p>
        <div className="flex items-center gap-1">
          <button type="button" className="rounded-md p-2 text-muted hover:text-fg" onClick={() => setMode("chip")} aria-label="Minimise">
            <Minimize2 className="size-4" />
          </button>
          <a
            className="rounded-md p-2 text-muted hover:text-fg"
            href={`https://www.youtube.com/watch?v=${LIVE_ID}`}
            target="_blank"
            rel="noreferrer"
            aria-label="Open on YouTube"
          >
            <Maximize2 className="size-4" />
          </a>
          <button type="button" className="rounded-md p-2 text-muted hover:text-fg" onClick={() => setMode("hidden")} aria-label="Close">
            <X className="size-4" />
          </button>
        </div>
      </div>
      <div className="aspect-video bg-bg">
        <iframe
          title="CNBC Awaaz live"
          className="h-full w-full"
          src={`https://www.youtube.com/embed/${LIVE_ID}?autoplay=0&rel=0`}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
      <p className="px-3 py-2 text-[11px] leading-snug text-subtle">
        Public YouTube live from @cnbcawaaz. Stream IDs change — open on YouTube if the embed is idle. News is not advice.
      </p>
    </div>
  );
}
