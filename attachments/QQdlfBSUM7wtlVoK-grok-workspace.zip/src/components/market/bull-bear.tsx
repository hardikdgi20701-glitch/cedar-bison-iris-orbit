import { cn } from "@/lib/utils";

export function BullBearMark({
  isBull,
  className,
  size = "md",
}: {
  isBull: boolean
  className?: string
  size?: "sm" | "md" | "lg"
}) {
  const dim = size === "lg" ? "h-16 w-16" : size === "sm" ? "h-8 w-8" : "h-11 w-11";
  return (
    <span
      className={cn(
        "relative inline-flex overflow-hidden rounded-md border border-border bg-surface-2",
        dim,
        className,
      )}
    >
      <video
        className="h-full w-full object-cover"
        autoPlay
        muted
        loop
        playsInline
        poster={isBull ? "/media/bull.jpg" : "/media/bear.jpg"}
        key={isBull ? "bull" : "bear"}
      >
        <source src={isBull ? "/media/bull.mp4" : "/media/bear.mp4"} type="video/mp4" />
      </video>
    </span>
  );
}

export function SessionLabel({ isBull, pct }: { isBull: boolean; pct?: number }) {
  return (
    <span className={cn("inline-flex items-center gap-2 text-sm font-medium", isBull ? "text-bull" : "text-bear")}>
      <BullBearMark isBull={isBull} size="sm" />
      <span>
        {isBull ? "Bull" : "Bear"}
        {pct != null ? ` ${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%` : ""}
      </span>
    </span>
  );
}
