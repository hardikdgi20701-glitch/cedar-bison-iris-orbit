import { cn } from "@/lib/utils";

export function Sparkline({
  data,
  isBull,
  className,
}: {
  data: number[]
  isBull: boolean
  className?: string
}) {
  if (!data.length) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const w = 120;
  const h = 36;
  const pts = data
    .map((v, i) => {
      const x = (i / Math.max(data.length - 1, 1)) * w;
      const y = h - ((v - min) / span) * h;
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={cn("h-9 w-28", className)} aria-hidden>
      <polyline
        fill="none"
        stroke={isBull ? "var(--color-bull)" : "var(--color-bear)"}
        strokeWidth="2"
        points={pts}
      />
    </svg>
  );
}
