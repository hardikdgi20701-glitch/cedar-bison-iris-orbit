import { Link } from "@tanstack/react-router";
import { formatInr, formatPct } from "@/lib/utils";
import type { Quote } from "@/lib/market/quotes";
import { Card } from "@/components/ui/card";
import { BullBearMark } from "./bull-bear";
import { Sparkline } from "./sparkline";
import { cn } from "@/lib/utils";

export function QuoteCard({ quote }: { quote: Quote }) {
  return (
    <Link to="/quote/$symbol" params={{ symbol: quote.id }} className="block">
      <Card className="flex items-center gap-3 p-3 transition-colors hover:bg-surface-2">
        <BullBearMark isBull={quote.isBull} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-fg">{quote.name}</p>
          <p className="text-xs text-muted">{quote.id} · {quote.sector}</p>
        </div>
        <Sparkline data={quote.spark} isBull={quote.isBull} className="hidden sm:block" />
        <div className="text-right">
          <p className="font-medium tabular-nums text-fg">
            {quote.kind === "index" ? quote.price.toFixed(2) : formatInr(quote.price)}
          </p>
          <p className={cn("text-xs tabular-nums", quote.isBull ? "text-bull" : "text-bear")}>
            {formatPct(quote.changePct)}
          </p>
        </div>
      </Card>
    </Link>
  );
}
