import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useMarketBoard } from "@/hooks/use-market";
import { useGate } from "@/hooks/use-gate";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { PASS_MARK } from "@/lib/gate/quiz";

export const Route = createFileRoute("/analytics")({ component: AnalyticsPage });

function AnalyticsPage() {
  const { data } = useMarketBoard();
  const gate = useGate();
  const quotes = data?.quotes ?? [];
  const breadth = useMemo(() => {
    const bull = quotes.filter((q) => q.isBull).length;
    const bear = quotes.length - bull;
    const avg = quotes.length ? quotes.reduce((s, q) => s + q.changePct, 0) / quotes.length : 0;
    const best = [...quotes].sort((a, b) => b.changePct - a.changePct)[0];
    const worst = [...quotes].sort((a, b) => a.changePct - b.changePct)[0];
    return { bull, bear, avg, best, worst };
  }, [quotes]);
  const bars = quotes.map((q) => ({ name: q.id, pct: Number(q.changePct.toFixed(2)), bull: q.isBull }));

  return (
    <div className="space-y-6">
      <header className="space-y-2">
        <h1 className="font-display text-3xl tracking-tight">Analytics</h1>
        <p className="text-sm text-muted">
          Breadth of this delayed board plus your stored risk-fitness percentage. Teaching stats, not a model portfolio.
        </p>
      </header>
      <div className="grid gap-3 sm:grid-cols-3">
        <Card>
          <p className="text-xs uppercase tracking-[0.14em] text-muted">Your risk score</p>
          <p className={cn("font-display text-4xl tabular-nums", (gate.quizScore ?? 0) >= PASS_MARK ? "text-bull" : "text-bear")}>
            {gate.quizScore ?? "—"}%
          </p>
          <p className="text-xs text-subtle">
            {gate.correctCount ?? "—"} / {gate.totalCount ?? "—"} on {gate.quizDate ?? "—"}
          </p>
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-[0.14em] text-muted">Bull vs bear</p>
          <p className="font-display text-4xl tabular-nums">
            <span className="text-bull">{breadth.bull}</span>
            <span className="text-muted"> / </span>
            <span className="text-bear">{breadth.bear}</span>
          </p>
          <p className="text-xs text-subtle">Names up vs down on this board</p>
        </Card>
        <Card>
          <p className="text-xs uppercase tracking-[0.14em] text-muted">Average move</p>
          <p className={cn("font-display text-4xl tabular-nums", breadth.avg >= 0 ? "text-bull" : "text-bear")}>
            {breadth.avg >= 0 ? "+" : ""}
            {breadth.avg.toFixed(2)}%
          </p>
          <p className="text-xs text-subtle">Equal-weight across listed names</p>
        </Card>
      </div>
      <Card className="p-4">
        <p className="mb-3 text-sm text-muted">Session change %</p>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={bars} margin={{ top: 8, right: 8, left: 0, bottom: 24 }}>
              <XAxis dataKey="name" tick={{ fill: "var(--color-muted)", fontSize: 10 }} interval={0} angle={-35} textAnchor="end" />
              <YAxis tick={{ fill: "var(--color-muted)", fontSize: 11 }} />
              <Tooltip
                contentStyle={{
                  background: "var(--color-surface)",
                  border: "1px solid var(--color-border)",
                  borderRadius: 12,
                }}
              />
              <Bar dataKey="pct" radius={[6, 6, 0, 0]}>
                {bars.map((b) => (
                  <Cell key={b.name} fill={b.bull ? "var(--color-bull)" : "var(--color-bear)"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      {breadth.best && breadth.worst ? (
        <p className="text-sm text-muted">
          Strongest print {breadth.best.name} ({breadth.best.changePct.toFixed(2)}%). Weakest {breadth.worst.name} (
          {breadth.worst.changePct.toFixed(2)}%). Still not a recommendation.
        </p>
      ) : null}
    </div>
  );
}
