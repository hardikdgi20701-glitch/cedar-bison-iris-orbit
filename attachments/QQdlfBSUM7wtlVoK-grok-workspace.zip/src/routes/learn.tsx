import { createFileRoute, Link } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/learn/articles";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/learn")({ component: LearnPage });

function LearnPage() {
  return (
    <div className="space-y-6">
      <header className="space-y-2">
        <h1 className="font-display text-3xl tracking-tight">Learn the market</h1>
        <p className="max-w-2xl text-sm text-muted">
          A beginner course: shares, indexes, demat, candles, stops, graphs, and SEBI. Read in order. Nothing here is a
          tip.
        </p>
      </header>
      <div className="grid gap-4 sm:grid-cols-2">
        {ARTICLES.map((a) => (
          <Link key={a.slug} to="/learn/$slug" params={{ slug: a.slug }} className="block">
            <Card className="h-full overflow-hidden p-0">
              <img src={a.image} alt="" className="h-40 w-full object-cover" />
              <div className="space-y-2 p-4">
                <p className="text-xs uppercase tracking-[0.14em] text-muted">
                  {a.level} · {a.minutes} min
                </p>
                <h2 className="font-display text-xl text-fg">{a.title}</h2>
                <p className="text-sm text-muted">{a.dek}</p>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
