import { createFileRoute, Link } from "@tanstack/react-router";
import { getArticle, neighbors } from "@/lib/learn/articles";

export const Route = createFileRoute("/learn/$slug")({ component: ArticlePage });

function ArticlePage() {
  const { slug } = Route.useParams();
  const article = getArticle(slug);
  const { prev, next } = neighbors(article.slug);
  return (
    <article className="mx-auto max-w-2xl space-y-8">
      <p className="text-xs uppercase tracking-[0.16em] text-muted">
        {article.level} · {article.minutes} min read
      </p>
      <h1 className="font-display text-4xl tracking-tight">{article.title}</h1>
      <p className="text-lg text-muted">{article.dek}</p>
      <img src={article.image} alt="" className="aspect-video w-full rounded-xl object-cover" />
      {article.sections.map((s) => (
        <section key={s.heading} className="space-y-3">
          <h2 className="font-display text-2xl">{s.heading}</h2>
          {s.body.map((p) => (
            <p key={p} className="text-[15px] leading-7 text-fg/90">
              {p}
            </p>
          ))}
        </section>
      ))}
      <section className="rounded-xl border border-border bg-surface p-5">
        <h2 className="font-display text-xl">Words to know</h2>
        <dl className="mt-3 space-y-3">
          {article.words.map((w) => (
            <div key={w.term}>
              <dt className="text-sm font-medium text-fg">{w.term}</dt>
              <dd className="text-sm text-muted">{w.def}</dd>
            </div>
          ))}
        </dl>
      </section>
      <section>
        <h2 className="font-display text-xl">Takeaways</h2>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-fg/90">
          {article.takeaways.map((t) => (
            <li key={t}>{t}</li>
          ))}
        </ul>
      </section>
      <p className="text-xs text-subtle">
        Education only. Not SEBI-registered advice. Do not treat this lesson as a recommendation.
      </p>
      <nav className="flex items-center justify-between gap-3 border-t border-border pt-4 text-sm">
        {prev ? (
          <Link to="/learn/$slug" params={{ slug: prev.slug }} className="text-muted hover:text-fg">
            ← {prev.title}
          </Link>
        ) : (
          <span />
        )}
        {next ? (
          <Link to="/learn/$slug" params={{ slug: next.slug }} className="text-muted hover:text-fg">
            {next.title} →
          </Link>
        ) : (
          <Link to="/learn" className="text-muted hover:text-fg">
            Course home
          </Link>
        )}
      </nav>
    </article>
  );
}
