import { createFileRoute, Link } from "@tanstack/react-router";
import { useMarketBoard } from "@/hooks/use-market";
import { useGate } from "@/hooks/use-gate";
import { QuoteCard } from "@/components/market/quote-card";
import { BullBearMark } from "@/components/market/bull-bear";
import { formatPct } from "@/lib/utils";
import { ARTICLES } from "@/lib/learn/articles";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { data, isLoading } = useMarketBoard();
  const gate = useGate();
  const session = data?.session;
  const indexes = data?.quotes.filter((q) => q.kind === "index") ?? [];
  const stocks = data?.quotes.filter((q) => q.kind === "stock") ?? [];

  return (
    <div className="space-y-8">
      <section className="overflow-hidden rounded-xl border border-border bg-surface">
        <div className="grid gap-0 md:grid-cols-[1.1fr_0.9fr]">
          <div className="space-y-4 p-6">
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Today’s session</p>
            <h1 className="font-display text-4xl tracking-tight">
              {session ? (session.isBull ? "Bull tape" : "Bear tape") : "Opening the tape"}
            </h1>
            <p className="max-w-md text-sm leading-relaxed text-muted">
              Hello {gate.name || "learner"}. The animal follows Nifty’s last close. Green is not a buy. Red is not a
              sell. Your risk-fitness score is{" "}
              <span className={cn("tabular-nums font-medium", (gate.quizScore ?? 0) >= 70 ? "text-bull" : "text-bear")}>
                {gate.quizScore ?? "—"}%
              </span>
              .
            </p>
            {session ? (
              <p className={cn("text-sm tabular-nums", session.isBull ? "text-bull" : "text-bear")}>
                {session.leader.name} {formatPct(session.leader.changePct)} ·{" "}
                {session.source === "live" ? "live delayed" : "refreshed simulation"}
              </p>
            ) : null}
          </div>
          <div className="relative min-h-48">
            {session ? (
              <video
                key={session.isBull ? "bull" : "bear"}
                className="absolute inset-0 h-full w-full object-cover"
                autoPlay
                muted
                loop
                playsInline
                poster={session.isBull ? "/media/bull.jpg" : "/media/bear.jpg"}
              >
                <source src={session.isBull ? "/media/bull.mp4" : "/media/bear.mp4"} type="video/mp4" />
              </video>
            ) : (
              <div className="h-full bg-surface-2" />
            )}
          </div>
        </div>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl">Indexes</h2>
          <Link to="/markets" className="text-sm text-muted hover:text-fg">
            All markets
          </Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          {isLoading
            ? Array.from({ length: 3 }).map((_, i) => <Card key={i} className="h-20 animate-pulse bg-surface-2" />)
            : indexes.map((q) => <QuoteCard key={q.id} quote={q} />)}
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-2xl">Watchlist</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {stocks.slice(0, 6).map((q) => <QuoteCard key={q.id} quote={q} />)}
        </div>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl">Start learning</h2>
          <Link to="/learn" className="text-sm text-muted hover:text-fg">
            Full course
          </Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {ARTICLES.slice(0, 4).map((a) => (
            <Link key={a.slug} to="/learn/$slug" params={{ slug: a.slug }} className="block">
              <Card className="overflow-hidden p-0">
                <img src={a.image} alt="" className="h-32 w-full object-cover" />
                <div className="space-y-1 p-4">
                  <p className="text-xs uppercase tracking-[0.14em] text-muted">{a.level}</p>
                  <p className="font-medium text-fg">{a.title}</p>
                  <p className="text-sm text-muted">{a.dek}</p>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <p className="flex items-center gap-2 text-xs text-subtle">
        <BullBearMark isBull={session?.isBull ?? true} size="sm" />
        Mascots describe the last print. They never place an order.
      </p>
    </div>
  );
}
