import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMarketBoard } from "@/hooks/use-market";
import { ChartGptPanel } from "@/components/chart/chart-gpt-panel";
import { PriceChart } from "@/components/chart/price-chart";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/chart-gpt")({ component: ChartGptPage });

function ChartGptPage() {
  const { data } = useMarketBoard();
  const quotes = data?.quotes ?? [];
  const [id, setId] = useState("NIFTY");
  const quote = useMemo(() => quotes.find((q) => q.id === id) ?? quotes[0], [quotes, id]);

  return (
    <div className="space-y-6">
      <header className="space-y-2">
        <p className="text-xs uppercase tracking-[0.16em] text-muted">CNBC Awaaz-style desk</p>
        <h1 className="font-display text-3xl tracking-tight">Chart GPT</h1>
        <p className="max-w-2xl text-sm text-muted">
          A teaching desk that reads candles, trend, and stops in plain language. It will not tell you to buy or sell.
          Pair it with the live Awaaz window in the corner — television is context, not a broker.
        </p>
      </header>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {quotes.map((q) => (
          <button
            key={q.id}
            type="button"
            onClick={() => setId(q.id)}
            className={cn(
              "shrink-0 rounded-full border px-3 py-1 text-xs",
              q.id === quote?.id ? "border-accent bg-surface-2 text-fg" : "border-border text-muted",
            )}
          >
            {q.id}
          </button>
        ))}
      </div>
      {quote ? (
        <>
          <Card className="p-4">
            <PriceChart quote={quote} />
          </Card>
          <ChartGptPanel quote={quote} />
        </>
      ) : (
        <Card className="h-64 animate-pulse bg-surface-2" />
      )}
    </div>
  );
}
