import { createFileRoute } from "@tanstack/react-router";
import { useQuote } from "@/hooks/use-market";
import { PriceChart } from "@/components/chart/price-chart";
import { ChartGptPanel } from "@/components/chart/chart-gpt-panel";
import { BullBearMark } from "@/components/market/bull-bear";
import { formatCompact, formatInr, formatPct } from "@/lib/utils";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/quote/$symbol")({ component: QuotePage });

function QuotePage() {
  const { symbol } = Route.useParams();
  const { data: quote, isLoading } = useQuote(symbol);
  if (isLoading || !quote) {
    return <Card className="h-80 animate-pulse bg-surface-2" />;
  }
  const price = quote.kind === "index" ? quote.price.toFixed(2) : formatInr(quote.price);
  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-start gap-4">
        <BullBearMark isBull={quote.isBull} size="lg" />
        <div className="min-w-0 flex-1">
          <p className="text-xs uppercase tracking-[0.16em] text-muted">{quote.sector}</p>
          <h1 className="font-display text-3xl tracking-tight">{quote.name}</h1>
          <p className="text-sm text-muted">{quote.id}</p>
        </div>
        <div className="text-right">
          <p className="font-display text-3xl tabular-nums">{price}</p>
          <p className={cn("text-sm tabular-nums", quote.isBull ? "text-bull" : "text-bear")}>
            {quote.isBull ? "Bull" : "Bear"} {formatPct(quote.changePct)}
          </p>
        </div>
      </header>
      <Card className="p-4">
        <PriceChart quote={quote} />
      </Card>
      <div className="grid gap-3 sm:grid-cols-4">
        {[
          ["Prev close", quote.kind === "index" ? quote.previousClose.toFixed(2) : formatInr(quote.previousClose)],
          ["High", quote.kind === "index" ? quote.high.toFixed(2) : formatInr(quote.high)],
          ["Low", quote.kind === "index" ? quote.low.toFixed(2) : formatInr(quote.low)],
          ["Volume", formatCompact(quote.volume)],
        ].map(([k, v]) => (
          <Card key={k} className="p-3">
            <p className="text-xs text-muted">{k}</p>
            <p className="tabular-nums text-fg">{v}</p>
          </Card>
        ))}
      </div>
      <ChartGptPanel quote={quote} />
    </div>
  );
}
