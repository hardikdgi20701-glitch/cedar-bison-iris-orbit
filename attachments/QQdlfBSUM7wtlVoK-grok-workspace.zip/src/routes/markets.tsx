import { createFileRoute } from "@tanstack/react-router";
import { useMarketBoard } from "@/hooks/use-market";
import { QuoteCard } from "@/components/market/quote-card";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/markets")({ component: MarketsPage });

function MarketsPage() {
  const { data, isLoading, dataUpdatedAt } = useMarketBoard();
  const quotes = data?.quotes ?? [];
  return (
    <div className="space-y-6">
      <header className="space-y-2">
        <h1 className="font-display text-3xl tracking-tight">Markets</h1>
        <p className="text-sm text-muted">
          Delayed public prints when the feed answers; otherwise a same-day simulation so the board still moves when you
          open the desk. Bull / bear follows the last close.
        </p>
        {dataUpdatedAt ? (
          <p className="text-xs text-subtle">Refreshed {new Date(dataUpdatedAt).toLocaleTimeString("en-IN")}</p>
        ) : null}
      </header>
      <div className="grid gap-3 md:grid-cols-2">
        {isLoading
          ? Array.from({ length: 8 }).map((_, i) => <Card key={i} className="h-20 animate-pulse bg-surface-2" />)
          : quotes.map((q) => <QuoteCard key={q.id} quote={q} />)}
      </div>
    </div>
  );
}
