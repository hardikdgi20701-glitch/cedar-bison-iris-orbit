import { useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { PASS_MARK, pickDailyQuiz, QUIZ_SIZE, scorePercent } from "@/lib/gate/quiz";
import { todayKey } from "@/lib/utils";
import { writeGate } from "@/lib/gate/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ScoreRing } from "@/components/score-ring";

export const Route = createFileRoute("/gate")({ component: GatePage });

type Step = "profile" | "docs" | "quiz" | "result";

function GatePage() {
  const navigate = useNavigate();
  const questions = useMemo(() => pickDailyQuiz(), []);
  const [step, setStep] = useState<Step>("profile");
  const [name, setName] = useState("");
  const [ageOk, setAgeOk] = useState(false);
  const [docName, setDocName] = useState<string | null>(null);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [correct, setCorrect] = useState(0);
  const [answered, setAnswered] = useState(0);
  const [locked, setLocked] = useState(false);
  const [finalPct, setFinalPct] = useState(0);

  const q = questions[index];
  const runningPct = answered === 0 ? 0 : scorePercent(correct, answered);
  const projected = scorePercent(correct + (QUIZ_SIZE - answered), QUIZ_SIZE);

  function finish(nextCorrect: number) {
    const pct = scorePercent(nextCorrect, QUIZ_SIZE);
    setFinalPct(pct);
    const passed = pct >= PASS_MARK;
    writeGate({
      name: name.trim(),
      ageConfirmed: true,
      documentName: docName,
      quizScore: pct,
      quizPassed: passed,
      quizDate: todayKey(),
      correctCount: nextCorrect,
      totalCount: QUIZ_SIZE,
    });
    setStep("result");
  }

  function submitAnswer() {
    if (picked == null || locked) return;
    setLocked(true);
    const isRight = picked === q.answer;
    const nextCorrect = correct + (isRight ? 1 : 0);
    const nextAnswered = answered + 1;
    setCorrect(nextCorrect);
    setAnswered(nextAnswered);
    window.setTimeout(() => {
      if (index + 1 >= QUIZ_SIZE) {
        finish(nextCorrect);
      } else {
        setIndex((i) => i + 1);
        setPicked(null);
        setLocked(false);
      }
    }, 650);
  }

  return (
    <div className="min-h-dvh bg-bg px-4 py-8 text-fg">
      <div className="mx-auto flex max-w-lg flex-col gap-6">
        <header className="space-y-2">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted">PlanVista gate</p>
          <h1 className="font-display text-3xl tracking-tight">18+ learning desk</h1>
          <p className="text-sm text-muted">
            Beginner quiz. Pass mark {PASS_MARK}%. Not a broker. Not SEBI-registered advice.
          </p>
        </header>

        {step === "profile" ? (
          <Card className="space-y-4 p-5">
            <label className="block space-y-2 text-sm">
              <span className="text-muted">Your name</span>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="As you want it on the desk" />
            </label>
            <label className="flex items-start gap-3 text-sm leading-relaxed text-muted">
              <input
                type="checkbox"
                className="mt-1 size-4 accent-accent"
                checked={ageOk}
                onChange={(e) => setAgeOk(e.target.checked)}
              />
              I confirm I am 18 or older. Indian securities markets are not a game for minors.
            </label>
            <Button
              className="w-full"
              disabled={!name.trim() || !ageOk}
              onClick={() => setStep("docs")}
            >
              Continue
            </Button>
          </Card>
        ) : null}

        {step === "docs" ? (
          <Card className="space-y-4 p-5">
            <h2 className="font-display text-xl">Mock document check</h2>
            <p className="text-sm text-muted">
              A real broker needs PAN and KYC. This prototype only records a filename on your device. Do not upload
              genuine ID cards here.
            </p>
            <Input
              type="file"
              accept=".pdf,image/*"
              onChange={(e) => setDocName(e.target.files?.[0]?.name ?? null)}
            />
            <Button type="button" variant="outline" className="w-full" onClick={() => setDocName("demo-pan-card.pdf")}>
              Attach demo PAN (filename only, nothing is uploaded)
            </Button>
            {docName ? <p className="text-sm text-fg">Attached: {docName}</p> : null}
            <Button className="w-full" disabled={!docName} onClick={() => setStep("quiz")}>
              Start today’s quiz
            </Button>
          </Card>
        ) : null}

        {step === "quiz" && q ? (
          <Card className="space-y-5 p-5">
            <div className="flex items-end justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-muted">
                  Question {index + 1} of {QUIZ_SIZE}
                </p>
                <p className="text-sm text-muted">Daily paper · {todayKey()}</p>
              </div>
              <div className="text-right">
                <p className="font-display text-3xl tabular-nums leading-none text-fg">{runningPct}%</p>
                <p className="text-[11px] uppercase tracking-[0.14em] text-muted">Running score</p>
              </div>
            </div>
            <Progress value={((index + (locked ? 1 : 0)) / QUIZ_SIZE) * 100} />
            <p className="text-xs text-subtle">
              {answered === 0
                ? `Need ${PASS_MARK}% (${Math.ceil((PASS_MARK / 100) * QUIZ_SIZE)} of ${QUIZ_SIZE}) to enter.`
                : `If you ace the rest, max score is ${projected}%.`}
            </p>
            {q.context ? <p className="text-sm text-muted">{q.context}</p> : null}
            <h2 className="font-display text-2xl leading-snug">{q.prompt}</h2>
            <div className="space-y-2">
              {q.options.map((opt, i) => {
                const show = locked;
                const right = i === q.answer;
                const mine = i === picked;
                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={locked}
                    onClick={() => setPicked(i)}
                    className={`w-full rounded-lg border px-3 py-3 text-left text-sm leading-relaxed ${
                      show && right
                        ? "border-bull bg-bull/10 text-fg"
                        : show && mine && !right
                          ? "border-bear bg-bear/10 text-fg"
                          : mine
                            ? "border-accent bg-surface-2 text-fg"
                            : "border-border text-muted hover:text-fg"
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
            {locked ? <p className="text-sm text-muted">{q.why}</p> : null}
            <Button className="w-full" disabled={picked == null || locked} onClick={submitAnswer}>
              {index + 1 === QUIZ_SIZE ? "See my percentage" : "Lock answer"}
            </Button>
          </Card>
        ) : null}

        {step === "result" ? (
          <Card className="space-y-5 p-5 text-center">
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Your risk-fitness score</p>
            <ScoreRing percent={finalPct} />
            <p className="text-sm text-muted">
              {correct} of {QUIZ_SIZE} correct · pass mark {PASS_MARK}% · score {finalPct}%
            </p>
            {finalPct >= PASS_MARK ? (
              <>
                <p className="text-sm text-fg">
                  Welcome, {name.trim()}. Your risk-fitness score is stored on this device and shown in the header.
                </p>
                <Button className="w-full" onClick={() => navigate({ to: "/" })}>
                  Enter the desk
                </Button>
              </>
            ) : (
              <>
                <p className="text-sm text-fg">
                  Score {finalPct}% is below {PASS_MARK}%. Read a starter lesson, then retry today’s paper. The desk stays
                  closed until you clear the mark.
                </p>
                <Button
                  className="w-full"
                  variant="outline"
                  onClick={() => {
                    setStep("quiz");
                    setIndex(0);
                    setPicked(null);
                    setCorrect(0);
                    setAnswered(0);
                    setLocked(false);
                    setFinalPct(0);
                  }}
                >
                  Retry quiz
                </Button>
              </>
            )}
          </Card>
        ) : null}
      </div>
    </div>
  );
}
