export type Article = {
  slug: string
  title: string
  dek: string
  minutes: number
  image: string
  level: "Start here" | "Charts" | "Rules"
  sections: { heading: string; body: string[] }[]
  words: { term: string; def: string }[]
  takeaways: string[]
}

export const ARTICLES: Article[] = [
  {
    slug: "what-is-a-share",
    title: "What is a share?",
    dek: "A share is a thin slice of a real company — not a lottery ticket.",
    minutes: 6,
    image: "/media/share.jpg",
    level: "Start here",
    sections: [
      {
        heading: "The simple picture",
        body: [
          "When a company needs money to grow, it can sell pieces of itself. Each piece is a share. If you own one share of a company that has issued 100 shares, you own 1% of that company.",
          "You do not sit in the boardroom. You do not run the factory. You own a claim on whatever value the market assigns to that slice, and sometimes a dividend if the company pays one.",
        ],
      },
      {
        heading: "A rupee example",
        body: [
          "Suppose a company is valued at ₹1,00,000 and has 1,000 shares. Each share is notionally ₹100. If you buy 10 shares, you have put ₹1,000 at risk. If the market later values the company at ₹90,000, your slice is worth ₹900. Nobody rings a bell to refund the ₹100.",
          "That is the whole game in one paragraph: price is an agreement between buyers and sellers today, not a promise about tomorrow.",
        ],
      },
      {
        heading: "What you are not buying",
        body: [
          "You are not buying a fixed deposit. You are not buying a SEBI guarantee. You are not buying a TV anchor’s confidence. You are buying a tradable claim that can go sideways for years.",
        ],
      },
    ],
    words: [
      { term: "Share / equity", def: "A unit of ownership in a company." },
      { term: "Market cap", def: "Share price × number of shares. A rough size tag, not a quality score." },
      { term: "Dividend", def: "A cash payout some companies share with owners. Optional, not owed." },
    ],
    takeaways: [
      "A share is ownership, not a voucher for profit.",
      "Price can fall. Capital is at risk.",
      "Start with companies you can explain in one sentence.",
    ],
  },
  {
    slug: "nifty-sensex",
    title: "Nifty & Sensex",
    dek: "The two scoreboards every Indian screen starts with.",
    minutes: 5,
    image: "/media/desk.jpg",
    level: "Start here",
    sections: [
      {
        heading: "What an index is",
        body: [
          "Nifty 50 and Sensex are not companies. They are baskets. Nifty tracks 50 large companies on the NSE. Sensex tracks 30 on the BSE. When people say “the market was green”, they usually mean these scoreboards closed higher.",
        ],
      },
      {
        heading: "How to read the number",
        body: [
          "If Nifty moves from 24,700 to 24,800, the basket is up about 0.4% that day. It does not mean every stock inside it was up. A bank can be red while an IT name is green and the index still prints a bull day.",
          "You cannot buy “Nifty” as a single share. Beginners who want index exposure usually use an index mutual fund or ETF — after they understand costs and tracking.",
        ],
      },
    ],
    words: [
      { term: "Index", def: "A calculated average of member stocks. A map, not a stock." },
      { term: "ETF", def: "A fund that trades like a share and often tracks an index." },
    ],
    takeaways: [
      "Index = basket scoreboard.",
      "A green Nifty is not a buy alarm on every name.",
      "Learn the index before you chase a tip on a small stock.",
    ],
  },
  {
    slug: "demat-first-order",
    title: "Demat, trading account & first order",
    dek: "The locker, the counter, and the ticket you actually send.",
    minutes: 7,
    image: "/media/demat.jpg",
    level: "Start here",
    sections: [
      {
        heading: "Two accounts, one person",
        body: [
          "A demat account holds shares electronically — it is the locker. A trading account is how you send buy and sell orders — it is the counter. KYC (PAN, address, bank) links them to you. This prototype never stores those documents; a real broker must.",
        ],
      },
      {
        heading: "A first order, slowly",
        body: [
          "You pick a stock, a quantity, and a price type. A market order says “fill me at whatever is available now”. A limit order says “only at this price or better”. Beginners get hurt by mashing market orders in thin stocks.",
          "After a buy fills, shares credit to demat (usually T+1 in the current cycle). After a sell fills, money credits to your linked ledger as per settlement. None of this is instant magic.",
        ],
      },
    ],
    words: [
      { term: "KYC", def: "Know Your Customer — identity checks required by regulation." },
      { term: "Limit order", def: "You name the worst price you will accept." },
      { term: "Market order", def: "You accept the price the book has right now." },
    ],
    takeaways: [
      "Demat = locker. Trading = counter.",
      "Prefer limit orders until you know the stock’s spread.",
      "Never upload real KYC to a learning prototype.",
    ],
  },
  {
    slug: "sip-basics",
    title: "SIP, the boring superpower",
    dek: "A fixed amount, on a schedule, without a speech about genius.",
    minutes: 5,
    image: "/media/sip.jpg",
    level: "Start here",
    sections: [
      {
        heading: "What it does",
        body: [
          "A Systematic Investment Plan puts the same rupee amount into a fund on a calendar. Some units are bought when prices are high, some when low. You are buying a habit, not a jackpot.",
          "SIP does not remove risk. A fund of shares can still fall. What it removes is the need to guess the one perfect Tuesday.",
        ],
      },
      {
        heading: "Rupee example",
        body: [
          "₹2,000 every month for a year is ₹24,000 of capital at work — not ₹24,000 of guaranteed value. If the fund’s NAV drops 10%, that slice is worth less. If it rises 10%, it is worth more. The SIP did not change the nature of equity.",
        ],
      },
    ],
    words: [
      { term: "NAV", def: "Net asset value — the per-unit price of a mutual fund." },
      { term: "Rupee-cost averaging", def: "Buying a fixed rupee amount through ups and downs." },
    ],
    takeaways: [
      "SIP is a schedule, not a shield.",
      "Use money that can stay invested.",
      "Read the fund’s mandate before the return chart.",
    ],
  },
  {
    slug: "candles",
    title: "How to read a candle",
    dek: "Open, high, low, close — four numbers, one picture.",
    minutes: 8,
    image: "/media/candles.jpg",
    level: "Charts",
    sections: [
      {
        heading: "The four prices",
        body: [
          "Each candle is a session compressed: where it opened (O), the highest print (H), the lowest print (L), and where it closed (C). The thick part is the body (open to close). The thin lines are wicks — prices that traded and got rejected.",
        ],
      },
      {
        heading: "Green and red",
        body: [
          "On this site a green / bull candle means close ≥ open. A red / bear candle means close < open. Colour is a shortcut for “did the session finish higher than it started?”, not a moral judgement and not a buy signal.",
          "A long lower wick says buyers stepped in after a dip. A long upper wick says sellers capped a rally. One candle is a sentence. A trend is a paragraph. Do not trade a sentence.",
        ],
      },
      {
        heading: "Timeframe",
        body: [
          "A 5-minute candle and a weekly candle use the same grammar with different meaning. Beginners should live on daily candles until the vocabulary is boring.",
        ],
      },
    ],
    words: [
      { term: "OHLC", def: "Open, high, low, close." },
      { term: "Wick / shadow", def: "The thin line beyond the body." },
      { term: "Doji", def: "Open and close almost equal — indecision, not a prophecy." },
    ],
    takeaways: [
      "Body = open vs close. Wicks = rejected prices.",
      "Colour describes the bar, not your next order.",
      "Read several candles together before you invent a story.",
    ],
  },
  {
    slug: "stop-loss-targets",
    title: "Stop-loss, target, buy & sell",
    dek: "Decide the exit before the excitement.",
    minutes: 7,
    image: "/media/stoploss.jpg",
    level: "Charts",
    sections: [
      {
        heading: "Buy and sell are just tickets",
        body: [
          "A buy is an order to own more. A sell is an order to own less (or to close a short, which beginners should leave alone). Neither ticket is “right” because a TV panel shouted it.",
        ],
      },
      {
        heading: "Stop-loss",
        body: [
          "A stop-loss is the price where you admit the idea is wrong. Example: you buy at ₹100 because you believe ₹95 should not break. You place a stop under ₹95. If it breaks, you leave. The stop is a plan for a maximum loss — in a gap, you may get a worse fill.",
        ],
      },
      {
        heading: "Target",
        body: [
          "A target is where you planned to take profit if the idea works — say ₹112. Professionals pre-define both sides. Beginners often skip the stop and then negotiate with hope. Hope is not a risk system.",
        ],
      },
    ],
    words: [
      { term: "Stop-loss", def: "A pre-decided exit if price goes against you." },
      { term: "Target", def: "A pre-decided zone to reduce or exit if price goes for you." },
      { term: "Gap", def: "Price opening far from the last close. Stops may slip." },
    ],
    takeaways: [
      "Write stop and target before you click buy.",
      "A stop is a plan, not a guaranteed price.",
      "If you cannot name the invalidation, you do not have a trade.",
    ],
  },
  {
    slug: "how-to-read-graphs",
    title: "How to read graphs & market stats",
    dek: "Axes, volume, and the numbers around the chart.",
    minutes: 8,
    image: "/media/desk.jpg",
    level: "Charts",
    sections: [
      {
        heading: "The graph itself",
        body: [
          "Time runs left to right. Price runs up and down. A line chart shows closes only. A candle chart shows the fight inside each session. Zoom out before you zoom in — a pretty 3-day rally can still be a downtrend on the weekly.",
        ],
      },
      {
        heading: "Volume",
        body: [
          "Volume is how much actually traded. A breakout on empty volume is a whisper. A breakout on heavy volume is a crowd. Volume does not tell you what happens next; it tells you whether anyone showed up.",
        ],
      },
      {
        heading: "Stats around the chart",
        body: [
          "Previous close, day high/low, 52-week high/low, PE, and delivery percentage are context. PE is price versus earnings — high is not automatically “bad”, low is not automatically “cheap”. Delivery % hints at whether trades were taken home or squared off. None of these is a buy button.",
        ],
      },
    ],
    words: [
      { term: "Support", def: "A zone where buyers have repeatedly shown up." },
      { term: "Resistance", def: "A zone where sellers have repeatedly shown up." },
      { term: "PE", def: "Price divided by earnings. A ratio, not a verdict." },
    ],
    takeaways: [
      "Read left to right, then high to low, then volume.",
      "Stats explain the picture; they do not place the order.",
      "If you cannot explain the axis, you are not reading the graph yet.",
    ],
  },
  {
    slug: "bull-vs-bear",
    title: "Bull vs bear",
    dek: "The animals are shorthand for last direction — not a personality test.",
    minutes: 5,
    image: "/media/bull.jpg",
    level: "Charts",
    sections: [
      {
        heading: "On this site",
        body: [
          "If the last trade versus the previous close is green, we show the bull. If it is red, we show the bear. The opening animation follows Nifty’s last close the same way: a charging bull on an up session, a stomping bear on a down session.",
        ],
      },
      {
        heading: "In market language",
        body: [
          "A bull market is a long stretch of higher highs. A bear market is a long stretch of lower lows. One green day is not a bull market. One red week is not the end of equity as an asset class. Do not let a mascot talk you into a position.",
        ],
      },
    ],
    words: [
      { term: "Bullish", def: "Expecting or observing upward pressure." },
      { term: "Bearish", def: "Expecting or observing downward pressure." },
    ],
    takeaways: [
      "Bull = last move up. Bear = last move down.",
      "Mascots describe. They do not advise.",
      "Trend is many sessions, not one print.",
    ],
  },
  {
    slug: "beginner-mistakes",
    title: "Ten beginner mistakes",
    dek: "The expensive lessons, listed before you pay tuition to the market.",
    minutes: 7,
    image: "/media/mistakes.jpg",
    level: "Rules",
    sections: [
      {
        heading: "The list",
        body: [
          "1. Trading with rent money. 2. Copying a tip without a stop. 3. Averaging a falling knife because “it will come back”. 4. Confusing a green candle with a research report. 5. Watching live TV as if it were a personal advisor.",
          "6. Ignoring costs (brokerage, taxes, slippage). 7. Checking prices every four minutes. 8. Using leverage before you can explain a plain cash trade. 9. Treating past returns as a contract. 10. Skipping the regulator’s basic investor pages.",
        ],
      },
      {
        heading: "A better first year",
        body: [
          "Build an emergency buffer. Learn one index. Run a tiny SIP you can forget. Read candles as language, not as spells. Keep a paper journal of why you would buy — and the price that would prove you wrong.",
        ],
      },
    ],
    words: [
      { term: "Leverage", def: "Borrowed exposure. Losses grow as fast as gains." },
      { term: "Slippage", def: "The difference between the price you hoped for and the fill you got." },
    ],
    takeaways: [
      "Most pain is process, not a missing indicator.",
      "Small size is a feature.",
      "If it needs a hot take, it is probably not a first trade.",
    ],
  },
  {
    slug: "sebi-basics",
    title: "SEBI guidelines, in practice",
    dek: "The regulator’s job, and what this prototype is allowed to be.",
    minutes: 6,
    image: "/media/sebi.jpg",
    level: "Rules",
    sections: [
      {
        heading: "What SEBI is",
        body: [
          "The Securities and Exchange Board of India regulates the securities market: exchanges, brokers, mutual funds, and who may call themselves an investment adviser or research analyst. It exists so that a tip and a regulated product are not the same thing.",
        ],
      },
      {
        heading: "What this site must say",
        body: [
          "PlanVista Finance is an educational prototype. It is not registered with SEBI as a broker, investment adviser, or research analyst. Nothing here is a recommendation to buy, sell, or hold any security. Market snapshots may be delayed or simulated when a live feed is unavailable.",
          "A real investing setup needs a SEBI-registered intermediary, completed KYC, and documents you should never paste into a demo. Past performance is not a reliable indicator of future results. Equity can go to zero.",
        ],
      },
    ],
    words: [
      { term: "Investment adviser", def: "A person/entity registered to give personalised advice for a fee." },
      { term: "Research analyst", def: "A registered role for published research — not a YouTube comment.", },
    ],
    takeaways: [
      "Education ≠ advice.",
      "Check registration before you follow anyone with your money.",
      "If a product cannot show its licence, walk away.",
    ],
  },
];

export function getArticle(slug: string) {
  return ARTICLES.find((a) => a.slug === slug) ?? ARTICLES[0];
}

export function neighbors(slug: string) {
  const i = ARTICLES.findIndex((a) => a.slug === slug);
  return {
    prev: i > 0 ? ARTICLES[i - 1] : null,
    next: i >= 0 && i < ARTICLES.length - 1 ? ARTICLES[i + 1] : null,
  };
}
