import { createServerFn } from "@tanstack/react-start";
import type { Quote } from "@/lib/market/quotes";

export type ChartGptResult =
  | { ok: true; text: string }
  | { ok: false; error: string; text: string }

function localDesk(quote: Quote, question: string): string {
  const tone = quote.isBull ? "bull session" : "bear session";
  const last = quote.candles[quote.candles.length - 1];
  const prev = quote.candles[quote.candles.length - 2];
  const body = last && prev ? (last.c >= last.o ? "green candle" : "red candle") : "last candle";
  const range = last ? `high ${last.h.toFixed(1)} / low ${last.l.toFixed(1)}` : "the recent range";
  return [
    `Chart GPT desk — teaching note on ${quote.name} (${quote.id}).`,
    `Last print is a ${tone}: ${quote.changePct >= 0 ? "+" : ""}${quote.changePct.toFixed(2)}% versus the previous close. That is a description of the last move, not a buy or sell call.`,
    `The most recent daily bar is a ${body}. Read it as open → high → low → close. Wicks are the rejected prices; the body is where the session actually opened and closed.`,
    `Use ${range} as a simple map of today's battlefield. A beginner stop-loss sits beyond a level you would no longer want the trade if it breaks — it is a plan, not a promise of that exact fill.`,
    question.trim()
      ? `On your question (“${question.trim()}”): look at trend (higher highs vs lower lows), then volume, then whether the last close is near the high or the low of the bar. Do not stack rent money into a position because a candle is green.`
      : `Ask a specific question about this chart — trend, support, a candle, or a stop — and we will walk the picture, not pick a stock.`,
    `SEBI reminder: this is education. PlanVista is not a research analyst, not a broker, and not investment advice.`,
  ].join("\n\n");
}

export const askChartGpt = createServerFn({ method: "POST" })
  .validator((input: { quote: Quote; question: string }) => input)
  .handler(async ({ data }): Promise<ChartGptResult> => {
    const fallback = localDesk(data.quote, data.question);
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: true, text: fallback };
    }
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          max_tokens: 500,
          temperature: 0.4,
          messages: [
            {
              role: "system",
              content:
                "You are Chart GPT on an educational Indian-market desk in the style of a calm CNBC Awaaz explainer. Teach candles, trend, support/resistance, stop-loss and targets in plain language. Never give a buy, sell, or hold recommendation. Never pick a stock as a tip. Always state that this is education, not SEBI-registered advice. Use INR context. Keep under 220 words.",
            },
            {
              role: "user",
              content: JSON.stringify({
                question: data.question || "Explain this chart to a complete beginner.",
                snapshot: {
                  name: data.quote.name,
                  id: data.quote.id,
                  price: data.quote.price,
                  changePct: data.quote.changePct,
                  isBull: data.quote.isBull,
                  high: data.quote.high,
                  low: data.quote.low,
                  lastCandles: data.quote.candles.slice(-8),
                },
              }),
            },
          ],
        }),
      });
      if (!res.ok) return { ok: false, error: "Live desk is on local notes today", text: fallback };
      const body = (await res.json()) as {
        choices?: Array<{ message?: { content?: string } }>
      };
      const text = body.choices?.[0]?.message?.content?.trim();
      return { ok: true, text: text || fallback };
    } catch {
      return { ok: false, error: "Desk unreachable", text: fallback };
    }
  });
