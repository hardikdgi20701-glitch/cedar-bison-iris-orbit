import { hashString, todayKey } from "@/lib/utils";

export type QuizQuestion = {
  id: string
  prompt: string
  context?: string
  options: string[]
  answer: number
  why: string
}

const BANK: QuizQuestion[] = [
  {
    id: "lose-money",
    prompt: "If you buy a share, what can happen to your money?",
    context: "A first-day fact every new investor must accept.",
    options: [
      "The exchange guarantees you a profit after 1 year",
      "You can lose some or all of the money you invested",
      "SEBI will refund losses if the stock falls",
      "A green day means your capital is locked in as profit",
    ],
    answer: 1,
    why: "Shares have no guaranteed return. Price can fall. Only invest money you can afford to keep at risk.",
  },
  {
    id: "sip",
    prompt: "What is a SIP, in plain words?",
    options: [
      "A loan from the broker to buy more shares",
      "A one-time lump-sum bet on a hot stock",
      "Investing a fixed amount on a schedule, usually into a mutual fund",
      "A government bonus paid when Nifty is green",
    ],
    answer: 2,
    why: "A Systematic Investment Plan puts a fixed sum in at regular intervals. It is a habit, not a promise of profit.",
  },
  {
    id: "bull-green",
    prompt: "A stock’s last trade is shown in green with a bull mark. What does that mean?",
    options: [
      "You should buy it immediately",
      "The last move was up versus the previous close — not a buy call",
      "The company cannot report a loss this quarter",
      "SEBI has certified the stock as safe",
    ],
    answer: 1,
    why: "Green / bull only describes the last price move. It is not advice to buy, hold, or sell.",
  },
  {
    id: "rent-money",
    prompt: "Which money should stay out of the stock market?",
    options: [
      "Money already sitting in a 5-year goal fund",
      "A small amount you can leave untouched for years",
      "Next month’s rent, fees, or emergency cash",
      "A long-term SIP you started after building an emergency buffer",
    ],
    answer: 2,
    why: "Near-term living costs and emergency money do not belong in shares. Markets can stay down longer than a rent cycle.",
  },
  {
    id: "past-returns",
    prompt: "A fund card shows “+18% last year”. What is the honest reading?",
    options: [
      "You will also earn 18% this year",
      "Past returns are a record of the past, not a promise",
      "SEBI requires the same return next year",
      "The number is a guaranteed bank-like interest rate",
    ],
    answer: 1,
    why: "Past performance is not a guide to future results. That line exists in every SEBI-mandated disclaimer for a reason.",
  },
  {
    id: "sebi",
    prompt: "What is SEBI’s role in the Indian market?",
    options: [
      "It picks winning stocks for retail investors",
      "It is the market regulator — it writes and enforces the rules",
      "It pays compensation when Nifty falls 2%",
      "It runs every brokerage’s trading app",
    ],
    answer: 1,
    why: "The Securities and Exchange Board of India regulates markets and intermediaries. It does not give stock tips.",
  },
  {
    id: "stop-loss",
    prompt: "What is a stop-loss, for a beginner?",
    options: [
      "A bonus the broker pays if you lose money",
      "A planned exit price so a loss cannot run without a decision",
      "A way to buy more shares as the price falls",
      "A SEBI rule that blocks all selling",
    ],
    answer: 1,
    why: "A stop-loss is your pre-decided “this is enough” price. It does not guarantee that exact fill in a fast market.",
  },
  {
    id: "demat",
    prompt: "Where do the shares you buy actually sit?",
    options: [
      "As paper certificates in your wallet",
      "Inside the trading app’s chat window",
      "In a demat account in your name, held electronically",
      "At SEBI headquarters until you sell",
    ],
    answer: 2,
    why: "Indian shares are electronic. A demat account is the locker; a trading account is the counter you use to place orders.",
  },
  {
    id: "index",
    prompt: "Nifty 50 is best described as…",
    options: [
      "A single company you can buy by name “Nifty”",
      "A basket that tracks 50 large Indian companies",
      "A government savings scheme with fixed interest",
      "A private tip sheet from a TV channel",
    ],
    answer: 1,
    why: "An index is a scoreboard for a group of stocks. You cannot buy the index itself; you buy a fund or the members.",
  },
  {
    id: "advice",
    prompt: "A learning site explains candles and shows a live TV feed. Is that a buy or sell order?",
    options: [
      "Yes — if the screen is green you must buy",
      "Yes — Chart GPT is a SEBI-registered advisor",
      "No. Education and news are not personalised investment advice",
      "Only if your quiz score is above 70%",
    ],
    answer: 2,
    why: "PlanVista is an educational prototype. It is not a broker, not a research analyst, and not investment advice.",
  },
];

export const QUIZ_SIZE = 7;
export const PASS_MARK = 70;

export function pickDailyQuiz(date = new Date()): QuizQuestion[] {
  const key = todayKey(date);
  const seed = hashString(`planvista-quiz-${key}`);
  const rest = BANK.filter((q) => q.id !== "lose-money");
  const shuffled = [...rest];
  let s = seed;
  for (let i = shuffled.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) >>> 0;
    const j = s % (i + 1);
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  const lose = BANK.find((q) => q.id === "lose-money");
  const picked = [lose!, ...shuffled.slice(0, QUIZ_SIZE - 1)];
  return picked;
}

export function scorePercent(correct: number, total = QUIZ_SIZE) {
  if (total <= 0) return 0;
  return Math.round((correct / total) * 100);
}

export function passes(percent: number) {
  return percent >= PASS_MARK;
}
