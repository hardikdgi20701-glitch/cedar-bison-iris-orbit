import { todayKey } from "@/lib/utils";

const KEY = "planvista-gate-v1";

export type GateRecord = {
  name: string
  ageConfirmed: boolean
  documentName: string | null
  quizScore: number | null
  quizPassed: boolean
  quizDate: string | null
  correctCount: number | null
  totalCount: number | null
}

const empty: GateRecord = {
  name: "",
  ageConfirmed: false,
  documentName: null,
  quizScore: null,
  quizPassed: false,
  quizDate: null,
  correctCount: null,
  totalCount: null,
};

export function readGate(): GateRecord {
  if (typeof window === "undefined") return empty;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return empty;
    return { ...empty, ...(JSON.parse(raw) as Partial<GateRecord>) };
  } catch {
    return empty;
  }
}

export function writeGate(patch: Partial<GateRecord>) {
  const next = { ...readGate(), ...patch };
  window.localStorage.setItem(KEY, JSON.stringify(next));
  window.dispatchEvent(new Event("planvista-gate"));
  return next;
}

export function clearGate() {
  window.localStorage.removeItem(KEY);
  window.dispatchEvent(new Event("planvista-gate"));
}

export function isGateOpen(record: GateRecord = readGate()) {
  return Boolean(record.quizPassed && record.ageConfirmed && record.name.trim());
}

export function quizIsForToday(record: GateRecord = readGate()) {
  return record.quizDate === todayKey();
}
