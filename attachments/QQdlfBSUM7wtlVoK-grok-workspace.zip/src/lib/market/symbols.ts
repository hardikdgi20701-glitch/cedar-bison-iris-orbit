export type MarketKind = "index" | "stock"

export type SymbolDef = {
  id: string
  yahoo: string
  name: string
  kind: MarketKind
  sector: string
}

export const SYMBOLS: SymbolDef[] = [
  { id: "NIFTY", yahoo: "^NSEI", name: "Nifty 50", kind: "index", sector: "Index" },
  { id: "SENSEX", yahoo: "^BSESN", name: "Sensex", kind: "index", sector: "Index" },
  { id: "BANKNIFTY", yahoo: "^NSEBANK", name: "Bank Nifty", kind: "index", sector: "Index" },
  { id: "RELIANCE", yahoo: "RELIANCE.NS", name: "Reliance", kind: "stock", sector: "Energy" },
  { id: "TCS", yahoo: "TCS.NS", name: "TCS", kind: "stock", sector: "IT" },
  { id: "HDFCBANK", yahoo: "HDFCBANK.NS", name: "HDFC Bank", kind: "stock", sector: "Banking" },
  { id: "INFY", yahoo: "INFY.NS", name: "Infosys", kind: "stock", sector: "IT" },
  { id: "ICICIBANK", yahoo: "ICICIBANK.NS", name: "ICICI Bank", kind: "stock", sector: "Banking" },
  { id: "ITC", yahoo: "ITC.NS", name: "ITC", kind: "stock", sector: "FMCG" },
  { id: "SBIN", yahoo: "SBIN.NS", name: "SBI", kind: "stock", sector: "Banking" },
  { id: "BHARTI", yahoo: "BHARTIARTL.NS", name: "Bharti Airtel", kind: "stock", sector: "Telecom" },
  { id: "LT", yahoo: "LT.NS", name: "Larsen & Toubro", kind: "stock", sector: "Infra" },
];

export function findSymbol(id: string) {
  const key = id.toUpperCase();
  return SYMBOLS.find((s) => s.id === key || s.yahoo === key) ?? SYMBOLS[0];
}
