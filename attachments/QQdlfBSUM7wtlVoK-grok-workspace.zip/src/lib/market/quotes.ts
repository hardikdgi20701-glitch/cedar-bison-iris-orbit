import { createServerFn } from "@tanstack/react-start";
import { hashString, todayKey } from "@/lib/utils";
import { SYMBOLS, findSymbol, type SymbolDef } from "./symbols";

export type Quote = {
  id: string
  yahoo: string
  name: string
  kind: SymbolDef["kind"]
  sector: string
  price: number
  previousClose: number
  change: number
  changePct: number
  high: number
  low: number
  volume: number
  spark: number[]
  candles: Candle[]
  isBull: boolean
  source: "live" | "delayed-sim"
  asOf: string
}

export type Candle = {
  t: number
  o: number
  h: number
  l: number
  c: number
  v: number
}

type YahooChart = {
  chart?: {
    result?: Array<{
      meta?: {
        regularMarketPrice?: number
        previousClose?: number
        chartPreviousClose?: number
      }
      timestamp?: number[]
      indicators?: {
        quote?: Array<{
          open?: Array<number | null>
          high?: Array<number | null>
          low?: Array<number | null>
          close?: Array<number | null>
          volume?: Array<number | null>
        }>
      }
    }>
  }
}

function seededWalk(def: SymbolDef): Quote {
  const day = todayKey();
  const hour = new Date().getHours();
  let s = hashString(`${def.id}-${day}-${hour}`);
  const rand = () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
  const baseMap: Record<string, number> = {
    NIFTY: 24750,
    SENSEX: 80920,
    BANKNIFTY: 55640,
    RELIANCE: 1428,
    TCS: 3895,
    HDFCBANK: 1662,
    INFY: 1874,
    ICICIBANK: 1218,
    ITC: 492,
    SBIN: 812,
    BHARTI: 1840,
    LT: 3625,
  };
  const base = baseMap[def.id] ?? 1000;
  const drift = (rand() - 0.48) * 0.012;
  const candles: Candle[] = [];
  let price = base * (1 - drift);
  const start = Date.now() - 29 * 86400000;
  for (let i = 0; i < 30; i++) {
    const o = price;
    const move = (rand() - 0.48) * 0.018 * price;
    const c = Math.max(1, o + move);
    const h = Math.max(o, c) * (1 + rand() * 0.006);
    const l = Math.min(o, c) * (1 - rand() * 0.006);
    candles.push({
      t: start + i * 86400000,
      o,
      h,
      l,
      c,
      v: Math.round(2e6 + rand() * 8e6),
    });
    price = c;
  }
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2] ?? last;
  const change = last.c - prev.c;
  return {
    id: def.id,
    yahoo: def.yahoo,
    name: def.name,
    kind: def.kind,
    sector: def.sector,
    price: last.c,
    previousClose: prev.c,
    change,
    changePct: (change / prev.c) * 100,
    high: last.h,
    low: last.l,
    volume: last.v,
    spark: candles.map((c) => c.c),
    candles,
    isBull: change >= 0,
    source: "delayed-sim",
    asOf: new Date().toISOString(),
  };
}

async function fetchYahoo(def: SymbolDef): Promise<Quote | null> {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(def.yahoo)}?interval=1d&range=1mo`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 PlanVistaEducation/1.0",
      Accept: "application/json",
    },
    signal: AbortSignal.timeout(4000),
  });
  if (!res.ok) return null;
  const body = (await res.json()) as YahooChart;
  const result = body.chart?.result?.[0];
  const quote = result?.indicators?.quote?.[0];
  const ts = result?.timestamp ?? [];
  if (!result || !quote || !ts.length) return null;
  const candles: Candle[] = [];
  for (let i = 0; i < ts.length; i++) {
    const o = quote.open?.[i];
    const h = quote.high?.[i];
    const l = quote.low?.[i];
    const c = quote.close?.[i];
    const v = quote.volume?.[i];
    if (o == null || h == null || l == null || c == null) continue;
    candles.push({ t: ts[i] * 1000, o, h, l, c, v: v ?? 0 });
  }
  if (candles.length < 2) return null;
  const last = candles[candles.length - 1];
  const prevClose =
    result.meta?.previousClose ??
    result.meta?.chartPreviousClose ??
    candles[candles.length - 2].c;
  const price = result.meta?.regularMarketPrice ?? last.c;
  const change = price - prevClose;
  return {
    id: def.id,
    yahoo: def.yahoo,
    name: def.name,
    kind: def.kind,
    sector: def.sector,
    price,
    previousClose: prevClose,
    change,
    changePct: (change / prevClose) * 100,
    high: last.h,
    low: last.l,
    volume: last.v,
    spark: candles.map((c) => c.c),
    candles,
    isBull: change >= 0,
    source: "live",
    asOf: new Date().toISOString(),
  };
}

async function loadOne(def: SymbolDef): Promise<Quote> {
  try {
    const live = await fetchYahoo(def);
    if (live) return live;
  } catch {
    /* fall through */
  }
  return seededWalk(def);
}

export const getMarketBoard = createServerFn({ method: "GET" }).handler(async () => {
  const quotes = await Promise.all(SYMBOLS.map((s) => loadOne(s)));
  const nifty = quotes.find((q) => q.id === "NIFTY") ?? quotes[0];
  return {
    quotes,
    session: {
      isBull: nifty.isBull,
      leader: nifty,
      asOf: nifty.asOf,
      source: quotes.some((q) => q.source === "live") ? ("live" as const) : ("delayed-sim" as const),
    },
  };
});

export const getQuote = createServerFn({ method: "POST" })
  .validator((id: unknown) => String(id || "NIFTY"))
  .handler(async ({ data }) => loadOne(findSymbol(data)));
