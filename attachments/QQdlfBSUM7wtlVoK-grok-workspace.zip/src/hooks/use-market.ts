import { useQuery } from "@tanstack/react-query";
import { getMarketBoard, getQuote } from "@/lib/market/quotes";

export function useMarketBoard() {
  return useQuery({
    queryKey: ["market-board"],
    queryFn: () => getMarketBoard(),
  });
}

export function useQuote(id: string) {
  return useQuery({
    queryKey: ["quote", id],
    queryFn: () => getQuote({ data: id }),
  });
}
