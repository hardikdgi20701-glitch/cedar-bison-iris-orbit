import { useEffect, useState } from "react";
import { readGate, type GateRecord } from "@/lib/gate/store";

export function useGate() {
  const [record, setRecord] = useState<GateRecord>(() => readGate());
  useEffect(() => {
    const sync = () => setRecord(readGate());
    sync();
    window.addEventListener("storage", sync);
    window.addEventListener("planvista-gate", sync);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener("planvista-gate", sync);
    };
  }, []);
  return record;
}
