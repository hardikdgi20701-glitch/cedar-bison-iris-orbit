//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-pZXCEqDp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/learn",
			"/markets",
			"/onboarding",
			"/planner",
			"/portfolio",
			"/progress",
			"/quiz",
			"/report",
			"/search",
			"/sip",
			"/goal/$id",
			"/quote/$symbol"
		],
		preloads: [
			"/assets/index-aSJkMc89.js",
			"/assets/utils-CqniLJKt.js",
			"/assets/createServerFn-hCxbz79M.js",
			"/assets/link-JCd0Egco.js",
			"/assets/redirect-DtIAAt0y.js",
			"/assets/useRouter-C3khPP3c.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-aSJkMc89.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-aUivGJ2Q.js"]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: ["/learn/$slug"],
		preloads: ["/assets/learn-j1p-a6Qf.js"]
	},
	"/markets": {
		filePath: "/workspace/src/routes/markets.tsx",
		children: void 0,
		preloads: ["/assets/markets-CehoFpNa.js", "/assets/DeepSearch-BMIoOmkD.js"]
	},
	"/onboarding": {
		filePath: "/workspace/src/routes/onboarding.tsx",
		children: void 0,
		preloads: ["/assets/onboarding-Dnv78TlR.js"]
	},
	"/planner": {
		filePath: "/workspace/src/routes/planner.tsx",
		children: void 0,
		preloads: ["/assets/planner-D3ehvqC5.js", "/assets/GoalForm-BUyEDzkR.js"]
	},
	"/portfolio": {
		filePath: "/workspace/src/routes/portfolio.tsx",
		children: void 0,
		preloads: [
			"/assets/portfolio-DZ-3b_Y1.js",
			"/assets/AllocationBar-DaEKP6Mr.js",
			"/assets/GrowthChart-BC9okb5k.js"
		]
	},
	"/progress": {
		filePath: "/workspace/src/routes/progress.tsx",
		children: void 0,
		preloads: ["/assets/progress-BWNOb7vX.js"]
	},
	"/quiz": {
		filePath: "/workspace/src/routes/quiz.tsx",
		children: void 0,
		preloads: ["/assets/quiz-BsR6ED-j.js"]
	},
	"/report": {
		filePath: "/workspace/src/routes/report.tsx",
		children: void 0,
		preloads: ["/assets/report-BBgRyDUR.js", "/assets/AllocationBar-DaEKP6Mr.js"]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: ["/assets/search-R2dYf3sq.js", "/assets/DeepSearch-BMIoOmkD.js"]
	},
	"/sip": {
		filePath: "/workspace/src/routes/sip.tsx",
		children: void 0,
		preloads: ["/assets/sip-B4MHxxp-.js", "/assets/GrowthChart-BC9okb5k.js"]
	},
	"/goal/$id": {
		filePath: "/workspace/src/routes/goal.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/goal._id-44NDvWyH.js",
			"/assets/AllocationBar-DaEKP6Mr.js",
			"/assets/GrowthChart-BC9okb5k.js",
			"/assets/GoalForm-BUyEDzkR.js"
		]
	},
	"/learn/$slug": {
		filePath: "/workspace/src/routes/learn.$slug.tsx",
		children: void 0,
		preloads: ["/assets/learn._slug-BCzq0Odd.js"]
	},
	"/quote/$symbol": {
		filePath: "/workspace/src/routes/quote.$symbol.tsx",
		children: void 0,
		preloads: ["/assets/quote._symbol-t4xvYN0h.js", "/assets/generateCategoricalChart-fGb8-w-X.js"]
	}
} });
//#endregion
export { tsrStartManifest };
