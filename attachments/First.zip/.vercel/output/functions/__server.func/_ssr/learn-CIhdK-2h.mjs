import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as useSiply, s as ARTICLES } from "./router-DAvrQrMU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-CIhdK-2h.js
var import_jsx_runtime = require_jsx_runtime();
function Learn() {
	const read = useSiply((s) => s.readSlugs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium tracking-tight",
			children: "Learn"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Short explainers written for first-time student investors. Read two to earn the reader badge."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-border overflow-hidden rounded-lg border border-border",
			children: ARTICLES.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/learn/$slug",
				params: { slug: a.slug },
				className: "block px-4 py-4 hover:bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-wide text-primary",
						children: a.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-base font-medium",
						children: a.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							a.minutes,
							" min read",
							read.includes(a.slug) ? " · Read" : ""
						]
					})
				]
			}) }, a.slug))
		})]
	});
}
//#endregion
export { Learn as component };
