import { i as __toESM } from "../_runtime.mjs";
import { V as require_react, _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as displayTicker, c as googleFinanceSearchUrl, i as MARKET_LISTS, n as DEFAULT_WATCHLIST, o as findCompany, u as googleSearchUrl } from "./universe-DCkNyMnJ.mjs";
import { a as Send, c as Phone, d as Menu, f as Mail, g as ArrowUp, h as ChevronDown, i as Sparkles, m as ChevronUp, n as TriangleAlert, o as Search, p as ListPlus, r as Sun, s as Plus, t as X, u as Moon, v as ArrowDown } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-C1p7zOu_.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-DAvrQrMU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var DEMO_PROFILE = {
	displayName: "Hardik",
	age: 24,
	monthlyIncome: 45e3,
	monthlySurplus: 8e3,
	risk: "moderate",
	timeHorizon: "medium",
	purpose: "plan",
	quizAnswers: [
		1,
		1,
		0,
		1,
		1,
		1,
		1
	],
	quizComplete: true,
	onboardingComplete: false
};
function demoGoals() {
	return [
		{
			id: "demo-emergency",
			name: "Emergency fund",
			category: "emergency",
			todayCost: 12e4,
			years: 1.5,
			inflation: .06,
			existing: 2e4,
			stepUp: 0,
			monthlySipOverride: null,
			createdAt: 1
		},
		{
			id: "demo-laptop",
			name: "Workstation upgrade",
			category: "gadget",
			todayCost: 95e3,
			years: 1.5,
			inflation: .05,
			existing: 1e4,
			stepUp: .1,
			monthlySipOverride: null,
			createdAt: 2
		},
		{
			id: "demo-house",
			name: "Home down-payment seed",
			category: "home",
			todayCost: 15e5,
			years: 7,
			inflation: .07,
			existing: 5e4,
			stepUp: .1,
			monthlySipOverride: null,
			createdAt: 3
		},
		{
			id: "demo-retire",
			name: "Retirement corpus start",
			category: "retirement",
			todayCost: 5e6,
			years: 25,
			inflation: .06,
			existing: 0,
			stepUp: .1,
			monthlySipOverride: null,
			createdAt: 4
		}
	];
}
var TICKER = [
	{
		symbol: "NIFTY 50",
		yahoo: "^NSEI"
	},
	{
		symbol: "SENSEX",
		yahoo: "^BSESN"
	},
	{
		symbol: "BANK NIFTY",
		yahoo: "^NSEBANK"
	},
	{
		symbol: "NIFTY IT",
		yahoo: "^CNXIT"
	},
	{
		symbol: "USD/INR",
		yahoo: "USDINR=X"
	},
	{
		symbol: "GOLD USD",
		yahoo: "GC=F"
	},
	{
		symbol: "INDIA VIX",
		yahoo: "^INDIAVIX"
	}
];
var EQUITY_RET = .12;
var HYBRID_RET = .1;
var DEBT_RET = .07;
var GOLD_RET = .08;
var EQUITY_VOL = .18;
var HYBRID_VOL = .1;
var DEBT_VOL = .03;
var GOLD_VOL = .12;
var ALLOC = {
	conservative: {
		short: {
			equity: .2,
			hybrid: .2,
			debt: .55,
			gold: .05
		},
		medium: {
			equity: .35,
			hybrid: .25,
			debt: .35,
			gold: .05
		},
		long: {
			equity: .5,
			hybrid: .2,
			debt: .25,
			gold: .05
		}
	},
	moderate: {
		short: {
			equity: .3,
			hybrid: .25,
			debt: .4,
			gold: .05
		},
		medium: {
			equity: .5,
			hybrid: .2,
			debt: .25,
			gold: .05
		},
		long: {
			equity: .7,
			hybrid: .1,
			debt: .15,
			gold: .05
		}
	},
	aggressive: {
		short: {
			equity: .45,
			hybrid: .2,
			debt: .3,
			gold: .05
		},
		medium: {
			equity: .65,
			hybrid: .15,
			debt: .15,
			gold: .05
		},
		long: {
			equity: .8,
			hybrid: .1,
			debt: .05,
			gold: .05
		}
	}
};
var FUNDS = {
	equity: [{
		name: "Nifty 50 Index Fund (Direct)",
		why: "Broad large-cap market at low cost — a simple core holding."
	}, {
		name: "Flexi Cap Fund (Direct)",
		why: "Manager can shift across large/mid/small as markets change."
	}],
	hybrid: [{
		name: "Balanced Advantage / Dynamic Asset Allocation",
		why: "Automatically trims equity when expensive — useful for medium goals."
	}, {
		name: "Aggressive Hybrid Fund",
		why: "Equity-tilted mix with a debt cushion for 3–7 year goals."
	}],
	debt: [{
		name: "Liquid / Overnight Fund",
		why: "Park near-term money (fees, emergency) with high liquidity."
	}, {
		name: "Short Duration Debt Fund",
		why: "Slightly higher yield than liquid for 1–3 year goals."
	}],
	gold: [{
		name: "Gold ETF / Gold FoF",
		why: "Small diversifier; not a growth engine for student goals."
	}]
};
function horizonBucket(years) {
	if (years < 3) return "short";
	if (years < 7) return "medium";
	return "long";
}
function allocationFor(risk, years, category) {
	let r = risk;
	let y = years;
	if (category === "emergency") {
		r = "conservative";
		y = Math.min(years, 2);
	}
	return { ...ALLOC[r][horizonBucket(y)] };
}
function blendedReturn(a) {
	return a.equity * EQUITY_RET + a.hybrid * HYBRID_RET + a.debt * DEBT_RET + a.gold * GOLD_RET;
}
function blendedVol(a) {
	return a.equity * EQUITY_VOL + a.hybrid * HYBRID_VOL + a.debt * DEBT_VOL + a.gold * GOLD_VOL;
}
function projectCorpus(startSip, n, r, stepUp, existing) {
	let corpus = existing;
	let sip = startSip;
	for (let m = 0; m < n; m++) {
		corpus = corpus * (1 + r) + sip;
		if ((m + 1) % 12 === 0) sip *= 1 + stepUp;
	}
	return corpus;
}
function requiredSip(target, n, r, stepUp, existing) {
	const remaining = target - existing * (1 + r) ** n;
	if (remaining <= 0 || n <= 0) return 0;
	if (Math.abs(r) < 1e-12 && stepUp <= 0) return remaining / n;
	let lo = 0;
	let hi = Math.max(remaining, 1);
	for (let i = 0; i < 40; i++) {
		if (projectCorpus(hi, n, r, stepUp, existing) >= target) break;
		hi *= 2;
	}
	for (let i = 0; i < 48; i++) {
		const mid = (lo + hi) / 2;
		if (projectCorpus(mid, n, r, stepUp, existing) < target) lo = mid;
		else hi = mid;
	}
	return hi;
}
function yearlyPath(startSip, years, annualR, stepUp, existing) {
	const n = Math.max(1, Math.round(years * 12));
	const r = annualR / 12;
	let corpus = existing;
	let sip = startSip;
	let invested = existing;
	const rows = [{
		year: 0,
		sip,
		corpus,
		invested
	}];
	for (let m = 0; m < n; m++) {
		corpus = corpus * (1 + r) + sip;
		invested += sip;
		if ((m + 1) % 12 === 0) {
			sip *= 1 + stepUp;
			rows.push({
				year: (m + 1) / 12,
				sip,
				corpus,
				invested
			});
		}
	}
	if (n % 12 !== 0) rows.push({
		year: n / 12,
		sip,
		corpus,
		invested
	});
	return rows;
}
function sparkline(startSip, years, annualR, stepUp, existing, points = 24) {
	const n = Math.max(1, Math.round(years * 12));
	const r = annualR / 12;
	let corpus = existing;
	let sip = startSip;
	const series = [corpus];
	const step = Math.max(1, Math.floor(n / points));
	for (let m = 0; m < n; m++) {
		corpus = corpus * (1 + r) + sip;
		if ((m + 1) % 12 === 0) sip *= 1 + stepUp;
		if ((m + 1) % step === 0 || m === n - 1) series.push(corpus);
	}
	return series;
}
function gauss(rng) {
	let u = 0;
	let v = 0;
	while (u === 0) u = rng();
	while (v === 0) v = rng();
	return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
function mulberry32(a) {
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function monteCarlo(startSip, n, annualR, vol, stepUp, existing, target, paths = 400, seed = 42) {
	const rng = mulberry32(seed);
	const mu = annualR / 12;
	const sig = vol / Math.sqrt(12);
	const finals = [];
	let hits = 0;
	for (let p = 0; p < paths; p++) {
		let corpus = existing;
		let sip = startSip;
		for (let m = 0; m < n; m++) {
			corpus = corpus * (1 + (mu + sig * gauss(rng))) + sip;
			if ((m + 1) % 12 === 0) sip *= 1 + stepUp;
		}
		finals.push(corpus);
		if (corpus >= target) hits++;
	}
	finals.sort((a, b) => a - b);
	return {
		successRate: hits / paths,
		p10: finals[Math.floor(.1 * (paths - 1))] ?? 0,
		p50: finals[Math.floor(.5 * (paths - 1))] ?? 0,
		p90: finals[Math.floor(.9 * (paths - 1))] ?? 0
	};
}
function explain(goal, alloc, annualR, sip, surplus) {
	const years = goal.years;
	const bucket = horizonBucket(years);
	const eq = Math.round(alloc.equity * 100);
	let why;
	if (goal.category === "emergency") why = "Emergency money should stay mostly in debt so you can use it without selling in a crash.";
	else if (bucket === "short") why = `With only ${years.toFixed(1)} years, markets may not recover from a dip — so equity is capped at ${eq}%.`;
	else if (bucket === "long") why = `${years.toFixed(0)} years is long enough for equity (${eq}%) to be the growth engine; inflation is the bigger risk.`;
	else why = `A ${years.toFixed(0)}-year horizon uses a blended mix (${eq}% equity) so growth and stability share the job.`;
	if (surplus > 0 && sip > surplus) why += " Required SIP is above your monthly surplus — trim the goal, extend the timeline, or add a step-up.";
	else if (surplus > 0) why += ` Assumed long-run blended return is ${(annualR * 100).toFixed(1)}% (illustrative, not a guarantee).`;
	return why;
}
function planGoal(goal, risk, surplus, runMc = true) {
	const years = Math.max(.25, goal.years);
	const inflation = goal.inflation ?? .06;
	const alloc = allocationFor(risk, years, goal.category);
	const annualR = blendedReturn(alloc);
	const vol = blendedVol(alloc);
	const fv = goal.todayCost * (1 + inflation) ** years;
	const n = Math.max(1, Math.round(years * 12));
	const sip = requiredSip(fv, n, annualR / 12, goal.stepUp, goal.existing);
	const used = goal.monthlySipOverride ?? sip;
	const path = yearlyPath(used, years, annualR, goal.stepUp, goal.existing);
	const last = path[path.length - 1];
	const equalSave = n ? fv / n : fv;
	const funds = [];
	Object.keys(alloc).forEach((k) => {
		if (alloc[k] <= 0) return;
		FUNDS[k].forEach((f) => funds.push({
			...f,
			sleeve: k,
			weight: alloc[k]
		}));
	});
	let afford = "comfortable";
	if (surplus > 0) {
		if (sip > surplus * .9) afford = "stretch";
		else if (sip > surplus * .5) afford = "tight";
	}
	const mc = runMc ? monteCarlo(used, n, annualR, vol, goal.stepUp, goal.existing, fv) : null;
	return {
		id: goal.id,
		futureCost: fv,
		requiredSip: sip,
		usedSip: used,
		totalInvested: last.invested,
		projectedCorpus: last.corpus,
		expectedReturn: annualR,
		volatility: vol,
		allocation: alloc,
		funds,
		yearly: path,
		spark: sparkline(used, years, annualR, goal.stepUp, goal.existing),
		affordability: afford,
		successRate: mc?.successRate ?? null,
		p10: mc?.p10 ?? null,
		p50: mc?.p50 ?? null,
		p90: mc?.p90 ?? null,
		equalMonthlySaving: equalSave,
		sipVsSavingPct: equalSave ? (equalSave - sip) / equalSave * 100 : 0,
		explanation: explain(goal, alloc, annualR, sip, surplus),
		horizon: horizonBucket(years),
		months: n
	};
}
function planAll(profile, goals, monteCarlo = true) {
	const planned = goals.map((g) => planGoal(g, profile.risk, profile.monthlySurplus, monteCarlo));
	const monthlySip = planned.reduce((s, p) => s + p.requiredSip, 0);
	return {
		engine: "local",
		goals: planned,
		totals: {
			monthlySip,
			surplus: profile.monthlySurplus,
			gap: monthlySip - profile.monthlySurplus,
			utilization: profile.monthlySurplus ? monthlySip / profile.monthlySurplus : null
		}
	};
}
var QUIZ = [
	{
		id: "horizon",
		q: "When do you need most of this money?",
		options: [
			{
				label: "Within 2 years (fees, laptop, trip)",
				score: 0
			},
			{
				label: "3–5 years (degree, first job buffer)",
				score: 1
			},
			{
				label: "6+ years (higher studies, seed capital)",
				score: 2
			}
		]
	},
	{
		id: "drop",
		q: "If your SIP corpus fell 20% in a bad year, you would…",
		options: [
			{
				label: "Stop SIPs and move to a savings account",
				score: 0
			},
			{
				label: "Pause and wait it out",
				score: 1
			},
			{
				label: "Keep going — maybe even increase the SIP",
				score: 2
			}
		]
	},
	{
		id: "exp",
		q: "How much investing have you done so far?",
		options: [
			{
				label: "None — this is my first plan",
				score: 0
			},
			{
				label: "A little (PPF, RD, or one mutual fund)",
				score: 1
			},
			{
				label: "I already run SIPs or hold index funds",
				score: 2
			}
		]
	},
	{
		id: "income",
		q: "How stable is the money you can invest each month?",
		options: [
			{
				label: "It changes a lot (gigs / pocket money)",
				score: 0
			},
			{
				label: "Mostly steady internship or allowance",
				score: 1
			},
			{
				label: "Predictable stipend or part-time salary",
				score: 2
			}
		]
	},
	{
		id: "emergency",
		q: "Do you already have 2–3 months of expenses set aside?",
		options: [
			{
				label: "Not yet",
				score: 0
			},
			{
				label: "Working on it",
				score: 1
			},
			{
				label: "Yes, in a liquid/savings account",
				score: 2
			}
		]
	},
	{
		id: "priority",
		q: "What matters more for these student goals?",
		options: [
			{
				label: "Not losing money",
				score: 0
			},
			{
				label: "A balance of growth and sleep-at-night",
				score: 1
			},
			{
				label: "Beating inflation, even if the path is bumpy",
				score: 2
			}
		]
	},
	{
		id: "lock",
		q: "Can this money stay invested until the goal date?",
		options: [
			{
				label: "I might need it earlier",
				score: 0
			},
			{
				label: "Probably, with a small buffer",
				score: 1
			},
			{
				label: "Yes — it is earmarked",
				score: 2
			}
		]
	}
];
function scoreToRisk(answers) {
	const s = answers.reduce((a, b) => a + b, 0);
	if (s <= 5) return "conservative";
	if (s <= 10) return "moderate";
	return "aggressive";
}
function projectSip(opts) {
	return yearlyPath(opts.monthly, opts.years, opts.annualReturn, opts.stepUp, opts.existing);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function inr(n, compact = false) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	const sign = n < 0 ? "-" : "";
	if (compact) {
		if (abs >= 1e7) return `${sign}₹${(abs / 1e7).toFixed(abs >= 1e8 ? 1 : 2)}Cr`;
		if (abs >= 1e5) return `${sign}₹${(abs / 1e5).toFixed(abs >= 1e6 ? 1 : 2)}L`;
		if (abs >= 1e3) return `${sign}₹${(abs / 1e3).toFixed(abs >= 1e4 ? 1 : 1)}K`;
	}
	return sign + "₹" + Math.round(abs).toLocaleString("en-IN", { maximumFractionDigits: 0 });
}
function inrPrice(n) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	const sign = n < 0 ? "-" : "";
	const digits = abs >= 1e3 ? 2 : abs >= 1 ? 2 : 4;
	return sign + "₹" + abs.toLocaleString("en-IN", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function formatMoney(n, currency, compact = false) {
	if (!Number.isFinite(n)) return "—";
	if (currency === "INR") return compact ? inr(n, true) : inrPrice(n);
	const sign = n < 0 ? "-" : "";
	const abs = Math.abs(n);
	const sym = currency === "USD" ? "$" : currency === "EUR" ? "€" : "";
	if (compact && abs >= 1e9) return `${sign}${sym}${(abs / 1e9).toFixed(2)}B`;
	if (compact && abs >= 1e6) return `${sign}${sym}${(abs / 1e6).toFixed(2)}M`;
	return sign + (sym || currency + " ") + abs.toLocaleString("en-US", { maximumFractionDigits: abs >= 100 ? 2 : 4 });
}
function pct(n, digits = 2) {
	if (!Number.isFinite(n)) return "—";
	const v = n * 100;
	return `${v > 0 ? "+" : ""}${v.toFixed(digits)}%`;
}
function uid() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return "g" + Math.random().toString(36).slice(2, 10);
}
function formatVol(n) {
	if (n == null || !Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	if (abs >= 1e7) return `${(abs / 1e7).toFixed(2)}Cr`;
	if (abs >= 1e5) return `${(abs / 1e5).toFixed(2)}L`;
	if (abs >= 1e3) return `${(abs / 1e3).toFixed(2)}k`;
	return Math.round(abs).toLocaleString("en-IN");
}
function timeAgo(input) {
	const t = Date.parse(input);
	if (!Number.isFinite(t)) return input;
	const s = Math.max(0, (Date.now() - t) / 1e3);
	if (s < 60) return "just now";
	if (s < 3600) return `${Math.floor(s / 60)}m ago`;
	if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
	const d = Math.floor(s / 86400);
	if (d < 30) return `${d}d ago`;
	return new Date(t).toLocaleDateString("en-IN", {
		day: "numeric",
		month: "short"
	});
}
var emptyProfile = {
	displayName: "",
	age: 25,
	monthlyIncome: 0,
	monthlySurplus: 5e3,
	risk: "moderate",
	timeHorizon: "medium",
	purpose: "",
	quizAnswers: [],
	quizComplete: false,
	onboardingComplete: false
};
function withBadges(goals, profile, read, watch, prev) {
	const next = new Set(prev);
	if (profile.quizComplete) next.add("quiz");
	if (profile.onboardingComplete) next.add("onboarded");
	if (goals.length >= 1) next.add("first-goal");
	if (goals.length >= 3) next.add("three-goals");
	if (read.length >= 2) next.add("reader");
	if (watch.length >= 5) next.add("watchlist");
	const p = planAll(profile, goals, false);
	if (p.totals.surplus > 0 && p.totals.monthlySip <= p.totals.surplus) next.add("affordable");
	return [...next];
}
var useSiply = create()(persist((set, get) => ({
	profile: { ...DEMO_PROFILE },
	goals: demoGoals(),
	badges: [
		"quiz",
		"first-goal",
		"three-goals"
	],
	readSlugs: [],
	watchlist: [...DEFAULT_WATCHLIST],
	hydratedFromCloud: false,
	setProfile: (p) => set((s) => {
		const profile = {
			...s.profile,
			...p
		};
		return {
			profile,
			badges: withBadges(s.goals, profile, s.readSlugs, s.watchlist, s.badges)
		};
	}),
	completeQuiz: (answers) => set((s) => {
		const profile = {
			...s.profile,
			quizAnswers: answers,
			quizComplete: true,
			risk: scoreToRisk(answers)
		};
		return {
			profile,
			badges: withBadges(s.goals, profile, s.readSlugs, s.watchlist, s.badges)
		};
	}),
	addGoal: (g) => {
		const id = uid();
		set((s) => {
			const goals = [...s.goals, {
				...g,
				id,
				createdAt: Date.now()
			}];
			return {
				goals,
				badges: withBadges(goals, s.profile, s.readSlugs, s.watchlist, s.badges)
			};
		});
		return id;
	},
	updateGoal: (id, g) => set((s) => {
		const goals = s.goals.map((x) => x.id === id ? {
			...x,
			...g
		} : x);
		return {
			goals,
			badges: withBadges(goals, s.profile, s.readSlugs, s.watchlist, s.badges)
		};
	}),
	removeGoal: (id) => set((s) => {
		const goals = s.goals.filter((x) => x.id !== id);
		return {
			goals,
			badges: withBadges(goals, s.profile, s.readSlugs, s.watchlist, s.badges)
		};
	}),
	loadDemo: () => set({
		profile: { ...DEMO_PROFILE },
		goals: demoGoals(),
		badges: [
			"quiz",
			"first-goal",
			"three-goals"
		]
	}),
	reset: () => set({
		profile: emptyProfile,
		goals: [],
		badges: [],
		readSlugs: [],
		watchlist: [...DEFAULT_WATCHLIST]
	}),
	markRead: (slug) => set((s) => {
		if (s.readSlugs.includes(slug)) return s;
		const readSlugs = [...s.readSlugs, slug];
		return {
			readSlugs,
			badges: withBadges(s.goals, s.profile, readSlugs, s.watchlist, s.badges)
		};
	}),
	toggleWatch: (symbol) => set((s) => {
		const watchlist = s.watchlist.includes(symbol) ? s.watchlist.filter((x) => x !== symbol) : [...s.watchlist, symbol];
		return {
			watchlist,
			badges: withBadges(s.goals, s.profile, s.readSlugs, watchlist, s.badges)
		};
	}),
	setWatchlist: (watchlist) => set((s) => ({
		watchlist,
		badges: withBadges(s.goals, s.profile, s.readSlugs, watchlist, s.badges)
	})),
	hydrateCloud: (incoming) => set({
		...incoming,
		watchlist: incoming.watchlist.length ? incoming.watchlist : [...DEFAULT_WATCHLIST],
		hydratedFromCloud: true
	}),
	markHydrated: () => set({ hydratedFromCloud: true }),
	snapshot: () => {
		const s = get();
		return {
			profile: s.profile,
			goals: s.goals,
			badges: s.badges,
			readSlugs: s.readSlugs,
			watchlist: s.watchlist
		};
	},
	plan: () => planAll(get().profile, get().goals, true)
}), {
	name: "planvista-v2",
	skipHydration: true,
	partialize: (s) => ({
		profile: s.profile,
		goals: s.goals,
		badges: s.badges,
		readSlugs: s.readSlugs,
		watchlist: s.watchlist
	})
}));
var CATEGORIES = [
	{
		id: "education",
		label: "Education"
	},
	{
		id: "gadget",
		label: "Gadget"
	},
	{
		id: "travel",
		label: "Travel"
	},
	{
		id: "emergency",
		label: "Emergency"
	},
	{
		id: "career",
		label: "Career"
	},
	{
		id: "home",
		label: "Home"
	},
	{
		id: "retirement",
		label: "Retirement"
	},
	{
		id: "custom",
		label: "Custom"
	}
];
var BADGE_META = {
	quiz: {
		label: "Risk mapped",
		hint: "Finished the risk questionnaire"
	},
	"first-goal": {
		label: "First goal",
		hint: "Created a named SIP job"
	},
	"three-goals": {
		label: "Multi-goal",
		hint: "Three or more goals on the book"
	},
	reader: {
		label: "Market student",
		hint: "Read two explainers"
	},
	affordable: {
		label: "Fits surplus",
		hint: "Required SIPs ≤ monthly surplus"
	},
	watchlist: {
		label: "List builder",
		hint: "Five or more stocks on a list"
	},
	onboarded: {
		label: "Profile set",
		hint: "Completed onboarding"
	}
};
var KEY = "pv-theme";
function readTheme() {
	if (typeof window === "undefined") return "dark";
	try {
		const stored = window.localStorage.getItem(KEY);
		if (stored === "light" || stored === "dark") return stored;
	} catch {}
	return "dark";
}
function applyTheme(theme) {
	const root = document.documentElement;
	root.classList.toggle("dark", theme === "dark");
	root.style.colorScheme = theme;
	const meta = document.querySelector("meta[name=\"theme-color\"]");
	if (meta) meta.setAttribute("content", theme === "dark" ? "#131314" : "#ffffff");
}
var ThemeContext = (0, import_react.createContext)(null);
function ThemeProvider({ children }) {
	const [theme, setThemeState] = (0, import_react.useState)("dark");
	(0, import_react.useEffect)(() => {
		const next = readTheme();
		setThemeState(next);
		applyTheme(next);
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		theme,
		setTheme: (t) => {
			setThemeState(t);
			try {
				window.localStorage.setItem(KEY, t);
			} catch {}
			applyTheme(t);
		},
		toggle: () => {
			setThemeState((prev) => {
				const next = prev === "dark" ? "light" : "dark";
				try {
					window.localStorage.setItem(KEY, next);
				} catch {}
				applyTheme(next);
				return next;
			});
		}
	}), [theme]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeContext.Provider, {
		value,
		children
	});
}
function useTheme() {
	const ctx = (0, import_react.useContext)(ThemeContext);
	if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
	return ctx;
}
var RANGE_MAP = {
	"1d": {
		range: "1d",
		interval: "2m"
	},
	"5d": {
		range: "5d",
		interval: "15m"
	},
	"1mo": {
		range: "1mo",
		interval: "1d"
	},
	"6mo": {
		range: "6mo",
		interval: "1d"
	},
	ytd: {
		range: "ytd",
		interval: "1d"
	},
	"1y": {
		range: "1y",
		interval: "1d"
	},
	"5y": {
		range: "5y",
		interval: "1wk"
	},
	max: {
		range: "max",
		interval: "1mo"
	}
};
var getQuotes = createServerFn({ method: "POST" }).validator((data) => {
	const symbols = data?.symbols;
	if (!Array.isArray(symbols)) throw new Error("symbols required");
	return { symbols: symbols.slice(0, 40).map(String) };
}).handler(createSsrRpc("5948da8bf4c04fa12b5a432843bb3a7036103dc6f3e924194d39a3211ad6f650"));
createServerFn({ method: "POST" }).validator((data) => {
	const d = data;
	if (!d?.symbol) throw new Error("symbol required");
	const range = d.range ?? "1d";
	if (!(range in RANGE_MAP)) throw new Error("bad range");
	return {
		symbol: String(d.symbol),
		range
	};
}).handler(createSsrRpc("a04b39d305727adcd6ad9cb315ab77e37f8791cd7d5e940e045bcb457dff4725"));
var getQuoteBundle = createServerFn({ method: "POST" }).validator((data) => {
	const d = data;
	if (!d?.symbol) throw new Error("symbol required");
	return {
		symbol: String(d.symbol),
		range: d.range ?? "1d"
	};
}).handler(createSsrRpc("b354a524a6cbba392d0645cea016f451d312080d2b0c965435be457138c033ac"));
var searchSymbols = createServerFn({ method: "POST" }).validator((data) => {
	return { q: String(data?.q ?? "").trim() };
}).handler(createSsrRpc("c92fff7a71d6b66371a7fb00eccfda99f9b3a5a18eec9613d8925e8f284ad937"));
var deepSearch = createServerFn({ method: "POST" }).validator((data) => {
	const q = String(data?.q ?? "").trim();
	if (q.length > 80) throw new Error("Keep searches under 80 characters");
	return { q };
}).handler(createSsrRpc("2511b9cef7a308ff5ec82e09bd3b563ad5c75799f7f4c3af8fa8d4fc1defe76d"));
var getMarketHome = createServerFn({ method: "POST" }).validator((data) => {
	return { region: String(data?.region ?? "india") };
}).handler(createSsrRpc("1032937a8477871338630ae8ff42a84bcde9f05f7f24c728920eb9ee81fa0105"));
createServerFn({ method: "GET" }).handler(createSsrRpc("76936a157cae8e3a2f21f3c4632688d31273503a1515bffe40bb4eccdd043ccb"));
var ARTICLES = [
	{
		slug: "what-is-a-sip",
		title: "What a SIP actually does with your ₹500",
		kicker: "Basics",
		minutes: 4,
		body: [
			"A Systematic Investment Plan (SIP) invests a fixed amount on a fixed date, usually into a mutual fund. You are not timing the market — you are buying more units when prices are low and fewer when they are high (rupee-cost averaging).",
			"For students, the point is habit plus compounding. ₹2,000 a month for five years is ₹1.2 lakh of your money; at an illustrative 11% annualised return the corpus is closer to ₹1.6 lakh. The extra is market growth, not magic.",
			"SIPs can be paused. They are not a loan and not a lock-in (except tax-saving ELSS, which has a 3-year lock). Start with an amount you will not miss on a bad month."
		]
	},
	{
		slug: "goal-based-vs-random",
		title: "Why every SIP needs a job",
		kicker: "Planning",
		minutes: 3,
		body: [
			"A nameless SIP is easy to raid for a weekend trip. A SIP labelled “semester fees 2029” is harder to break. Goal-based investing assigns each rupee a date, an amount, and a risk level.",
			"Short goals (under 3 years) should not sit in pure equity. Long goals can. Mixing them in one fund makes it tempting to sell the long-term units when a short-term bill arrives.",
			"PlanVista maps each goal to its own SIP size and mix so you can see if the plan fits your surplus before you open a folio."
		]
	},
	{
		slug: "inflation-is-the-silent-fee",
		title: "Inflation is the fee nobody invoices",
		kicker: "Inflation",
		minutes: 3,
		body: ["A ₹80,000 laptop today is not ₹80,000 in 18 months. Education costs in India have often run above general CPI. Planning in today’s rupees without an inflation line understates the SIP you need.", "PlanVista inflates the goal first, then solves for the monthly amount. If the number shocks you, that is useful information: extend the date, step up the SIP with income hikes, or shrink the goal."]
	},
	{
		slug: "risk-for-students",
		title: "Risk when you have more time than money",
		kicker: "Risk",
		minutes: 5,
		body: [
			"Students usually have a long career ahead and a small corpus. Volatility on a ₹10,000 pot is emotionally loud but financially small. The bigger risk is staying in a 3% savings account while fees inflate at 7%.",
			"That does not mean 100% equity for a laptop you need next semester. Match risk to the calendar: emergency and near-term fees in debt/liquid; five-year study-abroad seed can hold more equity.",
			"The quiz in PlanVista is a teaching tool, not a SEBI-registered risk profile. When you invest for real, complete the fund house’s questionnaire."
		]
	},
	{
		slug: "index-funds-first",
		title: "Why an index fund is a good first SIP",
		kicker: "Funds",
		minutes: 4,
		body: [
			"A Nifty 50 or Nifty 500 index fund (direct plan) tracks the market at a low expense ratio. You skip star-manager risk and the urge to switch funds every year.",
			"Direct plans cut distributor commission. For a 10-year SIP the difference compounds. You still need a demat/MF account (Groww, Coin, MF Central, etc.) — PlanVista does not transact.",
			"Categories shown in the planner are sleeves, not buy-lists. Always read the scheme document and past rolling returns, not last year’s rank."
		]
	},
	{
		slug: "step-up-sip",
		title: "Step-up SIPs: let your stipend do the heavy lifting",
		kicker: "Tactics",
		minutes: 3,
		body: ["A 10% annual step-up means this year’s ₹2,000 becomes ₹2,200 next year. That often matches internship or placement hikes and dramatically cuts the starting SIP needed for a far-off goal.", "If you cannot commit to a step-up, plan a flat SIP. A missed step-up is not a failure — recalculate. Consistency beats an aggressive schedule you abandon in exam season."]
	}
];
var HEADLINES = [
	{
		title: "SEBI’s investor-ed push: why campuses are the next classroom",
		source: "Campus Desk",
		time: "2h"
	},
	{
		title: "Direct plans vs regular: the 1% that compounds on student SIPs",
		source: "Explainers",
		time: "5h"
	},
	{
		title: "Education inflation vs CPI — plan the fee, not last year’s brochure",
		source: "Data",
		time: "1d"
	},
	{
		title: "Liquid funds for emergency money: what students actually need",
		source: "Guides",
		time: "1d"
	}
];
function SearchBox({ className }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [remote, setRemote] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const local = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		if (query.length < 1) return [];
		const pages = [
			{
				href: "/",
				label: "Markets",
				kind: "Page"
			},
			{
				href: "/search",
				label: "Deep Search",
				kind: "Page"
			},
			{
				href: "/sip",
				label: "SIP calculator",
				kind: "Page"
			},
			{
				href: "/planner",
				label: "Goals",
				kind: "Page"
			},
			{
				href: "/portfolio",
				label: "Portfolio",
				kind: "Page"
			},
			{
				href: "/learn",
				label: "Learn",
				kind: "Page"
			},
			{
				href: "/progress",
				label: "Progress",
				kind: "Page"
			}
		].filter((p) => p.label.toLowerCase().includes(query));
		const arts = ARTICLES.filter((a) => a.title.toLowerCase().includes(query) || a.kicker.toLowerCase().includes(query)).map((a) => ({
			href: `/learn/${a.slug}`,
			label: a.title,
			kind: "Explainer"
		}));
		return [...pages, ...arts].slice(0, 4);
	}, [q]);
	(0, import_react.useEffect)(() => {
		const query = q.trim();
		if (query.length < 1) {
			setRemote([]);
			return;
		}
		let live = true;
		setBusy(true);
		const t = window.setTimeout(() => {
			searchSymbols({ data: { q: query } }).then((res) => {
				if (!live) return;
				const hits = [...res.local.map((c) => ({
					href: `/quote/${encodeURIComponent(c.yahoo)}`,
					label: c.symbol,
					sub: c.name,
					kind: c.exchange
				})), ...res.remote.map((r) => ({
					href: `/quote/${encodeURIComponent(r.symbol)}`,
					label: r.symbol.replace(/\.NS$|\.BO$/, ""),
					sub: r.name,
					kind: r.exchange || r.type
				}))];
				setRemote(hits.slice(0, 8));
			}).catch(() => {
				if (live) setRemote([]);
			}).finally(() => {
				if (live) setBusy(false);
			});
		}, 220);
		return () => {
			live = false;
			window.clearTimeout(t);
		};
	}, [q]);
	const results = [...remote, ...local].slice(0, 10);
	const query = q.trim();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative min-w-0 flex-1", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => {
					setQ(e.target.value);
					setOpen(true);
				},
				onFocus: () => setOpen(true),
				onBlur: () => setTimeout(() => setOpen(false), 180),
				onKeyDown: (e) => {
					if (e.key === "Enter" && query) {
						window.location.assign(`/search?q=${encodeURIComponent(query)}`);
						setOpen(false);
					}
				},
				placeholder: "Search NSE & BSE stocks, ETFs and more",
				className: "h-11 w-full rounded-full border border-border bg-surface pl-10 pr-4 text-sm outline-none placeholder:text-subtle focus:bg-bg focus:ring-2 focus:ring-primary/30"
			}),
			open && (results.length > 0 || busy || query.length > 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "absolute z-50 mt-1 w-full overflow-hidden rounded-lg border border-border bg-bg shadow-lg",
				children: [
					busy && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-3 py-3 text-sm text-muted",
						children: "Searching listed companies…"
					}) : null,
					results.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: r.href,
						className: "flex items-center justify-between gap-3 px-3 py-2.5 text-sm hover:bg-surface",
						onClick: () => setOpen(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: r.label
							}), r.sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 truncate text-muted",
								children: r.sub
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs text-subtle",
							children: r.kind
						})]
					}) }, r.href + r.label)),
					query ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `/search?q=${encodeURIComponent(query)}`,
								className: "block px-3 py-2.5 text-sm font-medium text-primary hover:bg-surface",
								children: [
									"Deep Search “",
									query,
									"” — live quotes + Google"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: googleFinanceSearchUrl(query),
								target: "_blank",
								rel: "noreferrer",
								className: "block px-3 py-2 text-xs text-muted hover:bg-surface",
								children: "Open in Google Finance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: googleSearchUrl(`${query} stock NSE BSE`),
								target: "_blank",
								rel: "noreferrer",
								className: "block px-3 py-2 text-xs text-muted hover:bg-surface",
								children: "Search Google"
							})
						]
					}) : null
				]
			}) : null
		]
	});
}
var askResearch = createServerFn({ method: "POST" }).validator((data) => {
	const d = data;
	const prompt = String(d?.prompt ?? "").trim();
	if (!prompt) throw new Error("Ask a question");
	if (prompt.length > 2e3) throw new Error("Keep questions under 2,000 characters");
	return {
		prompt,
		context: String(d?.context ?? "").slice(0, 4e3)
	};
}).handler(createSsrRpc("e8e5687cd8191f1d4cf4ae7660bf84fa1ca4f54ad65ea071f465be82ee5235ca"));
function ResearchPanel({ context }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const profile = useSiply((s) => s.profile);
	const [input, setInput] = (0, import_react.useState)("");
	const [msgs, setMsgs] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const symbol = (0, import_react.useMemo)(() => {
		const m = pathname.match(/\/quote\/([^/]+)/);
		return m ? decodeURIComponent(m[1]) : null;
	}, [pathname]);
	const company = symbol ? findCompany(symbol) : null;
	const name = profile.displayName.split(" ")[0] || "Hardik";
	const suggestions = company ? [
		`Give me an overview of ${company.symbol}`,
		`What were the key takeaways from ${company.name} latest quarterly results?`,
		`Why might ${company.symbol} be moving, and what should a learner watch?`
	] : [
		"What's going on with Indian markets today?",
		"How does a SIP compare with a lump sum for a 5-year goal?",
		"How are higher oil prices affecting Indian retail stocks?"
	];
	async function send(text) {
		const prompt = text.trim();
		if (!prompt || busy) return;
		setBusy(true);
		setErr(null);
		setInput("");
		setMsgs((m) => [...m, {
			role: "user",
			text: prompt
		}]);
		try {
			const res = await askResearch({ data: {
				prompt,
				context: [
					context ?? "",
					profile.displayName ? `Learner: ${profile.displayName}, age ${profile.age}, ${profile.risk} risk, ${profile.timeHorizon} horizon.` : "",
					company ? `Viewing ${company.name} (${company.yahoo}), sector ${company.sector}.` : ""
				].filter(Boolean).join("\n")
			} });
			if (!res.ok) {
				setErr(res.error);
				setMsgs((m) => [...m, {
					role: "assistant",
					text: res.error
				}]);
			} else setMsgs((m) => [...m, {
				role: "assistant",
				text: res.text
			}]);
		} catch (e) {
			const msg = e instanceof Error ? e.message : "Could not reach the assistant.";
			setErr(msg);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-medium",
					children: "Research"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-primary" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-4 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Hi ",
							name,
							", ask any financial question"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: suggestions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => void send(s),
							className: "flex w-full items-center justify-between gap-2 rounded-lg border border-border px-3 py-2.5 text-left text-sm hover:bg-surface",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-subtle",
								children: "↗"
							})]
						}) }, s))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-xs font-medium uppercase tracking-wide text-subtle",
						children: "Explore"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/planner",
								className: "inline-flex h-10 items-center gap-2 rounded-full border border-border px-3 text-sm hover:bg-surface",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListPlus, { className: "size-4" }), " Create a goal"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/sip",
								className: "inline-flex h-10 items-center gap-2 rounded-full border border-border px-3 text-sm hover:bg-surface",
								children: "SIP calculator"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/progress",
								className: "inline-flex h-10 items-center gap-2 rounded-full border border-border px-3 text-sm hover:bg-surface",
								children: "Track progress"
							})
						]
					}),
					msgs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-3",
						children: msgs.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: cn("rounded-lg px-3 py-2 text-sm leading-relaxed", m.role === "user" ? "bg-primary-soft text-fg" : "border border-border bg-surface"),
							children: m.text
						}, i))
					}) : null,
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted",
						children: "Thinking…"
					}) : null,
					err && !msgs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-down",
						children: err
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "border-t border-border p-3",
				onSubmit: (e) => {
					e.preventDefault();
					send(input);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end gap-2 rounded-xl border border-border bg-surface px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: input,
						onChange: (e) => setInput(e.target.value),
						rows: 2,
						placeholder: "Ask anything",
						className: "min-h-11 flex-1 resize-none bg-transparent text-sm outline-none placeholder:text-subtle"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: busy || !input.trim(),
						className: "inline-flex size-10 items-center justify-center rounded-full bg-primary text-primary-fg disabled:opacity-40",
						"aria-label": "Send",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-[10px] text-subtle",
					children: "For learning purposes only. Not investment advice."
				})]
			})
		]
	});
}
function Sparkline({ data, className = "h-8 w-24", up }) {
	if (!data.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className });
	const min = Math.min(...data);
	const span = Math.max(...data) - min || 1;
	const w = 96;
	const h = 32;
	const coords = data.map((v, i) => {
		return {
			x: i / Math.max(data.length - 1, 1) * w,
			y: h - (v - min) / span * 26 - 3
		};
	});
	const pts = coords.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
	const last = coords[coords.length - 1];
	const area = `0,${h} ${pts} ${w},${h}`;
	const positive = up ?? data[data.length - 1] >= data[0];
	const color = positive ? "var(--color-up)" : "var(--color-down)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className,
		preserveAspectRatio: "none",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				fill: positive ? "var(--color-up-soft)" : "var(--color-down-soft)",
				points: area
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
				fill: "none",
				stroke: color,
				strokeWidth: "1.5",
				strokeLinejoin: "round",
				points: pts
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: last.x,
				cy: last.y,
				r: "1.7",
				fill: color
			})
		]
	});
}
function WatchlistRail() {
	const watchlist = useSiply((s) => s.watchlist);
	const toggleWatch = useSiply((s) => s.toggleWatch);
	const [open, setOpen] = (0, import_react.useState)({
		watchlist: true,
		index: true
	});
	const [quotes, setQuotes] = (0, import_react.useState)({});
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const groups = (0, import_react.useMemo)(() => [{
		id: "watchlist",
		name: "Watchlist",
		symbols: watchlist
	}, ...MARKET_LISTS], [watchlist]);
	const needed = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		for (const g of groups) if (open[g.id]) g.symbols.forEach((s) => set.add(s));
		return [...set];
	}, [groups, open]);
	(0, import_react.useEffect)(() => {
		let live = true;
		const load = () => {
			const missing = needed.filter((s) => !quotes[s]);
			const batch = (missing.length ? missing : needed).slice(0, 40);
			if (!batch.length) return;
			getQuotes({ data: { symbols: batch } }).then((rows) => {
				if (!live) return;
				setQuotes((prev) => {
					const next = { ...prev };
					for (const r of rows) next[r.symbol] = r;
					return next;
				});
			}).catch(() => {});
		};
		load();
		const id = window.setInterval(load, 25e3);
		return () => {
			live = false;
			window.clearInterval(id);
		};
	}, [needed.join("|")]);
	(0, import_react.useEffect)(() => {
		const query = q.trim();
		if (!adding || query.length < 1) {
			setHits([]);
			return;
		}
		let live = true;
		const t = window.setTimeout(() => {
			searchSymbols({ data: { q: query } }).then((res) => {
				if (!live) return;
				setHits([...res.local.map((c) => ({
					symbol: c.yahoo,
					name: c.name,
					exchange: c.exchange
				})), ...res.remote.map((r) => ({
					symbol: r.symbol,
					name: r.name,
					exchange: r.exchange
				}))].slice(0, 8));
			}).catch(() => {
				if (live) setHits([]);
			});
		}, 180);
		return () => {
			live = false;
			window.clearTimeout(t);
		};
	}, [q, adding]);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Lists"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/markets",
					className: "text-xs text-primary hover:underline",
					children: "Markets"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto",
				children: groups.map((g) => {
					const expanded = Boolean(open[g.id]);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "border-t border-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1 px-2 py-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 flex-1 rounded-md px-1 text-left text-sm font-medium hover:bg-surface",
									onClick: () => setOpen((s) => ({
										...s,
										[g.id]: !expanded
									})),
									children: g.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex size-9 items-center justify-center rounded-full text-muted hover:bg-surface hover:text-fg",
									"aria-label": `Add symbol to ${g.name}`,
									onClick: () => {
										setAdding(true);
										setOpen((s) => ({
											...s,
											watchlist: true,
											[g.id]: true
										}));
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex size-9 items-center justify-center rounded-full text-muted hover:bg-surface hover:text-fg",
									"aria-label": expanded ? `Collapse ${g.name}` : `Expand ${g.name}`,
									onClick: () => setOpen((s) => ({
										...s,
										[g.id]: !expanded
									})),
									children: expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
								})
							]
						}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [g.symbols.map((sym) => {
							const quote = quotes[sym];
							const company = findCompany(sym);
							const ticker = displayTicker(sym);
							const name = quote?.name ?? company?.name ?? ticker;
							const href = `/quote/${encodeURIComponent(sym)}`;
							const active = pathname === href || pathname.endsWith("/" + encodeURIComponent(sym));
							const up = (quote?.change ?? 0) >= 0;
							const flat = quote != null && Math.abs(quote.changePct) < 5e-5;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/quote/$symbol",
								params: { symbol: sym },
								className: cn("grid grid-cols-[1fr_72px_auto] items-center gap-2 px-3 py-2 hover:bg-surface", active ? "bg-surface" : ""),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-[13px] font-medium tracking-tight",
											children: ticker
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-[11px] text-subtle",
											children: name
										})]
									}),
									quote?.spark?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
										data: quote.spark,
										up,
										className: "h-7 w-[72px]"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-center text-subtle",
										children: "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-[88px] text-right",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[13px] tabular-nums",
											children: quote ? formatMoney(quote.price, quote.currency) : "—"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: cn("inline-flex items-center justify-end gap-0.5 text-[11px] tabular-nums", flat ? "text-muted" : up ? "text-up" : "text-down"),
											children: [quote ? pct(quote.changePct) : "—", quote && !flat ? up ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3" }) : null]
										})]
									})
								]
							}) }, g.id + sym);
						}), g.symbols.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "px-3 py-6 text-center text-xs text-muted",
							children: "Search any NSE or BSE name to build a list."
						}) : null] }) : null]
					}, g.id);
				})
			}),
			adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium",
						children: "Add symbol"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search NSE & BSE",
						className: "h-10 w-full rounded-md border border-border bg-bg px-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 max-h-40 overflow-y-auto",
						children: hits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-center justify-between gap-2 rounded-md px-2 py-2 text-left text-sm hover:bg-surface",
							onClick: () => {
								toggleWatch(h.symbol);
								setQ("");
								setAdding(false);
								setOpen((s) => ({
									...s,
									watchlist: true
								}));
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 truncate",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: displayTicker(h.symbol)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-muted",
									children: h.name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-subtle",
								children: h.exchange
							})]
						}) }, h.symbol))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-2 text-xs text-muted hover:text-fg",
						onClick: () => {
							setAdding(false);
							setQ("");
						},
						children: "Close"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/search",
					className: "flex min-h-11 items-center gap-2 rounded-lg border border-border px-3 text-sm hover:bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Deep Search"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1 text-xs text-muted",
						children: "Google + live quotes"
					})] })]
				})
			})
		]
	});
}
/** Rehydrate local lists and profile. Cloud sync is off in this build. */
function CloudSync() {
	(0, import_react.useEffect)(() => {
		useSiply.persist.rehydrate();
	}, []);
	return null;
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "PlanVista Finance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-relaxed text-muted",
					children: "Live NSE/BSE market tracking, goal-based SIP planning and explainable research. Built as an educational product — not a brokerage, not a SEBI-registered advisor."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-wide text-subtle",
					children: "Assumptions"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-relaxed text-muted",
					children: "Equity 12% / hybrid 10% / debt 7% / gold 8% long-run (illustrative). Inflation default 6–8%. Quotes are delayed public-market snapshots. Monte Carlo is a teaching simulation, not a forecast."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-subtle",
						children: "Contact"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm font-medium text-fg",
						children: "Hardik Kumar Vimal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Product & website design"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "mailto:hardikk.vimal@gmail.com",
						className: "mt-2 inline-flex min-h-11 items-center gap-2 text-sm text-primary hover:underline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), "hardikk.vimal@gmail.com"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "tel:8076636524",
						className: "mt-1 inline-flex min-h-11 items-center gap-2 text-sm text-primary hover:underline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), "8076636524"]
					})
				] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border px-4 py-3 text-center text-[11px] text-subtle",
			children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" PlanVista Finance · Designed by Hardik Kumar Vimal · For learning purposes only"
			]
		})]
	});
}
function Ticker() {
	const [rows, setRows] = (0, import_react.useState)(TICKER.map((t) => ({
		symbol: t.symbol,
		value: "—",
		change: 0
	})));
	(0, import_react.useEffect)(() => {
		let live = true;
		const load = () => {
			getQuotes({ data: { symbols: TICKER.map((t) => t.yahoo) } }).then((quotes) => {
				if (!live) return;
				const by = new Map(quotes.map((q) => [q.symbol, q]));
				setRows(TICKER.map((t) => {
					const q = by.get(t.yahoo);
					return {
						symbol: t.symbol,
						value: q ? formatMoney(q.price, q.currency) : "—",
						change: q?.changePct ?? 0
					};
				}));
			}).catch(() => {});
		};
		load();
		const id = window.setInterval(load, 3e4);
		return () => {
			live = false;
			window.clearInterval(id);
		};
	}, []);
	const items = [...rows, ...rows];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden border-b border-border bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex w-max animate-[ticker_36s_linear_infinite] gap-8 px-4 py-2 text-xs",
			children: items.map((t, i) => {
				const up = t.change >= 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline gap-2 whitespace-nowrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-fg",
							children: t.symbol
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-fg",
							children: t.value
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("tabular-nums", up ? "text-up" : "text-down"),
							children: pct(t.change)
						})
					]
				}, t.symbol + i);
			})
		})
	});
}
var NAV = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/markets",
		label: "Markets"
	},
	{
		to: "/search",
		label: "Deep Search"
	},
	{
		to: "/portfolio",
		label: "Portfolio"
	},
	{
		to: "/planner",
		label: "Goals"
	},
	{
		to: "/sip",
		label: "SIP"
	},
	{
		to: "/learn",
		label: "Learn"
	},
	{
		to: "/progress",
		label: "Progress"
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [lists, setLists] = (0, import_react.useState)(false);
	const [research, setResearch] = (0, import_react.useState)(false);
	const { theme, toggle } = useTheme();
	const first = (useSiply((s) => s.profile.displayName) || "Hardik").split(" ")[0] || "Hardik";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudSync, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-bg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 px-2 py-2 sm:px-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface lg:hidden",
								"aria-label": "Open lists",
								onClick: () => setLists((v) => !v),
								children: lists ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "flex shrink-0 items-center gap-2 pr-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-flex size-8 items-center justify-center rounded-md bg-primary text-sm font-medium text-primary-fg",
										children: "P"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "hidden text-[20px] tracking-tight sm:inline",
										children: ["PlanVista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-1.5 text-sm text-muted",
											children: "Finance"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden rounded-sm bg-primary-soft px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary md:inline",
										children: "Beta"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, { className: "hidden max-w-xl md:block" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex shrink-0 items-center gap-1 sm:gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/search",
										className: "inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-sm text-muted hover:bg-surface hover:text-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "Deep Search"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: toggle,
										className: "inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface",
										"aria-label": theme === "dark" ? "Switch to light theme" : "Switch to dark theme",
										children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex h-9 items-center rounded-full px-3 text-sm text-muted hover:bg-surface xl:hidden",
										onClick: () => setResearch((v) => !v),
										children: "Research"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 pl-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-8 place-items-center rounded-full bg-primary text-sm font-medium text-primary-fg",
											children: first.charAt(0).toUpperCase()
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden text-sm font-medium sm:inline",
											children: first
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface md:hidden",
										"aria-label": "Open menu",
										onClick: () => setMenu((v) => !v),
										children: menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3 pb-2 md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "hidden gap-1 px-4 md:flex",
						children: NAV.map((n) => {
							const active = n.to === "/" ? pathname === "/" : pathname.startsWith(n.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: n.to,
								className: cn("border-b-2 px-3 py-2.5 text-sm", active ? "border-primary font-medium text-primary" : "border-transparent text-muted hover:border-border-strong hover:text-fg"),
								children: n.label
							}, n.to);
						})
					}),
					menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "border-t border-border px-3 py-2 md:hidden",
						children: NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: n.to,
							onClick: () => setMenu(false),
							className: "block rounded-md px-3 py-3 text-sm hover:bg-surface",
							children: n.label
						}, n.to))
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticker, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border bg-warn-soft px-3 py-1.5 text-center text-[11px] text-fg",
				children: "For learning purposes only — not investment advice, not a SEBI-registered advisor. Market data may be delayed."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-[70vh]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: cn("w-[300px] shrink-0 border-r border-border bg-rail", lists ? "fixed inset-y-0 left-0 z-30 mt-[52px] bg-bg lg:static lg:mt-0" : "hidden lg:block"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WatchlistRail, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
							className: "mx-auto max-w-5xl px-3 py-5 sm:px-5 sm:py-6",
							children
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: cn("w-[320px] shrink-0 border-l border-border bg-rail", research ? "fixed inset-y-0 right-0 z-30 mt-[52px] bg-bg xl:static xl:mt-0" : "hidden xl:block"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sticky top-[108px] h-[calc(100vh-108px)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchPanel, {})
						})
					})
				]
			})
		]
	});
}
function BareShell({ children }) {
	const { theme, toggle } = useTheme();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex size-8 items-center justify-center rounded-md bg-primary text-sm font-medium text-primary-fg",
						children: "P"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[20px] tracking-tight",
						children: ["PlanVista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1.5 text-sm text-muted",
							children: "Finance"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm bg-primary-soft px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-primary",
						children: "Beta"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: toggle,
				className: "inline-flex size-11 items-center justify-center rounded-full text-muted hover:bg-surface",
				"aria-label": "Toggle theme",
				children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
			})]
		}), children]
	});
}
var styles_default = "/assets/styles-C7Hjg_qi.css";
var APP_NAME = "PlanVista Finance";
var THEME_BOOT = `(function(){try{var t=localStorage.getItem("pv-theme");if(t==="light"){document.documentElement.classList.remove("dark");document.documentElement.style.colorScheme="light";}else{document.documentElement.classList.add("dark");document.documentElement.style.colorScheme="dark";}}catch(e){document.documentElement.classList.add("dark");}})();`;
var Route$14 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "PlanVista Finance — live NSE/BSE market tracking, SIP calculator and goal-based planning. For learning purposes only."
			},
			{
				name: "theme-color",
				content: "#131314"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "dark antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_BOOT } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellSwitch, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
function ShellSwitch() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	if (pathname === "/login" || pathname === "/onboarding" || pathname === "/report") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BareShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
var $$splitComponentImporter$13 = () => import("./routes-BmdzYH9t.mjs");
var Route$13 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./learn-CIhdK-2h.mjs");
var Route$12 = createFileRoute("/learn")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./markets-DPqh6iLV.mjs");
var Route$11 = createFileRoute("/markets")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./onboarding-D-W112E_.mjs");
var Route$10 = createFileRoute("/onboarding")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./planner-HM1coRkl.mjs");
var Route$9 = createFileRoute("/planner")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./portfolio-DPtsvkSt.mjs");
var Route$8 = createFileRoute("/portfolio")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./progress-DDqG1L5C.mjs");
var Route$7 = createFileRoute("/progress")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./quiz-DeV7vQIX.mjs");
var Route$6 = createFileRoute("/quiz")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./report-CGJXbtn2.mjs");
var Route$5 = createFileRoute("/report")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./search-D_HyuPTN.mjs");
var Route$4 = createFileRoute("/search")({
	validateSearch: (search) => ({ q: typeof search.q === "string" ? search.q : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./sip-BBHUwgw0.mjs");
var Route$3 = createFileRoute("/sip")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./goal._id-FDkSFlFM.mjs");
var Route$2 = createFileRoute("/goal/$id")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./learn._slug-Cgfqlwvj.mjs");
var Route$1 = createFileRoute("/learn/$slug")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./quote._symbol-B3HAkBa_.mjs");
var Route = createFileRoute("/quote/$symbol")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var LearnRoute = Route$12.update({
	id: "/learn",
	path: "/learn",
	getParentRoute: () => Route$14
});
var MarketsRoute = Route$11.update({
	id: "/markets",
	path: "/markets",
	getParentRoute: () => Route$14
});
var OnboardingRoute = Route$10.update({
	id: "/onboarding",
	path: "/onboarding",
	getParentRoute: () => Route$14
});
var PlannerRoute = Route$9.update({
	id: "/planner",
	path: "/planner",
	getParentRoute: () => Route$14
});
var PortfolioRoute = Route$8.update({
	id: "/portfolio",
	path: "/portfolio",
	getParentRoute: () => Route$14
});
var ProgressRoute = Route$7.update({
	id: "/progress",
	path: "/progress",
	getParentRoute: () => Route$14
});
var QuizRoute = Route$6.update({
	id: "/quiz",
	path: "/quiz",
	getParentRoute: () => Route$14
});
var ReportRoute = Route$5.update({
	id: "/report",
	path: "/report",
	getParentRoute: () => Route$14
});
var SearchRoute = Route$4.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$14
});
var SipRoute = Route$3.update({
	id: "/sip",
	path: "/sip",
	getParentRoute: () => Route$14
});
var GoalIdRoute = Route$2.update({
	id: "/goal/$id",
	path: "/goal/$id",
	getParentRoute: () => Route$14
});
var LearnSlugRoute = Route$1.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => LearnRoute
});
var QuoteSymbolRoute = Route.update({
	id: "/quote/$symbol",
	path: "/quote/$symbol",
	getParentRoute: () => Route$14
});
var LearnRouteChildren = { LearnSlugRoute };
var rootRouteChildren = {
	IndexRoute,
	LearnRoute: LearnRoute._addFileChildren(LearnRouteChildren),
	MarketsRoute,
	OnboardingRoute,
	PlannerRoute,
	PortfolioRoute,
	ProgressRoute,
	QuizRoute,
	ReportRoute,
	SearchRoute,
	SipRoute,
	GoalIdRoute,
	QuoteSymbolRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { planAll as C, createSsrRpc as D, scoreToRisk as E, QUIZ as S, projectSip as T, formatMoney as _, Route$4 as a, pct as b, HEADLINES as c, getQuoteBundle as d, getQuotes as f, cn as g, useSiply as h, Route$2 as i, deepSearch as l, CATEGORIES as m, Route as n, Sparkline as o, BADGE_META as p, Route$1 as r, ARTICLES as s, router_exports as t, getMarketHome as u, formatVol as v, planGoal as w, timeAgo as x, inr as y };
