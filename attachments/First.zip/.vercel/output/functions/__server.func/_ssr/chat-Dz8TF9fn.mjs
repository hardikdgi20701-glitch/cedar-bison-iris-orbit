import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat-Dz8TF9fn.js
var askResearch_createServerFn_handler = createServerRpc({
	id: "e8e5687cd8191f1d4cf4ae7660bf84fa1ca4f54ad65ea071f465be82ee5235ca",
	name: "askResearch",
	filename: "src/lib/chat.ts"
}, (opts) => askResearch.__executeServer(opts));
var askResearch = createServerFn({ method: "POST" }).validator((data) => {
	const d = data;
	const prompt = String(d?.prompt ?? "").trim();
	if (!prompt) throw new Error("Ask a question");
	if (prompt.length > 2e3) throw new Error("Keep questions under 2,000 characters");
	return {
		prompt,
		context: String(d?.context ?? "").slice(0, 4e3)
	};
}).handler(askResearch_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Research assistant is unavailable in this environment."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 700,
			temperature: .4,
			messages: [{
				role: "system",
				content: `You are PlanVista Finance Research, an educational market explainer for Indian (NSE/BSE) and global markets.
Rules:
- For learning purposes only. Not investment advice, not a SEBI-registered advisor, not a recommendation to buy or sell.
- Be concise, structured, and calm. Use short paragraphs and bullet points.
- If you cite numbers from the provided context, treat them as delayed public-market snapshots that may be stale.
- If data is missing, say so. Do not invent filings, insider information, or guaranteed returns.
- Prefer explaining *why* a move or ratio matters over telling the user what to do.
- End with a one-line reminder: "For learning purposes only."`
			}, {
				role: "user",
				content: data.context ? `Context:\n${data.context}\n\nQuestion: ${data.prompt}` : data.prompt
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `Research assistant error (${res.status}). Try again.`
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "Empty response. Try a more specific question."
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { askResearch_createServerFn_handler };
