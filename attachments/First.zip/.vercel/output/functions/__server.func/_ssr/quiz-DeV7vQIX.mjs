import { i as __toESM } from "../_runtime.mjs";
import { V as require_react, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as scoreToRisk, S as QUIZ, h as useSiply } from "./router-DAvrQrMU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-DeV7vQIX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Quiz() {
	const completeQuiz = useSiply((s) => s.completeQuiz);
	const navigate = useNavigate();
	const [i, setI] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)([]);
	const q = QUIZ[i];
	const done = answers.length === QUIZ.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-wide text-subtle",
				children: "Risk questionnaire"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-medium tracking-tight",
				children: "Seven questions. One mix."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "This is a teaching profile for student goals — not a SEBI-registered assessment."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-1 overflow-hidden rounded-full bg-chip",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-primary transition-[width] duration-200",
					style: { width: `${Math.min(answers.length, QUIZ.length) / QUIZ.length * 100}%` }
				})
			}),
			done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-lg border border-border p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Your mapped profile"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-3xl font-medium capitalize",
						children: scoreToRisk(answers)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Score ",
							answers.reduce((a, b) => a + b, 0),
							" / ",
							QUIZ.length * 2,
							". Conservative ≤5, moderate ≤10, else aggressive. Emergency goals still use a debt-heavy sleeve."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-5 inline-flex h-11 items-center rounded-full bg-primary px-5 text-sm font-medium text-primary-fg hover:bg-primary-hover",
						onClick: () => {
							completeQuiz(answers);
							navigate({ to: "/portfolio" });
						},
						children: "Save and open portfolio"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							i + 1,
							" of ",
							QUIZ.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-lg font-medium",
						children: q.q
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-2",
						children: q.options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex min-h-12 w-full items-center rounded-md border border-border px-3 py-3 text-left text-sm hover:border-primary hover:bg-primary-soft",
							onClick: () => {
								const next = [...answers, o.score];
								setAnswers(next);
								setI((v) => v + 1);
							},
							children: o.label
						}) }, o.label))
					})
				]
			})
		]
	});
}
//#endregion
export { Quiz as component };
