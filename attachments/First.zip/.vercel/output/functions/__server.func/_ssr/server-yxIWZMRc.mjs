import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as displayTicker, c as googleFinanceSearchUrl, d as nseSession, f as searchUniverse, l as googleNewsUrl, o as findCompany, r as INDICES, s as googleFinanceQuoteUrl, u as googleSearchUrl } from "./universe-DCkNyMnJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-yxIWZMRc.js
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
var cache = /* @__PURE__ */ new Map();
function cached(key, ttlMs, fn) {
	const hit = cache.get(key);
	if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value);
	return fn().then((value) => {
		cache.set(key, {
			at: Date.now(),
			value
		});
		return value;
	});
}
async function yahooJson(url) {
	const res = await fetch(url, { headers: {
		"User-Agent": UA,
		Accept: "application/json,text/plain,*/*",
		"Accept-Language": "en-IN,en;q=0.9"
	} });
	if (!res.ok) throw new Error(`Yahoo ${res.status}`);
	return res.json();
}
var RANGE_MAP = {
	"1d": {
		range: "1d",
		interval: "2m"
	},
	"5d": {
		range: "5d",
		interval: "15m"
	},
	"1mo": {
		range: "1mo",
		interval: "1d"
	},
	"6mo": {
		range: "6mo",
		interval: "1d"
	},
	ytd: {
		range: "ytd",
		interval: "1d"
	},
	"1y": {
		range: "1y",
		interval: "1d"
	},
	"5y": {
		range: "5y",
		interval: "1wk"
	},
	max: {
		range: "max",
		interval: "1mo"
	}
};
function sparkFrom(closes, n = 28) {
	if (closes.length <= n) return closes;
	const step = (closes.length - 1) / (n - 1);
	const out = [];
	for (let i = 0; i < n; i++) out.push(closes[Math.round(i * step)]);
	return out;
}
function sessionState() {
	return nseSession().open ? "open" : "closed";
}
async function fetchChart(symbol, range) {
	const spec = RANGE_MAP[range];
	const result = (await yahooJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${spec.interval}&range=${spec.range}&includePrePost=false`)).chart?.result?.[0];
	if (!result) throw new Error("No chart data");
	const meta = result.meta;
	const ts = result.timestamp ?? [];
	const close = result.indicators?.quote?.[0]?.close ?? [];
	const vol = result.indicators?.quote?.[0]?.volume ?? [];
	const points = [];
	const closes = [];
	for (let i = 0; i < ts.length; i++) {
		const c = close[i];
		if (c == null || !Number.isFinite(c)) continue;
		points.push({
			t: ts[i] * 1e3,
			close: c,
			volume: vol[i] ?? null
		});
		closes.push(c);
	}
	const price = meta.regularMarketPrice ?? closes[closes.length - 1] ?? 0;
	const prev = meta.previousClose ?? meta.chartPreviousClose ?? closes[0] ?? price;
	const change = price - prev;
	const changePct = prev ? change / prev : 0;
	const company = findCompany(symbol);
	const quote = {
		symbol,
		name: company?.name ?? meta.longName ?? meta.shortName ?? symbol,
		shortName: meta.shortName ?? company?.symbol ?? symbol,
		exchange: meta.fullExchangeName ?? meta.exchangeName ?? company?.exchange ?? "",
		currency: meta.currency ?? "INR",
		price,
		previousClose: prev,
		change,
		changePct,
		dayHigh: meta.regularMarketDayHigh ?? null,
		dayLow: meta.regularMarketDayLow ?? null,
		volume: meta.regularMarketVolume ?? null,
		fiftyTwoWeekHigh: meta.fiftyTwoWeekHigh ?? null,
		fiftyTwoWeekLow: meta.fiftyTwoWeekLow ?? null,
		spark: sparkFrom(closes),
		marketState: sessionState()
	};
	return {
		quote,
		series: {
			symbol,
			range,
			previousClose: prev,
			currency: quote.currency,
			points
		}
	};
}
function parseRss(xml) {
	const items = [];
	const blocks = xml.match(/<item>[\s\S]*?<\/item>/g) ?? [];
	for (const block of blocks) {
		const title = decodeXml(tag(block, "title"));
		const link = decodeXml(tag(block, "link"));
		const source = decodeXml((block.match(/<source[^>]*>([\s\S]*?)<\/source>/) ?? [])[1] ?? "") || decodeXml(tag(block, "dc:creator")) || "News";
		const published = decodeXml(tag(block, "pubDate"));
		if (!title) continue;
		items.push({
			title: title.replace(/ - [^-]+$/, (m) => source ? "" : m).trim() || title,
			source,
			url: link,
			published
		});
		if (items.length >= 10) break;
	}
	return items;
}
function tag(block, name) {
	return (block.match(new RegExp(`<${name}[^>]*><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/${name}>`)) ?? block.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)<\\/${name}>`)))?.[1]?.trim() ?? "";
}
function decodeXml(s) {
	return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/"/g, "\"").replace(/&#39;/g, "'").replace(/'/g, "'");
}
async function fetchNews(query) {
	const url = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-IN&gl=IN&ceid=IN:en`;
	const res = await fetch(url, { headers: { "User-Agent": UA } });
	if (!res.ok) return [];
	return parseRss(await res.text());
}
async function fetchIndiaHeadlines() {
	const url = "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms";
	try {
		const res = await fetch(url, { headers: { "User-Agent": UA } });
		if (!res.ok) throw new Error("et");
		return parseRss(await res.text());
	} catch {
		return fetchNews("India stock market Nifty Sensex");
	}
}
async function yahooSearch(q, indiaOnly = true) {
	return ((await yahooJson(`https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=12&newsCount=0`)).quotes ?? []).filter((x) => x.symbol && (x.quoteType === "EQUITY" || x.quoteType === "INDEX" || x.quoteType === "ETF")).map((x) => ({
		symbol: x.symbol,
		name: x.longname ?? x.shortname ?? x.symbol,
		exchange: x.exchDisp ?? x.exchange ?? "",
		type: x.quoteType ?? "EQUITY"
	})).filter((r) => {
		if (!indiaOnly) return true;
		const ex = r.exchange.toUpperCase();
		return r.symbol.endsWith(".NS") || r.symbol.endsWith(".BO") || ex.includes("NSE") || ex.includes("BSE") || ex.includes("BOMBAY") || r.symbol.startsWith("^") || r.type === "INDEX";
	});
}
function analysisFrom(quote, yearCloses, profile) {
	const lines = [];
	const { price, changePct, fiftyTwoWeekHigh, fiftyTwoWeekLow, dayHigh, dayLow } = quote;
	const up = changePct >= 0;
	lines.push(`${quote.name} is ${up ? "up" : "down"} ${(Math.abs(changePct) * 100).toFixed(2)}% versus the previous close, trading at ${formatPx(price, quote.currency)}.`);
	if (fiftyTwoWeekHigh && fiftyTwoWeekLow) {
		const vsHigh = (price / fiftyTwoWeekHigh - 1) * 100;
		const span = fiftyTwoWeekHigh - fiftyTwoWeekLow || 1;
		const pos = (price - fiftyTwoWeekLow) / span * 100;
		lines.push(`The stock is ${Math.abs(vsHigh).toFixed(1)}% ${vsHigh >= 0 ? "above" : "below"} its 52-week high of ${formatPx(fiftyTwoWeekHigh, quote.currency)}, sitting near the ${pos.toFixed(0)}th percentile of the 52-week range.`);
	}
	if (dayHigh && dayLow) lines.push(`Today’s range is ${formatPx(dayLow, quote.currency)} – ${formatPx(dayHigh, quote.currency)}.`);
	if (yearCloses.length > 20) {
		const ago = yearCloses[0];
		const ret = ago ? (price / ago - 1) * 100 : 0;
		lines.push(`Over the available 1-year window the last close implies a ${ret >= 0 ? "gain" : "decline"} of ${Math.abs(ret).toFixed(1)}%.`);
	}
	if (profile?.quarters?.length) {
		const last = profile.quarters[profile.quarters.length - 1];
		if (last.yoyRevenue != null) lines.push(`Latest compiled quarter (${last.label}) shows revenue ${last.yoyRevenue >= 0 ? "up" : "down"} ${(Math.abs(last.yoyRevenue) * 100).toFixed(1)}% YoY` + (last.yoyPat != null ? ` and PAT ${last.yoyPat >= 0 ? "up" : "down"} ${(Math.abs(last.yoyPat) * 100).toFixed(1)}% YoY.` : "."));
	}
	lines.push("This is an educational snapshot built from public market data — not a recommendation to buy or sell.");
	return lines;
}
function formatPx(n, ccy) {
	if (ccy === "INR" || ccy === "USD") return (ccy === "INR" ? "₹" : "$") + n.toLocaleString(ccy === "INR" ? "en-IN" : "en-US", { maximumFractionDigits: n >= 100 ? 2 : 4 });
	return n.toLocaleString("en-IN", { maximumFractionDigits: 2 }) + " " + ccy;
}
function retFrom(closes, days, price) {
	if (closes.length < days) return null;
	const base = closes[closes.length - 1 - days];
	if (!base) return null;
	return price / base - 1;
}
var getQuotes_createServerFn_handler = createServerRpc({
	id: "5948da8bf4c04fa12b5a432843bb3a7036103dc6f3e924194d39a3211ad6f650",
	name: "getQuotes",
	filename: "src/lib/market/server.ts"
}, (opts) => getQuotes.__executeServer(opts));
var getQuotes = createServerFn({ method: "POST" }).validator((data) => {
	const symbols = data?.symbols;
	if (!Array.isArray(symbols)) throw new Error("symbols required");
	return { symbols: symbols.slice(0, 40).map(String) };
}).handler(getQuotes_createServerFn_handler, async ({ data }) => {
	const out = [];
	await Promise.all(data.symbols.map(async (sym) => {
		try {
			const row = await cached(`q:${sym}`, 2e4, () => fetchChart(sym, "1mo"));
			out.push(row.quote);
		} catch {}
	}));
	const order = new Map(data.symbols.map((s, i) => [s, i]));
	out.sort((a, b) => (order.get(a.symbol) ?? 0) - (order.get(b.symbol) ?? 0));
	return out;
});
var getChart_createServerFn_handler = createServerRpc({
	id: "a04b39d305727adcd6ad9cb315ab77e37f8791cd7d5e940e045bcb457dff4725",
	name: "getChart",
	filename: "src/lib/market/server.ts"
}, (opts) => getChart.__executeServer(opts));
var getChart = createServerFn({ method: "POST" }).validator((data) => {
	const d = data;
	if (!d?.symbol) throw new Error("symbol required");
	const range = d.range ?? "1d";
	if (!(range in RANGE_MAP)) throw new Error("bad range");
	return {
		symbol: String(d.symbol),
		range
	};
}).handler(getChart_createServerFn_handler, async ({ data }) => {
	return (await cached(`c:${data.symbol}:${data.range}`, 15e3, () => fetchChart(data.symbol, data.range))).series;
});
var getQuoteBundle_createServerFn_handler = createServerRpc({
	id: "b354a524a6cbba392d0645cea016f451d312080d2b0c965435be457138c033ac",
	name: "getQuoteBundle",
	filename: "src/lib/market/server.ts"
}, (opts) => getQuoteBundle.__executeServer(opts));
var getQuoteBundle = createServerFn({ method: "POST" }).validator((data) => {
	const d = data;
	if (!d?.symbol) throw new Error("symbol required");
	return {
		symbol: String(d.symbol),
		range: d.range ?? "1d"
	};
}).handler(getQuoteBundle_createServerFn_handler, async ({ data }) => {
	const profile = findCompany(data.symbol) ?? null;
	const yahoo = profile?.yahoo ?? data.symbol;
	const [main, year] = await Promise.all([cached(`c:${yahoo}:${data.range}`, 15e3, () => fetchChart(yahoo, data.range)), cached(`c:${yahoo}:1y`, 6e4, () => fetchChart(yahoo, "1y")).catch(() => null)]);
	const yearCloses = year?.series.points.map((p) => p.close) ?? [];
	const newsQuery = profile ? `${profile.name} stock` : `${main.quote.name} stock`;
	const news = await cached(`n:${newsQuery}`, 12e4, () => fetchNews(newsQuery)).catch(() => []);
	const avgVolume = year && year.series.points.length ? year.series.points.reduce((s, p) => s + (p.volume ?? 0), 0) / year.series.points.length : null;
	const marketCap = profile?.sharesCr && main.quote.price ? profile.sharesCr * 1e7 * main.quote.price : null;
	const vs52wHigh = main.quote.fiftyTwoWeekHigh && main.quote.fiftyTwoWeekHigh > 0 ? main.quote.price / main.quote.fiftyTwoWeekHigh - 1 : null;
	return {
		quote: {
			...main.quote,
			spark: year?.quote.spark ?? main.quote.spark
		},
		chart: main.series,
		profile,
		news,
		analysis: analysisFrom(main.quote, yearCloses, profile),
		stats: {
			open: main.series.points[0]?.close ?? null,
			avgVolume,
			marketCap,
			pe: profile?.pe ?? null,
			eps: profile?.eps ?? null,
			employees: profile?.employees ?? null,
			return1m: yearCloses.length ? retFrom(yearCloses, 21, main.quote.price) : null,
			return1y: yearCloses.length > 2 ? main.quote.price / yearCloses[0] - 1 : null,
			vs52wHigh
		},
		delayed: false
	};
});
var searchSymbols_createServerFn_handler = createServerRpc({
	id: "c92fff7a71d6b66371a7fb00eccfda99f9b3a5a18eec9613d8925e8f284ad937",
	name: "searchSymbols",
	filename: "src/lib/market/server.ts"
}, (opts) => searchSymbols.__executeServer(opts));
var searchSymbols = createServerFn({ method: "POST" }).validator((data) => {
	return { q: String(data?.q ?? "").trim() };
}).handler(searchSymbols_createServerFn_handler, async ({ data }) => {
	const q = data.q;
	if (q.length < 1) return {
		local: [],
		remote: []
	};
	const local = searchUniverse(q, 8);
	let remote = [];
	if (q.length >= 2) try {
		remote = await cached(`s:${q.toLowerCase()}`, 6e4, () => yahooSearch(q, true));
		const localYahoo = new Set(local.map((c) => c.yahoo.toUpperCase()));
		remote = remote.filter((r) => !localYahoo.has(r.symbol.toUpperCase()));
	} catch {
		remote = [];
	}
	return {
		local,
		remote: remote.slice(0, 8)
	};
});
var deepSearch_createServerFn_handler = createServerRpc({
	id: "2511b9cef7a308ff5ec82e09bd3b563ad5c75799f7f4c3af8fa8d4fc1defe76d",
	name: "deepSearch",
	filename: "src/lib/market/server.ts"
}, (opts) => deepSearch.__executeServer(opts));
var deepSearch = createServerFn({ method: "POST" }).validator((data) => {
	const q = String(data?.q ?? "").trim();
	if (q.length > 80) throw new Error("Keep searches under 80 characters");
	return { q };
}).handler(deepSearch_createServerFn_handler, async ({ data }) => {
	const q = data.q;
	const empty = {
		query: q,
		hits: [],
		quotes: [],
		news: [],
		googleFinanceSearch: googleFinanceSearchUrl(q || "Nifty 50"),
		googleSearch: googleSearchUrl(`${q || "Indian stock market"} NSE BSE`)
	};
	if (q.length < 1) return empty;
	const local = searchUniverse(q, 10);
	let remote = [];
	try {
		remote = await cached(`ds:${q.toLowerCase()}`, 6e4, () => yahooSearch(q, false));
	} catch {
		remote = [];
	}
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	for (const c of local) {
		const key = c.yahoo.toUpperCase();
		if (seen.has(key)) continue;
		seen.add(key);
		hits.push({
			symbol: c.yahoo,
			ticker: c.symbol,
			name: c.name,
			exchange: c.exchange,
			googleFinance: googleFinanceQuoteUrl(c.yahoo),
			googleSearch: googleSearchUrl(`${c.name} stock NSE`),
			googleNews: googleNewsUrl(`${c.name} stock`)
		});
	}
	for (const r of remote) {
		const key = r.symbol.toUpperCase();
		if (seen.has(key)) continue;
		seen.add(key);
		hits.push({
			symbol: r.symbol,
			ticker: displayTicker(r.symbol),
			name: r.name,
			exchange: r.exchange || r.type,
			googleFinance: googleFinanceQuoteUrl(r.symbol),
			googleSearch: googleSearchUrl(`${r.name} stock`),
			googleNews: googleNewsUrl(`${r.name} stock`)
		});
	}
	const top = hits.slice(0, 10);
	const quotes = [];
	await Promise.all(top.map(async (h) => {
		try {
			const row = await cached(`q:${h.symbol}`, 2e4, () => fetchChart(h.symbol, "1mo"));
			quotes.push(row.quote);
		} catch {}
	}));
	return {
		query: q,
		hits: top,
		quotes,
		news: await cached(`n:ds:${q.toLowerCase()}`, 12e4, () => fetchNews(`${q} stock India`)).catch(() => []),
		googleFinanceSearch: googleFinanceSearchUrl(q),
		googleSearch: googleSearchUrl(`${q} NSE BSE stock`)
	};
});
var getMarketHome_createServerFn_handler = createServerRpc({
	id: "1032937a8477871338630ae8ff42a84bcde9f05f7f24c728920eb9ee81fa0105",
	name: "getMarketHome",
	filename: "src/lib/market/server.ts"
}, (opts) => getMarketHome.__executeServer(opts));
var getMarketHome = createServerFn({ method: "POST" }).validator((data) => {
	return { region: String(data?.region ?? "india") };
}).handler(getMarketHome_createServerFn_handler, async ({ data }) => {
	const list = INDICES.filter((i) => i.region === data.region).slice(0, 4);
	const quotes = [];
	await Promise.all(list.map(async (i) => {
		try {
			const row = await cached(`q:${i.yahoo}`, 2e4, () => fetchChart(i.yahoo, "1mo"));
			quotes.push({
				...row.quote,
				name: i.name,
				shortName: i.name
			});
		} catch {}
	}));
	return {
		quotes,
		news: await cached("n:india-home", 18e4, () => fetchIndiaHeadlines()).catch(() => []),
		session: nseSession(),
		region: data.region
	};
});
var getIndexList_createServerFn_handler = createServerRpc({
	id: "76936a157cae8e3a2f21f3c4632688d31273503a1515bffe40bb4eccdd043ccb",
	name: "getIndexList",
	filename: "src/lib/market/server.ts"
}, (opts) => getIndexList.__executeServer(opts));
var getIndexList = createServerFn({ method: "GET" }).handler(getIndexList_createServerFn_handler, async () => {
	return INDICES;
});
//#endregion
export { deepSearch_createServerFn_handler, getChart_createServerFn_handler, getIndexList_createServerFn_handler, getMarketHome_createServerFn_handler, getQuoteBundle_createServerFn_handler, getQuotes_createServerFn_handler, searchSymbols_createServerFn_handler };
