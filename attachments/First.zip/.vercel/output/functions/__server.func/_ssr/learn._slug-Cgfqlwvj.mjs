import { i as __toESM } from "../_runtime.mjs";
import { V as require_react, v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as useSiply, r as Route$1, s as ARTICLES } from "./router-DAvrQrMU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn._slug-Cgfqlwvj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Article() {
	const { slug } = Route$1.useParams();
	const article = ARTICLES.find((a) => a.slug === slug);
	const markRead = useSiply((s) => s.markRead);
	(0, import_react.useEffect)(() => {
		if (article) markRead(article.slug);
	}, [article, markRead]);
	if (!article) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "py-16 text-center text-muted",
		children: [
			"Article missing.",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/learn",
				className: "text-primary hover:underline",
				children: "All explainers"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/learn",
				className: "text-xs text-primary hover:underline",
				children: "All explainers"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-[11px] font-medium uppercase tracking-wide text-primary",
				children: article.kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-3xl font-medium tracking-tight",
				children: article.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-subtle",
				children: [article.minutes, " min read"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-4 text-[15px] leading-relaxed text-fg",
				children: article.body.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: p }, p.slice(0, 24)))
			})
		]
	});
}
//#endregion
export { Article as component };
