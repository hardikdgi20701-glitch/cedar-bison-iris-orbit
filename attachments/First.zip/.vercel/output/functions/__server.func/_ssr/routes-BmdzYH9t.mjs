import { i as __toESM } from "../_runtime.mjs";
import { V as require_react, v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as formatMoney, b as pct, c as HEADLINES, g as cn, h as useSiply, o as Sparkline, p as BADGE_META, u as getMarketHome, x as timeAgo } from "./router-DAvrQrMU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BmdzYH9t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REGIONS = [
	{
		id: "india",
		label: "India"
	},
	{
		id: "us",
		label: "US"
	},
	{
		id: "europe",
		label: "Europe"
	},
	{
		id: "fx",
		label: "Currencies"
	},
	{
		id: "crypto",
		label: "Crypto"
	}
];
function Home() {
	const [region, setRegion] = (0, import_react.useState)("india");
	const [quotes, setQuotes] = (0, import_react.useState)([]);
	const [news, setNews] = (0, import_react.useState)([]);
	const [session, setSession] = (0, import_react.useState)({
		open: false,
		label: "NSE closed"
	});
	const [busy, setBusy] = (0, import_react.useState)(true);
	const profile = useSiply((s) => s.profile);
	const badges = useSiply((s) => s.badges);
	(0, import_react.useEffect)(() => {
		let live = true;
		setBusy(true);
		getMarketHome({ data: { region } }).then((res) => {
			if (!live) return;
			setQuotes(res.quotes);
			setNews(res.news);
			setSession(res.session);
		}).catch(() => {
			if (live) {
				setQuotes([]);
				setNews([]);
			}
		}).finally(() => {
			if (live) setBusy(false);
		});
		return () => {
			live = false;
		};
	}, [region]);
	const lead = news[0];
	const rest = news.slice(1, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-medium tracking-tight",
					children: "Markets"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Live NSE & BSE quotes · ",
						session.label,
						profile.displayName ? ` · Welcome back, ${profile.displayName.split(" ")[0]}` : ""
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/search",
						className: "inline-flex h-10 items-center rounded-full border border-border px-4 text-sm font-medium hover:bg-surface",
						children: "Deep Search"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sip",
						className: "inline-flex h-10 items-center rounded-full bg-primary px-4 text-sm font-medium text-primary-fg hover:bg-primary-hover",
						children: "SIP calculator"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1",
				children: REGIONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setRegion(r.id),
					className: cn("h-9 rounded-full px-4 text-sm", region === r.id ? "bg-chip font-medium text-fg" : "text-muted hover:bg-surface hover:text-fg"),
					children: r.label
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: (busy && quotes.length === 0 ? [
					0,
					1,
					2,
					3
				] : quotes).map((q, i) => typeof q === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-32 animate-pulse rounded-xl border border-border bg-surface" }, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/quote/$symbol",
					params: { symbol: q.symbol },
					className: "rounded-xl border border-border p-4 hover:bg-surface",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: q.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-2xl font-medium tabular-nums tracking-tight",
							children: formatMoney(q.price, q.currency)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("text-sm tabular-nums", q.change >= 0 ? "text-up" : "text-down"),
							children: pct(q.changePct)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
							data: q.spark,
							up: q.change >= 0,
							className: "mt-2 h-10 w-full"
						})
					]
				}, q.symbol))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-medium",
					children: region === "india" ? "India market summary" : "Market summary"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/markets",
					className: "text-sm text-primary hover:underline",
					children: "All markets"
				})]
			}), lead ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							lead.source,
							" · ",
							timeAgo(lead.published)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: lead.url,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-1 block text-lg font-medium hover:text-primary",
						children: lead.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 divide-y divide-border",
						children: rest.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: n.url,
							target: "_blank",
							rel: "noreferrer",
							className: "flex items-start justify-between gap-3 py-3 text-sm hover:text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: n.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-xs text-subtle",
								children: n.source
							})]
						}, n.url + n.title))
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl border border-border p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Classroom tape"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: HEADLINES.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/learn",
						className: "text-sm hover:text-primary",
						children: h.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-subtle",
						children: [
							h.source,
							" · ",
							h.time
						]
					})] }, h.title))
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/planner",
						className: "rounded-xl border border-border p-4 hover:bg-surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wide text-subtle",
								children: "Goals"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-lg font-medium",
								children: "Build a SIP watchlist"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Name a goal, inflate the cost, see the monthly SIP."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/learn",
						className: "rounded-xl border border-border p-4 hover:bg-surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wide text-subtle",
								children: "Learn"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-lg font-medium",
								children: "Short explainers"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "SIP, inflation, index funds, step-ups — written for first-timers."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wide text-subtle",
							children: "Badges"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-2 flex flex-wrap gap-1.5",
							children: [badges.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-full bg-primary-soft px-2.5 py-1 text-[11px] font-medium text-primary",
								children: BADGE_META[b].label
							}, b)), badges.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-xs text-muted",
								children: "Sign in and complete onboarding to start."
							}) : null]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
