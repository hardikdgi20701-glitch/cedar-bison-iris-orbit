import { Link, useNavigate } from "@tanstack/react-router";
import {
  BarChart3,
  BookOpen,
  Building2,
  CalendarDays,
  ChevronDown,
  LineChart,
  PieChart,
  Radio,
  Search,
  Shield,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Sparkline } from "@/components/charts/Sparkline";
import { TapeStamp } from "@/components/markets/TapeStamp";
import { useLiveRefresh } from "@/hooks/useLiveRefresh";
import { getNseDesk, type NseDeskStats, type NseSectorBook } from "@/lib/market/server";
import { upcomingNseHolidays } from "@/lib/market/universe";
import type { ChartSeries, MarketQuote, NewsItem } from "@/lib/market/types";
import { cn, formatMoney, formatVol, pct, timeAgo } from "@/lib/utils";

type RangeKey = "1d" | "5d" | "1mo" | "6mo" | "1y";

const RANGES: { id: RangeKey; label: string }[] = [
  { id: "1d", label: "1D" },
  { id: "5d", label: "5D" },
  { id: "1mo", label: "1M" },
  { id: "6mo", label: "6M" },
  { id: "1y", label: "1Y" },
];

const UTILITY = [
  { to: "/analytics", label: "Analytics" },
  { to: "/chart-gpt", label: "Chart GPT" },
  { to: "/markets", label: "Live market" },
  { to: "/learn", label: "Listings / IPO" },
  { to: "/search", label: "Corporates" },
  { to: "/report", label: "Daily report" },
  { to: "/quiz", label: "Risk quiz" },
] as const;

const MENUS: { label: string; items: { to: string; label: string }[] }[] = [
  {
    label: "Market data",
    items: [
      { to: "/markets", label: "Live market" },
      { to: "/nse", label: "NSE desk" },
      { to: "/search", label: "Deep search" },
      { to: "/chart-gpt", label: "Chart GPT" },
    ],
  },
  {
    label: "Learn",
    items: [
      { to: "/learn", label: "Classroom" },
      { to: "/gate", label: "Knowledge gate" },
      { to: "/chart-gpt", label: "How to read a chart" },
      { to: "/nse", label: "Holiday calendar" },
      { to: "/quiz", label: "Risk quiz" },
    ],
  },
  {
    label: "Plan",
    items: [
      { to: "/sip", label: "SIP calculator" },
      { to: "/planner", label: "Goals" },
      { to: "/portfolio", label: "Portfolio" },
      { to: "/analytics", label: "Analytics" },
    ],
  },
  {
    label: "Account",
    items: [
      { to: "/quiz", label: "Sign in for risk quiz" },
      { to: "/onboarding", label: "Register / onboarding" },
      { to: "/progress", label: "Progress" },
    ],
  },
];

const QUICK = [
  { to: "/markets", title: "Live market", body: "Indices, sectors and last prints", icon: LineChart },
  { to: "/chart-gpt", title: "Chart GPT", body: "Ask how to read this session", icon: Radio },
  { to: "/search", title: "Deep search", body: "Any NSE / BSE name, then Google", icon: Search },
  { to: "/learn", title: "Investor classroom", body: "Shares, SIPs, stops — in plain words", icon: BookOpen },
  { to: "/quiz", title: "Risk quiz", body: "Sign in each time · 18+ · education only", icon: Shield },
  { to: "/analytics", title: "Analytics", body: "Goals, mix and progress", icon: PieChart },
] as const;

const HI: Record<string, string> = {
  "NSE desk": "NSE डेस्क",
  "Classroom board": "कक्षा बोर्ड",
  "Key indices": "मुख्य सूचकांक",
  "Market statistics": "बाजार आँकड़े",
  "Tracked book": "ट्रैक बुक",
  "Quick access": "त्वरित पहुँच",
  "Headlines": "सुर्खियाँ",
  "Top movers": "टॉप मूवर्स",
  "Gainers": "गेनर्स",
  "Losers": "लूजर्स",
  "Most active": "सबसे सक्रिय",
  "Holidays": "अवकाश",
  "IPOs & listings": "आईपीओ और लिस्टिंग",
  "How to read this desk": "इस डेस्क को कैसे पढ़ें",
};

function t(lang: "en" | "hi", en: string) {
  return lang === "hi" ? (HI[en] ?? en) : en;
}

function istStamp(ms: number) {
  if (!ms) return "—";
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).format(new Date(ms));
}

export function NseBoard() {
  const navigate = useNavigate();
  const [range, setRange] = useState<RangeKey>("1d");
  const [lang, setLang] = useState<"en" | "hi">("en");
  const [font, setFont] = useState(14);
  const [contrast, setContrast] = useState(false);
  const [query, setQuery] = useState("");
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [nifty, setNifty] = useState<MarketQuote | null>(null);
  const [chart, setChart] = useState<ChartSeries | null>(null);
  const [openPx, setOpenPx] = useState<number | null>(null);
  const [indices, setIndices] = useState<MarketQuote[]>([]);
  const [stocks, setStocks] = useState<MarketQuote[]>([]);
  const [book, setBook] = useState<NseSectorBook[]>([]);
  const [stats, setStats] = useState<NseDeskStats | null>(null);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [session, setSession] = useState({ open: false, label: "NSE closed" });
  const [asOf, setAsOf] = useState(0);
  const [source, setSource] = useState<"live" | "cached" | "simulated">("simulated");
  const [busy, setBusy] = useState(true);
  const [tick, setTick] = useState(0);

  useLiveRefresh(() => {
    void getNseDesk({ data: { range, fresh: true } })
      .then((res) => {
        setNifty(res.nifty);
        setChart(res.niftyChart);
        setOpenPx(res.open);
        setIndices(res.indices);
        setStocks(res.stocks);
        setBook(res.book);
        setStats(res.stats);
        setNews(res.news);
        setSession(res.session);
        setAsOf(res.asOf);
        setSource(res.source);
      })
      .finally(() => setBusy(false));
  }, 20_000, [range, tick]);

  const spark = useMemo(() => chart?.points.map((p) => p.close) ?? nifty?.spark ?? [], [chart, nifty]);
  const up = (nifty?.change ?? 0) >= 0;
  const tape = [...stocks, ...stocks];
  const holidays = useMemo(() => upcomingNseHolidays(), [asOf]);
  const gainers = useMemo(
    () => [...stocks].sort((a, b) => b.changePct - a.changePct).slice(0, 5),
    [stocks],
  );
  const losers = useMemo(
    () => [...stocks].sort((a, b) => a.changePct - b.changePct).slice(0, 5),
    [stocks],
  );
  const active = useMemo(
    () => [...stocks].sort((a, b) => (b.volume ?? 0) - (a.volume ?? 0)).slice(0, 5),
    [stocks],
  );
  const ipoNews = useMemo(
    () => news.filter((n) => /ipo|listing|issue|sebi|offer/i.test(n.title)).slice(0, 3),
    [news],
  );

  function searchGo() {
    const q = query.trim();
    if (!q) return;
    void navigate({ to: "/search", search: { q } });
  }

  return (
    <div
      className={cn("nse-desk min-h-screen bg-nse-wash text-nse-fg", contrast && "nse-contrast")}
      style={{ fontSize: `${font}px` }}
    >
      <div className="bg-nse-deep text-[0.85em] text-nse-mist">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-3 py-1.5">
          <div className="flex flex-wrap gap-x-3 gap-y-1">
            {UTILITY.map((u) => (
              <Link key={u.to} to={u.to} className="hover:text-nse-ink">
                {u.label}
              </Link>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="sr-only" htmlFor="nse-lang">
              Language
            </label>
            <select
              id="nse-lang"
              className="h-8 rounded-sm border border-nse-ink/20 bg-transparent px-2 text-[0.85em] text-nse-ink"
              value={lang}
              onChange={(e) => setLang(e.target.value as "en" | "hi")}
            >
              <option value="en">English</option>
              <option value="hi">हिन्दी</option>
            </select>
            <span className="text-nse-mist">Font</span>
            <button type="button" className="h-8 rounded-sm bg-nse-ink/15 px-2 text-nse-ink" onClick={() => setFont((n) => Math.min(18, n + 1))}>
              A+
            </button>
            <button type="button" className="h-8 rounded-sm bg-nse-ink/15 px-2 text-nse-ink" onClick={() => setFont(14)}>
              Reset
            </button>
            <button type="button" className="h-8 rounded-sm bg-nse-ink/15 px-2 text-nse-ink" onClick={() => setFont((n) => Math.max(12, n - 1))}>
              A-
            </button>
            <button
              type="button"
              className="h-8 rounded-sm bg-nse-ink/15 px-2 text-nse-ink"
              onClick={() => setContrast((v) => !v)}
            >
              Contrast
            </button>
          </div>
        </div>
      </div>

      <header className="border-b border-nse-line bg-nse-card">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-3 py-3">
          <Link to="/" className="flex min-w-0 items-center gap-2">
            <img src="/planvista-icon.png" alt="" className="size-9 object-contain" width={36} height={36} />
            <span className="leading-tight">
              <span className="block text-sm font-semibold text-nse">{t(lang, "NSE desk")}</span>
              <span className="block text-[11px] text-nse-muted">PlanVista · {t(lang, "Classroom board")}</span>
            </span>
          </Link>
          <form
            className="flex min-w-0 flex-1 overflow-hidden rounded-sm border border-nse-line bg-nse-card"
            onSubmit={(e) => {
              e.preventDefault();
              searchGo();
            }}
          >
            <input
              className="h-11 min-w-0 flex-1 bg-transparent px-3 text-sm text-nse-fg outline-none"
              placeholder="Search company / stock / index…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button type="submit" className="inline-flex h-11 items-center gap-1 bg-nse px-3 text-nse-ink" aria-label="Search">
              <Search className="size-4" />
            </button>
          </form>
          <div className="flex gap-2">
            <Link
              to="/quiz"
              className="inline-flex h-11 items-center rounded-sm border border-nse px-3 text-sm font-medium text-nse"
            >
              Login
            </Link>
            <Link
              to="/onboarding"
              className="inline-flex h-11 items-center rounded-sm bg-nse-accent px-3 text-sm font-medium text-nse-ink"
            >
              Register
            </Link>
          </div>
        </div>
      </header>

      <nav className="bg-nse text-nse-ink">
        <div className="mx-auto flex max-w-6xl flex-wrap">
          {MENUS.map((menu) => (
            <div
              key={menu.label}
              className="relative"
              onMouseEnter={() => setOpenMenu(menu.label)}
              onMouseLeave={() => setOpenMenu(null)}
            >
              <button
                type="button"
                className="inline-flex h-11 items-center gap-1 px-4 text-sm font-medium hover:bg-nse-mid"
                onClick={() => setOpenMenu((cur) => (cur === menu.label ? null : menu.label))}
              >
                {menu.label}
                <ChevronDown className="size-3.5 opacity-80" />
              </button>
              {openMenu === menu.label ? (
                <div className="absolute left-0 z-30 min-w-48 rounded-b-sm border border-nse-line bg-nse-card py-1 text-nse-fg shadow-lg">
                  {menu.items.map((item) => (
                    <Link
                      key={item.to}
                      to={item.to}
                      className="block px-4 py-2.5 text-sm hover:bg-nse-wash hover:text-nse"
                      onClick={() => setOpenMenu(null)}
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              ) : null}
            </div>
          ))}
          <Link to="/" className="inline-flex h-11 items-center px-4 text-sm font-medium hover:bg-nse-mid">
            PlanVista home
          </Link>
        </div>
      </nav>

      <div className="overflow-hidden bg-nse-tick text-nse-ink">
        <div className="flex w-max animate-[ticker_60s_linear_infinite] gap-8 py-2 pr-8">
          {(tape.length ? tape : [{ symbol: "NIFTY", shortName: "NIFTY 50", price: 0, changePct: 0, currency: "INR", change: 0 } as MarketQuote]).map((s, i) => {
            const green = s.change >= 0;
            return (
              <Link
                key={`${s.symbol}-${i}`}
                to="/quote/$symbol"
                params={{ symbol: s.symbol }}
                className="inline-flex items-center gap-2 whitespace-nowrap text-xs"
              >
                <span className="font-semibold text-nse-mist">{s.shortName || s.symbol.replace(/\.NS$/, "")}</span>
                <span className="tabular-nums">{formatMoney(s.price, s.currency)}</span>
                <span className={cn("tabular-nums", green ? "text-up" : "text-down")}>{pct(s.changePct)}</span>
              </Link>
            );
          })}
        </div>
      </div>

      <section className="bg-nse-card">
        <div className="mx-auto grid max-w-6xl gap-5 px-3 py-5 lg:grid-cols-[1.4fr_1fr]">
          <div className="rounded-md border border-nse-line bg-nse-wash p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h1 className="text-xl font-bold text-nse">NIFTY 50</h1>
              <span className="text-[11px] text-nse-muted">
                {session.label} · {istStamp(asOf)} IST
              </span>
            </div>
            {nifty ? (
              <>
                <div className="mt-2 flex flex-wrap items-baseline gap-3">
                  <span className="text-3xl font-bold tabular-nums text-nse-fg">{formatMoney(nifty.price, nifty.currency)}</span>
                  <span className={cn("text-base font-medium tabular-nums", up ? "text-up" : "text-down")}>
                    {up ? "+" : ""}
                    {nifty.change.toFixed(2)} ({pct(nifty.changePct)})
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap gap-5 text-sm">
                  <span>
                    <span className="text-nse-muted">Open </span>
                    <span className="font-medium tabular-nums">{openPx != null ? formatMoney(openPx, nifty.currency) : "—"}</span>
                  </span>
                  <span>
                    <span className="text-nse-muted">High </span>
                    <span className="font-medium tabular-nums">
                      {nifty.dayHigh != null ? formatMoney(nifty.dayHigh, nifty.currency) : "—"}
                    </span>
                  </span>
                  <span>
                    <span className="text-nse-muted">Low </span>
                    <span className="font-medium tabular-nums">
                      {nifty.dayLow != null ? formatMoney(nifty.dayLow, nifty.currency) : "—"}
                    </span>
                  </span>
                </div>
                <div className="mt-3 rounded-sm border border-nse-line bg-nse-card p-2">
                  <Sparkline data={spark} up={up} className="h-24 w-full" />
                  <div className="mt-2 flex flex-wrap gap-1">
                    {RANGES.map((r) => (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => setRange(r.id)}
                        className={cn(
                          "h-8 rounded-sm border px-2.5 text-[11px]",
                          range === r.id
                            ? "border-nse bg-nse text-nse-ink"
                            : "border-nse-line text-nse-muted hover:border-nse hover:text-nse",
                        )}
                      >
                        {r.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <p className="mt-6 text-sm text-nse-muted">{busy ? "Loading last print…" : "Tape unavailable."}</p>
            )}
            <div className="mt-3">
              <TapeStamp
                asOf={asOf}
                source={source}
                busy={busy}
                onRefresh={() => {
                  setBusy(true);
                  setTick((n) => n + 1);
                }}
              />
            </div>
          </div>

          <div className="rounded-md border border-nse-line bg-nse-card p-4">
            <h2 className="text-sm font-semibold text-nse">{t(lang, "Key indices")}</h2>
            <ul className="mt-2 divide-y divide-nse-line">
              {indices.map((i) => {
                const green = i.change >= 0;
                return (
                  <li key={i.symbol}>
                    <Link
                      to="/quote/$symbol"
                      params={{ symbol: i.symbol }}
                      className="flex items-center justify-between gap-3 py-2.5 hover:bg-nse-wash"
                    >
                      <span className="text-sm font-medium">{i.name}</span>
                      <span className="text-right">
                        <span className="block text-sm font-semibold tabular-nums">{formatMoney(i.price, i.currency)}</span>
                        <span className={cn("block text-xs tabular-nums", green ? "text-up" : "text-down")}>
                          {pct(i.changePct)}
                        </span>
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-3 py-6">
        <h2 className="text-lg font-semibold text-nse">
          {t(lang, "Market statistics")}{" "}
          <span className="text-xs font-normal text-nse-muted">PlanVista universe · {istStamp(asOf)} IST</span>
        </h2>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: "Names tracked", value: stats?.traded ?? "—" },
            { label: "Advances", value: stats?.advances ?? "—", tone: "up" as const },
            { label: "Declines", value: stats?.declines ?? "—", tone: "down" as const },
            { label: "Unchanged", value: stats?.unchanged ?? "—" },
            { label: "Near 52w high", value: stats?.weekHigh ?? "—" },
            { label: "Near 52w low", value: stats?.weekLow ?? "—" },
            { label: "Volume", value: stats ? formatVol(stats.volume) : "—" },
            { label: "Notional", value: stats ? `₹${(stats.value / 1e7).toFixed(1)} Cr` : "—" },
          ].map((card) => (
            <div key={card.label} className="rounded-md border border-nse-line bg-nse-card p-3 text-center">
              <p className="text-[11px] text-nse-muted">{card.label}</p>
              <p
                className={cn(
                  "mt-1 text-xl font-bold tabular-nums",
                  card.tone === "up" ? "text-up" : card.tone === "down" ? "text-down" : "text-nse",
                )}
              >
                {card.value}
              </p>
            </div>
          ))}
        </div>
        <p className="mt-2 text-xs text-nse-muted">
          Counts are from names PlanVista tracks, not the full NSE board. Public delayed tape — not a broker feed.
        </p>
      </section>

      <section className="mx-auto max-w-6xl px-3 pb-6">
        <h2 className="text-lg font-semibold text-nse">
          {t(lang, "Tracked book")} <span className="text-xs font-normal text-nse-muted">Volume × last print</span>
        </h2>
        <div className="mt-3 overflow-x-auto rounded-md border border-nse-line bg-nse-card">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-nse text-nse-ink">
              <tr>
                <th className="px-3 py-2.5 text-left font-medium">Sector</th>
                <th className="px-3 py-2.5 text-right font-medium">Names</th>
                <th className="px-3 py-2.5 text-right font-medium">Volume</th>
                <th className="px-3 py-2.5 text-right font-medium">Value (₹ Cr)</th>
              </tr>
            </thead>
            <tbody>
              {book.map((row) => (
                <tr key={row.sector} className="border-t border-nse-line hover:bg-nse-wash">
                  <td className="px-3 py-2.5 font-medium">{row.sector}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{row.names}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{formatVol(row.volume)}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{(row.value / 1e7).toFixed(2)}</td>
                </tr>
              ))}
              {stats ? (
                <tr className="border-t border-nse-line bg-nse-wash font-semibold">
                  <td className="px-3 py-2.5">Total tracked</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{stats.traded}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{formatVol(stats.volume)}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{(stats.value / 1e7).toFixed(2)}</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-3 pb-6">
        <h2 className="text-lg font-semibold text-nse">
          {t(lang, "Top movers")}{" "}
          <span className="text-xs font-normal text-nse-muted">PlanVista names · last print</span>
        </h2>
        <div className="mt-3 grid gap-3 lg:grid-cols-3">
          <MoverCol title={t(lang, "Gainers")} icon="up" rows={gainers} />
          <MoverCol title={t(lang, "Losers")} icon="down" rows={losers} />
          <MoverCol title={t(lang, "Most active")} icon="vol" rows={active} volume />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-3 pb-6">
        <div className="grid gap-3 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-md border border-nse-line bg-nse-card p-4">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-nse">
              <CalendarDays className="size-4" />
              {t(lang, "Holidays")}
            </h2>
            <p className="mt-1 text-xs text-nse-muted">
              Next NSE capital-market holidays. Regular session is Mon–Fri, 9:15–15:30 IST. Not a broker calendar.
            </p>
            <ul className="mt-3 divide-y divide-nse-line">
              {holidays.map((h) => (
                <li key={h.date} className="flex items-baseline justify-between gap-3 py-2.5">
                  <span>
                    <span className="block text-sm font-medium">{h.name}</span>
                    {h.note ? <span className="text-[11px] text-nse-muted">{h.note}</span> : null}
                  </span>
                  <span className="shrink-0 text-right text-sm tabular-nums text-nse">
                    {h.date.slice(8)}/{h.date.slice(5, 7)}
                    <span className="ml-1 text-[11px] text-nse-muted">{h.day}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-md border border-nse-line border-l-4 border-l-nse-accent bg-nse-card p-4">
            <h2 className="text-lg font-semibold text-nse">{t(lang, "IPOs & listings")}</h2>
            <p className="mt-1 text-xs text-nse-muted">
              Live headlines about issues and listings. PlanVista does not run an IPO book — read, then use Deep Search.
            </p>
            <ul className="mt-3 space-y-3">
              {ipoNews.length ? (
                ipoNews.map((item) => (
                  <li key={item.url + item.title}>
                    <a href={item.url || "#"} target="_blank" rel="noreferrer" className="block hover:text-nse">
                      <p className="text-[11px] font-semibold uppercase tracking-wide text-nse-accent">{item.source}</p>
                      <p className="mt-0.5 text-sm font-medium">{item.title}</p>
                      <p className="text-xs text-nse-muted">{item.published ? timeAgo(item.published) : ""}</p>
                    </a>
                  </li>
                ))
              ) : (
                <li className="text-sm text-nse-muted">No IPO headline in this refresh. Check Learn → classroom, or Deep Search.</li>
              )}
            </ul>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link to="/learn" className="inline-flex h-10 items-center rounded-sm bg-nse px-3 text-sm text-nse-ink">
                How an IPO works
              </Link>
              <Link
                to="/chart-gpt"
                className="inline-flex h-10 items-center rounded-sm border border-nse px-3 text-sm text-nse"
              >
                Ask Chart GPT
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-3 pb-6">
        <div className="rounded-md border border-nse-line bg-nse-wash p-4">
          <h2 className="text-lg font-semibold text-nse">{t(lang, "How to read this desk")}</h2>
          <div className="mt-3 grid gap-3 text-sm leading-relaxed text-nse-fg sm:grid-cols-3">
            <p>
              <span className="font-semibold text-nse">Tape, not a tip.</span> Green and red are last prints versus
              previous close. They are not buy or sell signals.
            </p>
            <p>
              <span className="font-semibold text-nse">Option chain.</span> We do not show live strikes. First learn
              candles, trend and volume on Chart GPT, then open a broker for chains.
            </p>
            <p>
              <span className="font-semibold text-nse">Tracked book.</span> Counts are names PlanVista follows, not the
              full NSE board of 2,000+ stocks.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-nse-card py-6">
        <div className="mx-auto max-w-6xl px-3">
          <h2 className="text-lg font-semibold text-nse">{t(lang, "Quick access")}</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {QUICK.map((card) => {
              const Icon = card.icon;
              return (
                <Link
                  key={card.to}
                  to={card.to}
                  className="rounded-md border border-nse-line bg-nse-wash p-4 hover:border-nse"
                >
                  <Icon className="size-5 text-nse" />
                  <h3 className="mt-2 text-sm font-semibold text-nse">{card.title}</h3>
                  <p className="mt-1 text-xs text-nse-muted">{card.body}</p>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-3 py-6">
        <h2 className="text-lg font-semibold text-nse">{t(lang, "Headlines")}</h2>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          {news.slice(0, 6).map((item) => (
            <a
              key={item.url + item.title}
              href={item.url || "#"}
              target="_blank"
              rel="noreferrer"
              className="rounded-md border border-nse-line border-l-4 border-l-nse-accent bg-nse-card p-4 hover:bg-nse-wash"
            >
              <p className="text-[11px] font-semibold uppercase tracking-wide text-nse-accent">{item.source}</p>
              <p className="mt-1 text-sm font-medium">{item.title}</p>
              <p className="mt-1 text-xs text-nse-muted">{item.published ? timeAgo(item.published) : ""}</p>
            </a>
          ))}
        </div>
      </section>

      <footer className="bg-nse-deep py-8 text-nse-mist">
        <div className="mx-auto grid max-w-6xl gap-6 px-3 sm:grid-cols-3">
          <div>
            <p className="flex items-center gap-2 font-semibold text-nse-ink">
              <Building2 className="size-4" />
              PlanVista NSE desk
            </p>
            <p className="mt-2 text-xs leading-relaxed">
              Unofficial classroom board. Not the National Stock Exchange of India, not a broker, not SEBI-registered
              advice. Delayed public tape.
            </p>
          </div>
          <div>
            <p className="font-semibold text-nse-ink">Inside PlanVista</p>
            <div className="mt-2 flex flex-col gap-1 text-sm">
              <Link to="/markets" className="hover:text-nse-ink">
                Markets
              </Link>
              <Link to="/chart-gpt" className="hover:text-nse-ink">
                Chart GPT
              </Link>
              <Link to="/learn" className="hover:text-nse-ink">
                Learn
              </Link>
            </div>
          </div>
          <div>
            <p className="font-semibold text-nse-ink">Session</p>
            <p className="mt-2 text-sm">{session.label}</p>
            <p className="text-xs">{source === "live" ? "Public delayed tape" : source === "cached" ? "Last good print" : "Classroom sample"}</p>
            <p className="mt-3 inline-flex items-center gap-1 text-xs">
              <BarChart3 className="size-3.5" />
              Education only
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function MoverCol({
  title,
  icon,
  rows,
  volume,
}: {
  title: string;
  icon: "up" | "down" | "vol";
  rows: MarketQuote[];
  volume?: boolean;
}) {
  return (
    <div className="rounded-md border border-nse-line bg-nse-card">
      <div className="flex items-center gap-2 border-b border-nse-line px-3 py-2.5">
        {icon === "up" ? (
          <TrendingUp className="size-4 text-up" />
        ) : icon === "down" ? (
          <TrendingDown className="size-4 text-down" />
        ) : (
          <BarChart3 className="size-4 text-nse" />
        )}
        <h3 className="text-sm font-semibold text-nse">{title}</h3>
      </div>
      <ul className="divide-y divide-nse-line">
        {rows.length ? (
          rows.map((s) => {
            const green = s.change >= 0;
            return (
              <li key={s.symbol}>
                <Link
                  to="/quote/$symbol"
                  params={{ symbol: s.symbol }}
                  className="flex items-center justify-between gap-2 px-3 py-2.5 hover:bg-nse-wash"
                >
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium">{s.shortName || s.symbol.replace(/\.NS$/, "")}</span>
                    {volume ? (
                      <span className="text-[11px] text-nse-muted">Vol {formatVol(s.volume ?? 0)}</span>
                    ) : null}
                  </span>
                  <span className="text-right">
                    <span className="block text-sm font-semibold tabular-nums">{formatMoney(s.price, s.currency)}</span>
                    <span className={cn("block text-xs tabular-nums", green ? "text-up" : "text-down")}>
                      {pct(s.changePct)}
                    </span>
                  </span>
                </Link>
              </li>
            );
          })
        ) : (
          <li className="px-3 py-4 text-sm text-nse-muted">Waiting for last print…</li>
        )}
      </ul>
    </div>
  );
}
