import { useEffect, useRef } from "react";

/** Fetch on mount, on tab focus, and on an interval while the page is visible. */
export function useLiveRefresh(fn: () => void, intervalMs: number, deps: unknown[] = []) {
  const fnRef = useRef(fn);
  fnRef.current = fn;

  useEffect(() => {
    const run = () => {
      if (typeof document !== "undefined" && document.visibilityState === "hidden") return;
      fnRef.current();
    };
    run();
    const id = window.setInterval(run, intervalMs);
    const kick = () => {
      if (document.visibilityState === "visible") fnRef.current();
    };
    document.addEventListener("visibilitychange", kick);
    window.addEventListener("focus", kick);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", kick);
      window.removeEventListener("focus", kick);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- caller passes explicit deps
  }, deps);
}
