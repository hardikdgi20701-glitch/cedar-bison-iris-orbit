import { createFileRoute, Link } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/learn";
import { useSiply } from "@/lib/store";

export const Route = createFileRoute("/learn")({ component: Learn });

function Learn() {
  const read = useSiply((s) => s.readSlugs);
  return (
    <div className="space-y-6">
      <div className="max-w-2xl">
        <h1 className="text-2xl font-medium tracking-tight">Learn</h1>
        <p className="mt-1 text-[15px] leading-relaxed text-muted">
          Written for people who are new to the market. Start at the top. Each piece has examples, a
          mini-glossary and takeaways. Read two to earn the reader badge. When you want a live chart
          explained, open{" "}
          <Link to="/chart-gpt" className="text-primary hover:underline">
            Chart GPT
          </Link>{" "}
          and ask it to teach — not to pick.
        </p>
      </div>
      <ul className="grid gap-3 sm:grid-cols-2">
        {ARTICLES.map((a) => (
          <li key={a.slug}>
            <Link
              to="/learn/$slug"
              params={{ slug: a.slug }}
              className="block h-full overflow-hidden rounded-xl border border-border hover:bg-surface"
            >
              {a.image ? <img src={a.image} alt="" className="h-36 w-full object-cover" /> : null}
              <div className="px-4 py-4">
                <p className="text-[11px] font-medium uppercase tracking-wide text-primary">{a.kicker}</p>
                <p className="mt-1 text-base font-medium">{a.title}</p>
                <p className="mt-2 text-sm leading-relaxed text-muted">
                  {a.body[0].length > 160 ? `${a.body[0].slice(0, 157).trim()}…` : a.body[0]}
                </p>
                <p className="mt-2 text-xs text-subtle">
                  {a.minutes} min read
                  {read.includes(a.slug) ? " · Read" : ""}
                </p>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
