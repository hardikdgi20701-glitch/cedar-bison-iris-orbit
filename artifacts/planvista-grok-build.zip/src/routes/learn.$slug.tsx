import { createFileRoute, Link } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/learn";
import { useSiply } from "@/lib/store";
import { useEffect } from "react";

export const Route = createFileRoute("/learn/$slug")({ component: Article });

function Article() {
  const { slug } = Route.useParams();
  const article = ARTICLES.find((a) => a.slug === slug);
  const markRead = useSiply((s) => s.markRead);

  useEffect(() => {
    if (article) markRead(article.slug);
  }, [article, markRead]);

  if (!article) {
    return (
      <p className="py-16 text-center text-muted">
        Article missing.{" "}
        <Link to="/learn" className="text-primary hover:underline">
          All explainers
        </Link>
      </p>
    );
  }

  const artLabel: Record<string, string> = {
    "what-is-a-share": "Share",
    "what-is-a-sip": "SIP",
    "nifty-sensex": "Nifty",
    "goal-based-vs-random": "Goals",
    "inflation-is-the-silent-fee": "Inflation",
    "risk-for-students": "Risk",
    "index-funds-first": "Index",
    "step-up-sip": "Step-up",
    "how-to-read-candles": "Candles",
    "stop-loss-and-target": "Stops",
    "bull-vs-bear": "Bull / Bear",
    "reading-market-stats": "Stats",
    "sebi-guidelines-basics": "SEBI",
    "how-to-read-graphs": "Graphs",
    "demat-and-orders": "Demat",
    "first-mistakes": "Habits",
    "using-chart-gpt": "Chart GPT",
    "which-timeframe": "Timeframes",
    "indicators-later": "Indicators",
  };

  const idx = ARTICLES.findIndex((a) => a.slug === article.slug);
  const prev = idx > 0 ? ARTICLES[idx - 1] : null;
  const next = idx >= 0 && idx < ARTICLES.length - 1 ? ARTICLES[idx + 1] : null;

  return (
    <article className="mx-auto max-w-2xl">
      <Link to="/learn" className="text-xs text-primary hover:underline">
        All explainers
      </Link>
      <div className="mt-4 overflow-hidden rounded-2xl border border-border">
        {article.image ? (
          <img src={article.image} alt="" className="h-48 w-full object-cover sm:h-56" />
        ) : (
          <div className="flex h-36 items-center justify-center bg-surface">
            <span className="text-3xl font-semibold tracking-tight text-muted">
              {artLabel[article.slug] || "Learn"}
            </span>
          </div>
        )}
      </div>
      <p className="mt-4 text-[11px] font-medium uppercase tracking-wide text-primary">{article.kicker}</p>
      <h1 className="mt-1 text-3xl font-medium tracking-tight">{article.title}</h1>
      <p className="mt-2 text-sm text-subtle">{article.minutes} min read · Written for first-time investors</p>
      <p className="mt-4 text-base leading-relaxed text-muted">{article.body[0]}</p>
      <div className="mt-6 space-y-4 text-[17px] leading-[1.7] text-fg">
        {article.body.slice(1).map((p) => (
          <p key={p.slice(0, 32)}>{p}</p>
        ))}
      </div>

      {article.example ? (
        <div className="mt-8 rounded-xl border border-border bg-surface p-4">
          <p className="text-[11px] font-medium uppercase tracking-wide text-primary">{article.example.title}</p>
          <ul className="mt-3 space-y-2 text-sm leading-relaxed text-fg">
            {article.example.lines.map((line) => (
              <li key={line.slice(0, 28)} className="flex gap-2">
                <span className="mt-2 size-1.5 shrink-0 rounded-full bg-primary" />
                <span>{line}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {article.terms?.length ? (
        <div className="mt-8">
          <h2 className="text-sm font-medium uppercase tracking-wide text-subtle">Words to know</h2>
          <dl className="mt-3 divide-y divide-border overflow-hidden rounded-xl border border-border">
            {article.terms.map((t) => (
              <div key={t.term} className="grid gap-1 px-4 py-3 sm:grid-cols-[140px_1fr] sm:gap-4">
                <dt className="text-sm font-medium">{t.term}</dt>
                <dd className="text-sm text-muted">{t.meaning}</dd>
              </div>
            ))}
          </dl>
        </div>
      ) : null}

      {article.takeaways?.length ? (
        <div className="mt-8 rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-4">
          <h2 className="text-sm font-medium text-emerald-300">Takeaways</h2>
          <ul className="mt-2 space-y-2 text-sm leading-relaxed">
            {article.takeaways.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
        </div>
      ) : null}

      <p className="mt-10 rounded-xl border border-border bg-surface p-4 text-xs leading-relaxed text-muted">
        SEBI reminder: This article is for learning only. It is not investment advice. Numbers are illustrations,
        not forecasts. Do not treat any chart pattern, bull/bear label or statistic as a buy or sell
        recommendation. Capital is at risk in markets. Past performance is not indicative of future results.
      </p>

      {["how-to-read-candles", "how-to-read-graphs", "bull-vs-bear", "stop-loss-and-target", "using-chart-gpt", "which-timeframe", "indicators-later", "reading-market-stats"].includes(
        article.slug,
      ) ? (
        <p className="mt-4 rounded-xl border border-primary/20 bg-primary-soft p-4 text-sm leading-relaxed">
          Want this explained on a live (or last-close) chart?{" "}
          <Link to="/chart-gpt" className="font-medium text-primary hover:underline">
            Open Chart GPT
          </Link>{" "}
          and ask in your own words. It will teach. It will not pick a stock.
        </p>
      ) : null}

      <div className="mt-8 flex justify-between gap-4 text-sm">
        {prev ? (
          <Link to="/learn/$slug" params={{ slug: prev.slug }} className="text-primary hover:underline">
            ← {prev.title}
          </Link>
        ) : (
          <span />
        )}
        {next ? (
          <Link to="/learn/$slug" params={{ slug: next.slug }} className="ml-auto text-right text-primary hover:underline">
            {next.title} →
          </Link>
        ) : null}
      </div>
    </article>
  );
}
