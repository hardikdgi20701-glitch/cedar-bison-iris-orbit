import { createServerFn } from "@tanstack/react-start";
import { teachChart, type ChartSnapshot, type ChatTurn } from "./chart-teacher";

const DISCLAIMER = "For learning purposes only.";

export function localResearch(prompt: string, context: string, history: ChatTurn[] = []): string {
  const p = prompt.toLowerCase();
  const prior = history
    .filter((m) => m.role === "user")
    .slice(-2)
    .map((m) => m.text)
    .join(" ");
  const joined = `${prior} ${p}`;

  if (/(buy|sell|sure.?shot|recommend|ye lo|target do|intrade)/i.test(p)) {
    return [
      "**No pick, no target.** PlanVista will not tell you which stock to buy or sell.",
      "Write a named goal, match the mix to the date, and keep rent money out of equity. If you wanted a chart explained, open **Chart GPT** and ask how to *read* the picture.",
      context ? `Tape note: ${context.slice(0, 400)}` : "",
      DISCLAIMER,
    ]
      .filter(Boolean)
      .join("\n\n");
  }
  if (/(sip|lumpsum|mutual fund|index fund)/i.test(joined)) {
    return [
      "**SIP vs lump sum — classroom version.**",
      "A SIP invests a fixed rupee amount on a schedule. A lump sum invests in one go. For money you need inside 3 years, neither belongs in a pure equity fund. For a 7-year+ goal, a SIP into a low-cost index fund is the usual classroom start — on a real app. PlanVista does not invest for you.",
      "- Rupee-cost averaging is a habit, not a guarantee.",
      "- Red months buy more units. That only helps if you do not pause.",
      "- Name the job (fees, laptop, emergency) before you pick a fund category.",
      DISCLAIMER,
    ].join("\n\n");
  }
  if (/(nifty|sensex|market today|kya ho raha|oil|rupee)/i.test(joined)) {
    return [
      "**How to read ‘the market’ without panicking.**",
      "Nifty and Sensex are scoreboards of large Indian companies — mood, not your report card. A 1% day is loud. A 2% day is very loud. One loud day still does not decide a 5-year fee goal.",
      context ? `Snapshot: ${context.slice(0, 700)}` : "No live snapshot attached. Open Home or Markets for the last print, then ask again.",
      "Oil, the rupee and global cues show up in the tape. They explain *why the last session moved*. They are not a buy or sell instruction.",
      DISCLAIMER,
    ].join("\n\n");
  }
  if (/(inflation|goal|risk|emergency)/i.test(joined)) {
    return [
      "**Calendar first, product second.**",
      "Inflate the goal, then size the SIP. Short calendar (under 3 years) → mostly debt/liquid. Long calendar (7+ years) can hold more equity. Emergency cash is not a SIP.",
      "The quizzes here are teaching tools, not a SEBI-registered risk profile.",
      DISCLAIMER,
    ].join("\n\n");
  }
  return [
    "**PlanVista research desk (teaching notes).**",
    `Question: ${prompt}`,
    context ? `Context: ${context.slice(0, 600)}` : "No live snapshot attached.",
    "Shares can lose value. A SIP is a schedule, not a guarantee. Read the last move as history — not as a buy or sell instruction.",
    "For a live chart classroom, open **Chart GPT** and stay on one symbol.",
    DISCLAIMER,
  ].join("\n\n");
}

export const askResearch = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as { prompt?: string; context?: string; history?: ChatTurn[] };
    const prompt = String(d?.prompt ?? "").trim();
    if (!prompt) throw new Error("Ask a question");
    if (prompt.length > 2000) throw new Error("Keep questions under 2,000 characters");
    const history = Array.isArray(d?.history)
      ? d.history
          .slice(-8)
          .map((m) => ({
            role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
            text: String(m.text ?? "").slice(0, 1200),
          }))
          .filter((m) => m.text)
      : [];
    return { prompt, context: String(d?.context ?? "").slice(0, 4000), history };
  })
  .handler(async ({ data }) => {
    const local = localResearch(data.prompt, data.context, data.history);
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: true as const, text: local };

    const system = `You are PlanVista Finance Research, an educational market explainer for Indian (NSE/BSE) and global markets.
Rules:
- For learning purposes only. Not investment advice, not a SEBI-registered advisor, not a recommendation to buy or sell.
- Be concise, structured, and calm. Use short paragraphs and bullet points. Write in readable English; light Hindi is fine.
- If you cite numbers from the provided context, treat them as delayed public-market snapshots that may be stale.
- If data is missing, say so. Do not invent filings, insider information, or guaranteed returns.
- Prefer explaining *why* a move or ratio matters over telling the user what to do.
- End with a one-line reminder: "For learning purposes only."`;

    const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
      { role: "system", content: system },
    ];
    if (data.context) messages.push({ role: "user", content: `Context:\n${data.context}` });
    for (const m of data.history) {
      messages.push({ role: m.role, content: m.text });
    }
    messages.push({ role: "user", content: data.prompt });

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          max_tokens: 700,
          temperature: 0.4,
          messages,
        }),
      });
      if (!res.ok) return { ok: true as const, text: local };
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = body.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) return { ok: true as const, text: local };
      return { ok: true as const, text };
    } catch {
      return { ok: true as const, text: local };
    }
  });

export const askChartGpt = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = data as {
      prompt?: string;
      context?: string;
      history?: ChatTurn[];
      snapshot?: ChartSnapshot;
    };
    const prompt = String(d?.prompt ?? "").trim();
    if (!prompt) throw new Error("Ask Chart GPT a question");
    if (prompt.length > 2000) throw new Error("Keep questions under 2,000 characters");
    const history = Array.isArray(d?.history)
      ? d.history
          .slice(-8)
          .map((m) => ({
            role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
            text: String(m.text ?? "").slice(0, 1500),
          }))
          .filter((m) => m.text)
      : [];
    const snapshot = d?.snapshot && typeof d.snapshot === "object" ? (d.snapshot as ChartSnapshot) : null;
    return { prompt, context: String(d?.context ?? "").slice(0, 5000), history, snapshot };
  })
  .handler(async ({ data }) => {
    const local = data.snapshot
      ? teachChart(data.prompt, data.snapshot, data.history)
      : localResearch(data.prompt, data.context, data.history);
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: true as const, text: local };

    const system = `You are "Chart GPT — Awaaz Desk", an educational chart explainer in the style of a calm CNBC Awaaz market-desk teacher. Hindi-English mix is welcome; keep sentences short and readable.
You help first-time Indian investors READ a chart. You never tell them to buy or sell a specific stock.

Rules:
- For learning purposes only. Not investment advice. Not a SEBI-registered research analyst or adviser.
- Explain candles, trend, support/resistance, volume, bull vs bear colour in simple words.
- Use the provided snapshot numbers only. If a number is missing, say so. Do not invent prices, targets, or "sure-shot" levels.
- No guaranteed returns. No "ye stock lo". Offer 2–4 teaching bullets and one risk reminder.
- If the user asks for a buy/sell call, refuse and teach how a stop-loss and target are written instead.
- Structure every reply with short paragraphs and bullets so a beginner can actually read it.
- Remember prior turns in this chat and stay on the same symbol unless the snapshot changes.
- End with: "Yeh sirf padhai ke liye hai — Chart GPT is not a buy/sell call."`;

    const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
      { role: "system", content: system },
    ];
    if (data.context) {
      messages.push({
        role: "user",
        content: `Chart snapshot (delayed public tape — treat as last print, not a live tick):\n${data.context}`,
      });
      messages.push({
        role: "assistant",
        content: "Understood. I will teach from this snapshot only and will not give a buy/sell call.",
      });
    }
    for (const m of data.history) {
      messages.push({ role: m.role, content: m.text });
    }
    messages.push({ role: "user", content: `Learner question: ${data.prompt}` });

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          max_tokens: 700,
          temperature: 0.35,
          messages,
        }),
      });
      if (!res.ok) return { ok: true as const, text: local };
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = body.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) return { ok: true as const, text: local };
      return { ok: true as const, text };
    } catch {
      return { ok: true as const, text: local };
    }
  });
